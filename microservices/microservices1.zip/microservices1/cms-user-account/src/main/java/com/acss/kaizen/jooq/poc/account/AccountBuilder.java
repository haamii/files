package com.acss.kaizen.jooq.poc.account;

import com.acss.kaizen.jooq.poc.account.constants.AccountStatus;
import com.acss.kaizen.jooq.poc.role.UserRole;

/**
 * Builds an Account object.
 * @author gvargas
 *
 */
public class AccountBuilder {
	
	private Account user = new Account();
	
	public static final String DEFAULT_USERNAME="juan";
	public static final String DEFAULT_PASSWORD="password";
	public static final String DEFAULT_FNAME="Juan";
	public static final String DEFAULT_LNAME="Dela Cruz";
	public static final String DEFAULT_EMAIL="juan@mail.com";
	
	public static final String DEFAULT_ROLE="ROLE_USER";
	
	public AccountBuilder edit(Account account){
		this.user=account;
		return this;
	}
	
	/*
	 * Builder method starts here.
	 */
	public AccountBuilder withId(Long id){
		user.setId(id);
		return this;
	}
	public AccountBuilder withUsername(String username){
		//immediately updates the role with the assigned username.
		if(user.getAuthority()!=null){
			user.getAuthority().setUsername(username);
		}
		
		user.setUserCd(username);
		return this;
	}
	public AccountBuilder withPassword(String password){
		user.setPassword(password);
		return this;
	}
	public AccountBuilder withEmail(String email){
		user.setEmail(email);
		return this;
	}
	public AccountBuilder withFirstName(String firstName){
		user.setName(firstName);
		return this;
	}
	public AccountBuilder withRole(UserRole role){
		user.setAuthority(role);
		return this;
	}
	public AccountBuilder withDefaultRole(){
		user.setAuthority(new UserRole(user.getUserCd(), DEFAULT_ROLE,user.getId()));
		return this;
	}
	public AccountBuilder withAdditionalRole(String role){
		user.addRole(role);
		return this;
	}
	public AccountBuilder withStatus(AccountStatus status){
		user.setStatus(status);
		return this;
	}
	
	public AccountBuilder withStoreCd(String storeCd){
		user.setStoreCd(storeCd);
		return this;
	}

	/**
	 * Creates a default dummy user for testing purposes.
	 * <br>
	 * with default values as:
	 * <br>
	 * DEFAULT_USERNAME = {@value #DEFAULT_USERNAME}
	 * <br>
	 * DEFAULT_PASSWORD = {@value #DEFAULT_PASSWORD}
	 * <br>
	 * DEFAULT_FNAME = {@value #DEFAULT_FNAME}
	 * <br>
	 * DEFAULT_LNAME = {@value #DEFAULT_LNAME}
	 * <br>
	 * DEFAULT_EMAIL = {@value #DEFAULT_EMAIL}
	 * <br>
	 * DEFAULT_ROLE = {@value #DEFAULT_ROLE}
	 * 
	 * @return AccountBuilder
	 */
	public AccountBuilder aDefaultAccount(){
		withUsername(DEFAULT_USERNAME);
		withPassword(DEFAULT_PASSWORD);
		withFirstName(DEFAULT_FNAME);
		withPassword(DEFAULT_PASSWORD);
		withEmail(DEFAULT_EMAIL);
		withStatus(AccountStatus.ACTIVE);
		withDefaultRole();
		return this;
	}
	/*
	 * Builder method ends here.
	 */
	
	/**
	 * Builds a user.
	 * @return
	 */
	public Account build(){
		return user;
	}
}
