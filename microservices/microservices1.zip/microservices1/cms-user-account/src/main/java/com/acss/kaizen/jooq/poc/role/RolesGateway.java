package com.acss.kaizen.jooq.poc.role;

import static com.acss.kaizen.jooq.poc.db.tables.MAccountRoles.M_ACCOUNT_ROLES;

import java.math.BigDecimal;
import java.util.List;

import org.jooq.Condition;
import org.jooq.DSLContext;
import org.jooq.Record;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.acss.kaizen.jooq.poc.base.DomainGateway;
import com.acss.kaizen.jooq.poc.db.tables.records.MAccountRolesRecord;

@Component
public class RolesGateway implements DomainGateway<String,MAccountRolesRecord>{

	private final DSLContext jooq;
	
	@Autowired
	public RolesGateway(DSLContext jooq){
		this.jooq = jooq;
	}
	
	public Record retrieve(Long key) {
		
		return null;
	}


	public List<Record> retrieve() {
		
		return null;
	}


	public List<Record> retrieve(int limit) {
		
		return null;
	}


	public MAccountRolesRecord persist(MAccountRolesRecord data) {
		return jooq.insertInto(M_ACCOUNT_ROLES).set(data).returning().fetchOne();
	}

	
	public void update(String key, Record data) {
		jooq.update(M_ACCOUNT_ROLES)
		.set(data)
		.where(M_ACCOUNT_ROLES.USERCD.equal(key)).execute();
	}


	public void delete(Long key) {
		
	}

	@Override
	public List<Record> retrieve(Condition condition) {
		
		return null;
	}

	@Override
	public Record retrieve(String key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(String key) {
		// TODO Auto-generated method stub
		
	}

}
