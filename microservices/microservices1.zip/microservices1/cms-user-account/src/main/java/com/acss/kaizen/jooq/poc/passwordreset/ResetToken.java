package com.acss.kaizen.jooq.poc.passwordreset;

import java.math.BigDecimal;

import com.acss.kaizen.jooq.poc.base.BaseEntity;

public class ResetToken extends BaseEntity<Integer>{
	
	public ResetToken() {}

	public ResetToken(String token, BigDecimal expiryDate, BigDecimal userId) {
		super();
		this.token = token;
		this.expiryDate = expiryDate;
		this.userId = userId;
	}

	private String token;
	private BigDecimal expiryDate;
	private BigDecimal creTime;
	private BigDecimal creDate;
	private BigDecimal userId;
	
    public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public BigDecimal getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(BigDecimal expiryDate) {
		this.expiryDate = expiryDate;
	}

	public BigDecimal getUserId() {
		return userId;
	}

	public void setUserId(BigDecimal userId) {
		this.userId = userId;
	}

	public BigDecimal getCreTime() {
		return creTime;
	}

	public void setCreTime(BigDecimal creTime) {
		this.creTime = creTime;
	}

	public BigDecimal getCreDate() {
		return creDate;
	}

	public void setCreDate(BigDecimal creDate) {
		this.creDate = creDate;
	}
	
}
