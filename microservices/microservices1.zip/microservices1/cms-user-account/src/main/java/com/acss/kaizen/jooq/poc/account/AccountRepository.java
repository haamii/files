package com.acss.kaizen.jooq.poc.account;

import java.util.ArrayList;
import java.util.List;

import org.jooq.Condition;
import org.jooq.Record;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.acss.kaizen.jooq.poc.base.DomainFactory;
import com.acss.kaizen.jooq.poc.base.DomainGateway;
import com.acss.kaizen.jooq.poc.base.UpdateableRepository;
import com.acss.kaizen.jooq.poc.db.tables.records.MAccountRolesRecord;
import com.acss.kaizen.jooq.poc.db.tables.records.MCollectionAccountRecord;
import com.acss.kaizen.jooq.poc.role.UserRole;


/**
 * The repository for Account.
 * @author gvargas
 *
 */
@Repository
public class AccountRepository implements UpdateableRepository<Account,String>,AccountRepositoryInterface{
	
	private final DomainGateway<String,MCollectionAccountRecord> accountGateway;
	private final DomainFactory<Account, MCollectionAccountRecord> accountFactory;
	private final DomainGateway<String,MAccountRolesRecord> rolesGateway;
	private final DomainFactory<UserRole, MAccountRolesRecord> rolesFactory;
	private AccountGateway accountEntityGateway;
	
	/**
	 * The repository for Account
	 * 
	 * List of dependencies as follows
	 * @param accountGateway
	 * @param accountFactory
	 * @param rolesGateway
	 * @param rolesFactory
	 */
	@Autowired
	public AccountRepository(DomainGateway<String, MCollectionAccountRecord> accountGateway,
			DomainFactory<Account, MCollectionAccountRecord> accountFactory,
			DomainGateway<String, MAccountRolesRecord> rolesGateway,
			DomainFactory<UserRole, MAccountRolesRecord> rolesFactory,
			AccountGateway accountEntityGateway){
		
		this.accountFactory = accountFactory;
		this.accountGateway = accountGateway;
		this.rolesFactory = rolesFactory;
		this.rolesGateway = rolesGateway;
		this.accountEntityGateway = accountEntityGateway;
	}
	
	/**
	 * Adds an account
	 */
	@Transactional
	public Account add(Account account) {
		account.encodePassword();
		
		
		//account.setCreDate(ACSSDateUtil.getDateAsYYYYMMDDFromDateTime());
		//account.setCreTime(ACSSDateUtil.getTimeAsHHMMSSFromDateTime());
		MCollectionAccountRecord newAccount = accountGateway.persist(accountFactory.createRecord(account));

		//UserRole role = account.getAuthority();
		//get the newly generated ID from MAccountRecord and use it to persist role. 
		//role.setAccountId(newAccount.getId().longValue());
		//rolesGateway.persist(rolesFactory.createRecord(role));
		//return by finding by newly created ID from the MAccountRecord.
		//return findById(newAccount.getId().longValue());
		return findNewUser(newAccount.getUsercd());
	}
	
	
	/**
	 * Deletes by Id and return the deleted entity for post delete operation.
	 */
	@Transactional
	public Account delete(String id) {
		Account deletedAccount = findById(id);
		accountGateway.delete(id);
		return deletedAccount;
	}
	
	/**
	 * Finds all record
	 */
	@Transactional(readOnly=true)
	public List<Account> findAll() {
		List<Record> queryResults = accountEntityGateway.retrieveUnregisteredHPSUser();
		
		List<Account> accounts = new ArrayList<Account>();
		for(Record queryResult:queryResults){
			accounts.add(accountFactory.make(queryResult, Account.class));
		}
		if(accounts.size() > 0){
			return accounts;
		}else
			throw new DataRetrievalFailureException("Users not Found");
	}
	
	/**
	 * Finds by specified ID
	 */
	@Transactional(readOnly=true)
	public Account findById(String id) {
		Record queryResult = accountGateway.retrieve(id);
		
		if(queryResult!=null){
			return accountFactory.make(queryResult,Account.class);
		}else
			throw new DataRetrievalFailureException("User not Found");
	}
	
	/**
	 * Finds by specified ID
	 */
	@Transactional(readOnly=true)
	public Account findNewUser(String id) {
		Record queryResult = accountEntityGateway.retrieveUserWithoutRole(id);
		
		if(queryResult!=null){
			return accountFactory.make(queryResult,Account.class);
		}else
			throw new DataRetrievalFailureException("User not Found");
	}
	
	/**
	 * Updates by specified Account
	 */
	@Transactional
	public Account update(Account account) {
		//encodes the password first.
		account.encodePassword();
		accountGateway.update(account.getUserCd(), accountFactory.createRecord(account));
		//if an account contains role update it as well.
		if(account.containsRole()){
			rolesGateway.update(account.getUserCd(), rolesFactory.createRecord(account.getAuthority()));
		}
		return findById(account.getUserCd());
	}
	
	/**
	 * Updates by specified Account
	 */
	@Transactional
	public void updateLoginFlag(Account account) {
		//encodes the password first.
		account.encodePassword();
		accountEntityGateway.updateLoginFlag(account.getUserCd(),account.getLoginFlag(),accountFactory.createRecord(account));
		//if an account contains role update it as well.
	}
	
	/**
	 * Fetch by Condition
	 */
	@Transactional(readOnly=true)
	public List<Account> findUsingCondition(Condition condition) {
		List<Record> queryResults = accountGateway.retrieve(condition);
		
		List<Account> accounts = new ArrayList<Account>();
		for(Record queryResult:queryResults){
			accounts.add(accountFactory.make(queryResult, Account.class));
		}
		if(accounts.size() > 0){
			return accounts;
		}else
			throw new DataRetrievalFailureException("Users not Found"); 
	}
	
	
}
