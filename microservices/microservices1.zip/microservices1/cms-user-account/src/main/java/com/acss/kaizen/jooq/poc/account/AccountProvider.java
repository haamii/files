package com.acss.kaizen.jooq.poc.account;

import org.jooq.DSLContext;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.acss.kaizen.jooq.poc.base.EntityProviderFactory;
import com.acss.kaizen.jooq.poc.db.tables.MCollectionAccount;
import com.acss.kaizen.jooq.poc.db.tables.records.MCollectionAccountRecord;


/**
 * A Factory class which provides various ways of creating and returning
 * Account and Account Record Type instance.
 * 
 * @author gvargas
 *
 */
@Component
public class AccountProvider extends EntityProviderFactory<Account, MCollectionAccountRecord, Long,MCollectionAccount>{

	@Autowired
	public AccountProvider(ModelMapper modelMapper, DSLContext jooq) {
		super(modelMapper, jooq);
	}

	@Override
	public void init() {
		setInstances(MCollectionAccount.class,MCollectionAccountRecord.class);
	}
	
}
