package com.acss.kaizen.jooq.poc.passwordreset;

import static com.acss.kaizen.jooq.poc.db.tables.TPasswordresettoken.T_PASSWORDRESETTOKEN;

import java.util.List;

import org.jooq.Condition;
import org.jooq.DSLContext;
import org.jooq.Record;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.acss.kaizen.jooq.poc.base.DomainGateway;
import com.acss.kaizen.jooq.poc.db.tables.records.TPasswordresettokenRecord;

@Component
public class PasswordResetTokenGateway implements DomainGateway<Integer,TPasswordresettokenRecord>{

	private final DSLContext jooq;
	
	@Autowired
	public PasswordResetTokenGateway(DSLContext jooq){
		this.jooq = jooq;
	}
	
	
	public Record retrieve(Integer key) {
		return jooq.select(T_PASSWORDRESETTOKEN.fields())
				.from(T_PASSWORDRESETTOKEN)
				.where(T_PASSWORDRESETTOKEN.ID
						.eq(key)).fetchOne();
	}

	
	public List<Record> retrieve() {
		return jooq.select(T_PASSWORDRESETTOKEN.fields())
				.from(T_PASSWORDRESETTOKEN).fetch();
	}

	
	public List<Record> retrieve(int limit) {
		return null;
	}

	
	public TPasswordresettokenRecord persist(TPasswordresettokenRecord data) {
		return jooq.insertInto(T_PASSWORDRESETTOKEN).set(data).returning().fetchOne();
	}

	
	public void update(Integer key, Record data) {
	}

	
	public void delete(Integer key) {
		jooq.delete(T_PASSWORDRESETTOKEN)
		.where(T_PASSWORDRESETTOKEN.ID.eq(key))
		.execute();
	}

	
	public List<Record> retrieve(Condition condition) {
		return jooq.select(T_PASSWORDRESETTOKEN.fields())
				.from(T_PASSWORDRESETTOKEN)
				.where(condition).fetch();
	}

}
