package com.acss.kaizen.jooq.poc.base;

import java.math.BigDecimal;


/**
 * Base Entity Class
 * @author gvargas
 * @param <TKey> - the unique key.
 */
public class BaseEntity <TKey>{
	
	protected TKey id;

	private String crePerson;
	private String creProId;
	private BigDecimal creDate;
	private BigDecimal creTime;
	private String updPerson;
	private String updProId;
	private BigDecimal updDate;
	private BigDecimal updTime;
	private BigDecimal delflag;
	private BigDecimal updCnt;
	
	
	public TKey getId() {
		return id;
	}

	public void setId(TKey id) {
		this.id = id;
	}
	
	/**
     * Indicates if the entity needs updating or inserting.
     * when id is present it is for update otherwise it's for insert
     * @return boolean
     */
	public boolean isNew(){
		return (this.id == null);
	}

	public String getCrePerson() {
		return crePerson;
	}

	public void setCrePerson(String crePerson) {
		this.crePerson = crePerson;
	}

	public String getCreProId() {
		return creProId;
	}

	public void setCreProId(String creProId) {
		this.creProId = creProId;
	}

	public BigDecimal getCreDate() {
		return creDate;
	}

	public void setCreDate(BigDecimal creDate) {
		this.creDate = creDate;
	}

	public BigDecimal getCreTime() {
		return creTime;
	}

	public void setCreTime(BigDecimal creTime) {
		this.creTime = creTime;
	}

	public String getUpdPerson() {
		return updPerson;
	}

	public void setUpdPerson(String updPerson) {
		this.updPerson = updPerson;
	}

	public String getUpdProId() {
		return updProId;
	}

	public void setUpdProId(String updProId) {
		this.updProId = updProId;
	}

	public BigDecimal getUpdDate() {
		return updDate;
	}

	public void setUpdDate(BigDecimal updDate) {
		this.updDate = updDate;
	}

	public BigDecimal getUpdTime() {
		return updTime;
	}

	public void setUpdTime(BigDecimal updTime) {
		this.updTime = updTime;
	}

	public BigDecimal getDelflag() {
		return delflag;
	}

	public void setDelflag(BigDecimal delflag) {
		this.delflag = delflag;
	}

	public BigDecimal getUpdCnt() {
		return updCnt;
	}

	public void setUpdCnt(BigDecimal updCnt) {
		this.updCnt = updCnt;
	}
	
	
	
	
}
