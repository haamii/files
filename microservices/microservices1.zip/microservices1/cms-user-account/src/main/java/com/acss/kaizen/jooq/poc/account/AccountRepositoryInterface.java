package com.acss.kaizen.jooq.poc.account;

public interface AccountRepositoryInterface {
	public void updateLoginFlag(Account account);
}
