package com.acss.kaizen.jooq.poc.account.constants;

public enum AccountStatus {
	ACTIVE(1,"Active"),EXPIRED(2,"Expired"),LOCKED(3,"Locked");
	
	private int code;
	private String value;
	
	AccountStatus(int code,String value){
		this.code = code;
		this.value = value;
		BootstrapSingleton.lookupByValue.put(value, this);
		BootstrapSingleton.lookupByCode.put(new Integer(code), this);
	}
	
	public int getCode(){
		return code;
	}
	
	public String getValue(){
		return value;
	}
	
	public static AccountStatus getByValue(String value){
		return BootstrapSingleton.lookupByValue.get(value);
	}
	
	public static AccountStatus getByCode(int code){
		return BootstrapSingleton.lookupByCode.get(new Integer(code));
	}
	
}
