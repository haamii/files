package com.acss.kaizen.jooq.poc.configuration;

import java.math.BigDecimal;
import java.util.Properties;

import javax.sql.DataSource;

import org.jooq.SQLDialect;
import org.jooq.conf.Settings;
import org.jooq.impl.DataSourceConnectionProvider;
import org.jooq.impl.DefaultConfiguration;
import org.jooq.impl.DefaultDSLContext;
import org.jooq.impl.DefaultExecuteListenerProvider;
import org.modelmapper.AbstractConverter;
import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.NameTokenizers;
import org.modelmapper.jooq.RecordValueReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.LazyConnectionDataSourceProxy;
import org.springframework.jdbc.datasource.TransactionAwareDataSourceProxy;
import org.springframework.jdbc.datasource.init.DataSourceInitializer;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.crypto.password.StandardPasswordEncoder;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.acss.kaizen.jooq.poc.account.constants.AccountStatus;
import com.acss.kaizen.jooq.poc.configuration.exception.JOOQToSpringExceptionTransformer;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;


/**
 * Persistent Configuration Class.
 * @author gvargas.local
 */
@Configuration
@ComponentScan({"com.acss.kaizen.jooq.poc"})
@EnableTransactionManagement
@PropertySource("classpath:application.properties")
public class PersistenceContext {

	private static final String PROPERTY_NAME_DB_DRIVER = "db.driver";
    private static final String PROPERTY_NAME_DB_PASSWORD = "db.password";
//    private static final String PROPERTY_NAME_DB_SCHEMA_SCRIPT = "db.schema.script";
//    private static final String PROPERTY_NAME_DB_DATA_SCRIPT = "db.data.script";
    private static final String PROPERTY_NAME_DB_URL = "db.url";
    private static final String PROPERTY_NAME_DB_USERNAME = "db.username";
    private static final String PROPERTY_NAME_DB_DATASOURCECLASSNAME = "db.dataSourceClassName";
    private static final String PROPERTY_NAME_JOOQ_SQL_DIALECT = "jooq.sql.dialect";
    
    private static final String PROPERTY_NAME_MAXPOOL = "db.maximumPoolSize";
    private static final String PROPERTY_NAME_MIN_IDLE = "db.minimumIdle";
    private static final String PROPERTY_NAME_CONNECTIONTIMEOUT = "db.connectionTimeout";
    private static final String PROPERTY_NAME_IDLETIMEOUT = "db.idleTimeout";

    
    
    @Autowired
    private Environment env;
    
    @Bean(destroyMethod = "close")
    public DataSource dataSource() {

		Properties dsProps = new Properties();
		dsProps.put("url", env.getRequiredProperty(PROPERTY_NAME_DB_URL));
		dsProps.put("user", env.getRequiredProperty(PROPERTY_NAME_DB_USERNAME));
		dsProps.put("password", env.getRequiredProperty(PROPERTY_NAME_DB_PASSWORD));
		
		Properties configProps = new Properties();
		configProps.put("dataSourceClassName",env.getRequiredProperty(PROPERTY_NAME_DB_DATASOURCECLASSNAME));
		configProps.put("poolName","SpringBootHikariCP");
		configProps.put("maximumPoolSize",env.getRequiredProperty(PROPERTY_NAME_MAXPOOL));
		configProps.put("minimumIdle",env.getRequiredProperty(PROPERTY_NAME_MIN_IDLE));
		configProps.put("connectionTimeout", env.getRequiredProperty(PROPERTY_NAME_CONNECTIONTIMEOUT));
		configProps.put("idleTimeout", env.getRequiredProperty(PROPERTY_NAME_IDLETIMEOUT));
		configProps.put("dataSourceProperties", dsProps);
		   
		HikariConfig hc = new HikariConfig(configProps);
		HikariDataSource ds = new HikariDataSource(hc);
		   
		ds.setDriverClassName(env.getRequiredProperty(PROPERTY_NAME_DB_DRIVER));
		ds.setJdbcUrl(env.getRequiredProperty(PROPERTY_NAME_DB_URL));
		ds.setUsername(env.getRequiredProperty(PROPERTY_NAME_DB_USERNAME));
		ds.setPassword(env.getRequiredProperty(PROPERTY_NAME_DB_PASSWORD));
		    
		ds.addDataSourceProperty("cachePrepStmts", true);
		ds.addDataSourceProperty("prepStmtCacheSize", 250);
		ds.addDataSourceProperty("prepStmtCacheSqlLimit", 2048);
		ds.addDataSourceProperty("useServerPrepStmts", true);
       
        return ds;
    }

    @Bean
    public LazyConnectionDataSourceProxy lazyConnectionDataSource() {
        return new LazyConnectionDataSourceProxy(dataSource());
    }

    @Bean
    public TransactionAwareDataSourceProxy transactionAwareDataSource() {
        return new TransactionAwareDataSourceProxy(lazyConnectionDataSource());
    }

    @Bean
    public DataSourceTransactionManager transactionManager() {
        return new DataSourceTransactionManager(lazyConnectionDataSource());
    }

    @Bean
    public DataSourceConnectionProvider connectionProvider() {
        return new DataSourceConnectionProvider(transactionAwareDataSource());
    }

    @Bean
    public JOOQToSpringExceptionTransformer jooqToSpringExceptionTransformer() {
        return new JOOQToSpringExceptionTransformer();
    }

    @Bean
    public DefaultConfiguration configuration() {
        DefaultConfiguration jooqConfiguration = new DefaultConfiguration();

        jooqConfiguration.set(connectionProvider());
        jooqConfiguration.set(new DefaultExecuteListenerProvider(
            jooqToSpringExceptionTransformer()
        ));

        String sqlDialectName = env.getRequiredProperty(PROPERTY_NAME_JOOQ_SQL_DIALECT);
        SQLDialect dialect = SQLDialect.valueOf(sqlDialectName);
        jooqConfiguration.set(dialect);
        jooqConfiguration.set(new Settings().withRenderFormatted(true));
        
        return jooqConfiguration;
    }

    @Bean
    public DefaultDSLContext dsl() {
        return new DefaultDSLContext(configuration());
    }
    
    @Bean
    public ModelMapper modelMapper(){
    	ModelMapper modelMapper = new ModelMapper();
    	
    	modelMapper.getConfiguration().addValueReader(new RecordValueReader());
    	modelMapper.getConfiguration().setSourceNameTokenizer(NameTokenizers.UNDERSCORE);
    	//Adds custom converters to modelMapper
    	addCustomConvertersToModelMapper(modelMapper);

    	return modelMapper;
    }
    
//	@Bean
//    public DataSourceInitializer dataSourceInitializer() {
//        DataSourceInitializer initializer = new DataSourceInitializer();
//        initializer.setDataSource(dataSource());
//
//        ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
//        populator.addScript(
//                new ClassPathResource(env.getRequiredProperty(PROPERTY_NAME_DB_SCHEMA_SCRIPT))
//        );
//        populator.addScript(
//        		new ClassPathResource(env.getRequiredProperty(PROPERTY_NAME_DB_DATA_SCRIPT)));
//
//        initializer.setDatabasePopulator(populator);
//        return initializer;
//    }
//    
    @Bean
    public PasswordEncoder passwordEncoder(){
    	return new StandardPasswordEncoder();
    }
    
    /**
     * adds Customized Converters to modelMapper.
     * Temporarily added in Config Class because I have not yet thought of a place to do so.
     * @param modelMapper
     */
    private void addCustomConvertersToModelMapper(ModelMapper modelMapper) {
    	//A Custom Mapper for AccountStatus into Integer
    	Converter<AccountStatus, BigDecimal> accountStatusToInteger = new AbstractConverter<AccountStatus, BigDecimal>() {
			  @Override
			  protected BigDecimal convert(AccountStatus source) {
			    return source == null ? null : new BigDecimal(source.getCode());
			  }
		};
    	//A Custom Mapper for Integer to AccountStatus
    	Converter<BigDecimal, AccountStatus> integerToAccountStatus = new AbstractConverter<BigDecimal, AccountStatus>() {
			  @Override
			  protected AccountStatus convert(BigDecimal source) {
			    return source == null ? null : AccountStatus.getByCode(source.intValue());
			  }
		};
    	
		//add the converted for AccountStatus into Integer
		modelMapper.addConverter(accountStatusToInteger);
		modelMapper.addConverter(integerToAccountStatus);
		
	}
    
}
