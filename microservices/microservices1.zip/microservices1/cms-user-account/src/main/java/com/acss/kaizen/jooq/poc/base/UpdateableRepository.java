package com.acss.kaizen.jooq.poc.base;

/**
 * The Generic DAO Interface for Updateable / Transactional Repo
 * @author gvargas
 * @param T - The Aggregate root Class.
 * @param Tkey - The key of the Aggregate root Class
 */
public interface UpdateableRepository<T,Tkey> extends ReadOnlyRepository<T, Tkey>{
	public T add(T account);
	public T delete(Tkey id);
	public T update(T account);
	
}
