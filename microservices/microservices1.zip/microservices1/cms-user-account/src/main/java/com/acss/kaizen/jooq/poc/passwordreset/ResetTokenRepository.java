package com.acss.kaizen.jooq.poc.passwordreset;

import java.util.ArrayList;
import java.util.List;

import org.jooq.Condition;
import org.jooq.Record;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.stereotype.Repository;

import com.acss.kaizen.jooq.poc.base.DomainFactory;
import com.acss.kaizen.jooq.poc.base.DomainGateway;
import com.acss.kaizen.jooq.poc.base.UpdateableRepository;
import com.acss.kaizen.jooq.poc.db.tables.records.TPasswordresettokenRecord;

@Repository
public class ResetTokenRepository implements UpdateableRepository<ResetToken,Integer>{
	
	private final DomainGateway<Integer,TPasswordresettokenRecord> resetTokenGateway;
	private final DomainFactory<ResetToken,TPasswordresettokenRecord> resetTokenFactory;
	
	@Autowired
	public ResetTokenRepository(DomainGateway<Integer,TPasswordresettokenRecord> resetTokenGateway,
			DomainFactory<ResetToken,TPasswordresettokenRecord> resetTokenFactory){
		this.resetTokenGateway = resetTokenGateway;
		this.resetTokenFactory = resetTokenFactory;
	}
	
	public List<ResetToken> findAll() {
		List<Record> queryResults = resetTokenGateway.retrieve();
		
		List<ResetToken> tokens = new ArrayList<ResetToken>();
		for(Record queryResult:queryResults){
			tokens.add(resetTokenFactory.make(queryResult, ResetToken.class));
		}
		if(tokens.size() > 0){
			return tokens;
		}else
			throw new DataRetrievalFailureException("Tokens not Found");
	}

	public ResetToken findById(Integer id) {
		Record queryResult = resetTokenGateway.retrieve(id);
		if(queryResult!=null){
			return resetTokenFactory.make(queryResult,ResetToken.class);
		}else
			throw new DataRetrievalFailureException("Token not Found");
	}

	public List<ResetToken> findUsingCondition(Condition condition) {
		List<Record> queryResults = resetTokenGateway.retrieve(condition);
		List<ResetToken> tokens = new ArrayList<ResetToken>();
		for(Record queryResult:queryResults){
			tokens.add(resetTokenFactory.make(queryResult, ResetToken.class));
		}
		if(tokens.size() > 0){
			return tokens;
		}else
			throw new DataRetrievalFailureException("Tokens not Found");
	}

	public ResetToken add(ResetToken token) {
		TPasswordresettokenRecord newToken = resetTokenGateway.persist(resetTokenFactory.createRecord(token));
		return findById(newToken.getId());
	}

	public ResetToken delete(Integer id) {
		ResetToken deletedToken = findById(id);
		resetTokenGateway.delete(id);
		return deletedToken;
	}

	public ResetToken update(ResetToken account) {
		return null;
	}
	
}
