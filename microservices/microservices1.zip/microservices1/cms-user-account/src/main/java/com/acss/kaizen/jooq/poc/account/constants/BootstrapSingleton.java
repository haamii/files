package com.acss.kaizen.jooq.poc.account.constants;

import java.util.HashMap;
import java.util.Map;

public final class BootstrapSingleton{

	public static final Map<String,AccountStatus> lookupByValue = new HashMap<String,AccountStatus>();
	public static final Map<Integer,AccountStatus> lookupByCode = new HashMap<Integer,AccountStatus>();
}
