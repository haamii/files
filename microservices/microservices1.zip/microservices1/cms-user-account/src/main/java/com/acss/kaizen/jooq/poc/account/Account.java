package com.acss.kaizen.jooq.poc.account;

import java.math.BigDecimal;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.crypto.password.StandardPasswordEncoder;
import org.springframework.stereotype.Component;

import com.acss.kaizen.jooq.poc.account.constants.AccountStatus;
import com.acss.kaizen.jooq.poc.base.BaseEntity;
import com.acss.kaizen.jooq.poc.role.UserRole;

/**
 * The Aggregate root for Account.
 *
 *
 */
@Component
public class Account extends BaseEntity<Long>{

	private String usercd;
	private String password;
	private String confirmPassword;
	private String name;
	private String email;
	private String storeCd;
	private BigDecimal loginFlag;
	private BigDecimal bucket;
	
	private UserRole authority;
	private AccountStatus status;
	
	private PasswordEncoder utility;
	
    public Account() {
    	utility = new StandardPasswordEncoder();
    }
	
	
	public boolean containsRole(){
		return (this.authority!=null);
	}
	
	/**
	 * Add a new role by appending on the comma delimited role value.
	 * @param newRole
	 */
	public void addRole(String newRole){
		StringBuilder builder = new StringBuilder(this.authority.getRole());
		builder.append(",");
		builder.append(newRole);
		this.authority.setRole(builder.toString());
	}
	/**
	 * Encodes the password using the implementation : {@link StandardPasswordEncoder}
	 */
	public void encodePassword(){
		if(password!=null){
			this.password = utility.encode(password);
		}
	}
	
    public BigDecimal getLoginFlag() {
		return loginFlag;
	}

	public void setLoginFlag(BigDecimal loginFlag) {
		this.loginFlag = loginFlag;
	}
		
    public String getUserCd() {
		return usercd;
	}

	public void setUserCd(String usercd) {
		this.usercd = usercd;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
	public String getConfirmPassword() {
		return confirmPassword;
	}


	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public UserRole getAuthority() {
		return authority;
	}

	public void setAuthority(UserRole authority) {
		this.authority = authority;
	}

	public AccountStatus getStatus() {
		return status;
	}

	public void setStatus(AccountStatus status) {
		this.status = status;
	}


	public String getStoreCd() {
		return storeCd;
	}


	public void setStoreCd(String storeCd) {
		this.storeCd = storeCd;
	}
	
	
	public BigDecimal getBucket() {
		return bucket;
	}

	public void setBucket(BigDecimal bucket) {
		this.bucket = bucket;
	}
	
}
