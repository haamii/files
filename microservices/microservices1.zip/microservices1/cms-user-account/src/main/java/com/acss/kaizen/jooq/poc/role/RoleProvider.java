package com.acss.kaizen.jooq.poc.role;

import org.jooq.DSLContext;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.acss.kaizen.jooq.poc.base.EntityProviderFactory;
import com.acss.kaizen.jooq.poc.db.tables.MAccountRoles;
import com.acss.kaizen.jooq.poc.db.tables.records.MAccountRolesRecord;

@Component
public class RoleProvider extends EntityProviderFactory<UserRole, MAccountRolesRecord, Long,MAccountRoles> {
	
	@Autowired
	public RoleProvider(ModelMapper modelMapper, DSLContext jooq) {
		super(modelMapper, jooq);
	}

	@Override
	public void init() {
		setInstances(MAccountRoles.class, MAccountRolesRecord.class);
	}
}
