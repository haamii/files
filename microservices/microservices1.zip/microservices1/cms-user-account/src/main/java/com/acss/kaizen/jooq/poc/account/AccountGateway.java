package com.acss.kaizen.jooq.poc.account;

import static com.acss.kaizen.jooq.poc.db.tables.MAccountRoles.M_ACCOUNT_ROLES;
import static com.acss.kaizen.jooq.poc.db.tables.MCollectionAccount.M_COLLECTION_ACCOUNT;
import static com.acss.kaizen.jooq.poc.db.tables.MAccount.M_ACCOUNT;

import java.math.BigDecimal;
import java.util.List;

import org.jooq.Condition;
import org.jooq.DSLContext;
import org.jooq.Field;
import org.jooq.Record;
import org.jooq.Record1;
import org.jooq.Record2;
import org.jooq.Result;
import org.jooq.SelectJoinStep;
import org.jooq.impl.DSL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.acss.kaizen.jooq.poc.base.DomainGateway;
import com.acss.kaizen.jooq.poc.db.tables.records.MCollectionAccountRecord;

/**
 * The persistent layer used by the Account Repository.
 * @author gvargas
 *
 */
@Component
public class AccountGateway implements DomainGateway<String,MCollectionAccountRecord> {

	private final DSLContext jooq;
	
	@Autowired
	public AccountGateway(DSLContext jooq){
		this.jooq = jooq;
	}
	
	Field<String> NAME = DSL.val("NAME");
	
	/**
	 * Queries for retrieving account.
	 * the common statement.
	 * @return SelectJoinStep<Record>
	 */
	private SelectJoinStep<Record> selectAccount(){
		
		return //jooq.select(M_COLLECTION_ACCOUNT.fields())
				jooq.select(M_COLLECTION_ACCOUNT.USERCD)
					.select(M_COLLECTION_ACCOUNT.NAME)
					.select(M_COLLECTION_ACCOUNT.PASSWORD)
					.select(M_COLLECTION_ACCOUNT.PWDEXPIREDATE)
					.select(M_COLLECTION_ACCOUNT.BRANCHNM)
					.select(M_COLLECTION_ACCOUNT.DELFLAG)
					.select(M_COLLECTION_ACCOUNT.CREPERSON)
					.select(M_COLLECTION_ACCOUNT.CREDATE)
					.select(M_COLLECTION_ACCOUNT.CRETIME)
					.select(M_COLLECTION_ACCOUNT.CREPROID)
					.select(M_COLLECTION_ACCOUNT.UPDPERSON)
					.select(M_COLLECTION_ACCOUNT.UPDDATE)
					.select(M_COLLECTION_ACCOUNT.UPDTIME)
					.select(M_COLLECTION_ACCOUNT.UPDPROID)
					.select(M_COLLECTION_ACCOUNT.UPDCNT)
					.select(M_COLLECTION_ACCOUNT.LOGINFLAG)
					.select(DSL.nvl(M_COLLECTION_ACCOUNT.BUCKET, 100).as("BUCKET")) //default is 100 instead of null
					.select(M_COLLECTION_ACCOUNT.TEAMID)
		//The alias actually is for the field mapping from record to POJO
		//.select(M_ACCOUNT_ROLES.ACCOUNTID.as("ACCOUNT_AUTHORITY_ACCOUNTID"))
		.select(M_ACCOUNT_ROLES.ROLE.as("ACCOUNT_AUTHORITY_ROLE"))
		.select(M_ACCOUNT_ROLES.USERCD.as("ACCOUNT_AUTHORITY_USERNAME"))
		
		.from(M_COLLECTION_ACCOUNT.join(M_ACCOUNT_ROLES)
		.on(M_COLLECTION_ACCOUNT.USERCD.equal(M_ACCOUNT_ROLES.USERCD)));
	}
	
	/**
	 * Queries for retrieving account.
	 * the common statement.
	 * @return SelectJoinStep<Record>
	 */
	private SelectJoinStep<Record> selectAccountWithoutRole(){
		
		return jooq.select(M_COLLECTION_ACCOUNT.fields())
		.from(M_COLLECTION_ACCOUNT);
		
	}
	
	/**
	 * retrieveSummary - retrieves Summary based on selected branch
	 * 
	 */
	public Result<Record1<String>> selectUnregisterdCollectionAccount() {
		return jooq.select(M_COLLECTION_ACCOUNT.USERCD)
				.from(M_COLLECTION_ACCOUNT)
				.where(M_COLLECTION_ACCOUNT.USERCD.isNotNull())
				.fetch();
	}
	
	
	
	/**
	 * Retrieves a single record using id as parameter
	 */
	public Record retrieve(String usercd) {
		
		return selectAccount()
				.where(M_COLLECTION_ACCOUNT.USERCD.equal(usercd))
				.fetchOne();
	}
	
	/**
	 * Retrieves a single record using id as parameter
	 */
	public Record retrieveUserWithoutRole(String usercd) {
		
		return selectAccountWithoutRole()
				.where(M_COLLECTION_ACCOUNT.USERCD.equal(usercd))
				.fetchOne();
	}
	
	
	/**
	 * Retrieves a single record using id as parameter
	 */
	public List<Record> retrieveUnregisteredHPSUser() {
		
		return jooq.select(M_ACCOUNT.USERCD)
					.select(M_ACCOUNT.USERNAME.as("NAME"))
					.from(M_ACCOUNT)
					.where(M_ACCOUNT.USERCD.notIn(selectUnregisterdCollectionAccount())
					.and(M_ACCOUNT.GROUPCODE.in("007","006")))
					.and(M_ACCOUNT.DELFLAG.eq((byte) 0))
					.fetch();
	}
	
	/**
	 * Retrieves all record
	 */
	public List<Record> retrieve() {
		return selectAccount()
				.fetch();
	}
	
	/**
	 * Retrieves with a limit provided
	 */
	public List<Record> retrieve(int max) {
		return selectAccount()
				.limit(max)
				.fetch();
	}
	
	/**
	 * Updates a single record specified by id
	 */
	public void update(String usercd,Record data) {
		jooq.update(M_COLLECTION_ACCOUNT)
		.set(data)
		.where(M_COLLECTION_ACCOUNT.USERCD.equal(usercd)).execute();
	}
	
	/**
	 * Updates a single record loginflag
	 */
	public void updateLoginFlag(String usercd,BigDecimal loginflag,Record data) {	
		jooq.update(M_COLLECTION_ACCOUNT)
		.set(M_COLLECTION_ACCOUNT.LOGINFLAG,(byte)loginflag.intValue())
		.where(M_COLLECTION_ACCOUNT.USERCD.equal(usercd)).execute();
	}
	
	/**
	 * Deletes a single record specified by id
	 */
	public void delete(String usercd) {
		jooq.delete(M_COLLECTION_ACCOUNT)
		.where(M_COLLECTION_ACCOUNT.USERCD.equal(usercd))
		.execute();
	}
	
	/**
	 * Saves a record using the record equivalent (jooq generated) domain object
	 * @return 
	 */
	public MCollectionAccountRecord persist(MCollectionAccountRecord data) {
		return jooq.insertInto(M_COLLECTION_ACCOUNT).set(data).returning().fetchOne();
	}

	public List<Record> retrieve(Condition condition) {
		return selectAccount().where(condition).fetch();
	}

}
