package com.acss.kaizen.jooq.poc.passwordreset;

import org.jooq.DSLContext;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.acss.kaizen.jooq.poc.base.EntityProviderFactory;
import com.acss.kaizen.jooq.poc.db.tables.TPasswordresettoken;
import com.acss.kaizen.jooq.poc.db.tables.records.TPasswordresettokenRecord;

@Component
public class PasswordResetTokenProvider extends EntityProviderFactory<ResetToken,TPasswordresettokenRecord,Integer,TPasswordresettoken>{
	@Autowired
	public PasswordResetTokenProvider(ModelMapper modelMapper, DSLContext jooq) {
		super(modelMapper, jooq);
	}

	public void init() {
		setInstances(TPasswordresettoken.class, TPasswordresettokenRecord.class);	
	}
}
