package com.acss.kaizen.jooq.poc.role;

import com.acss.kaizen.jooq.poc.base.BaseEntity;

/**
 * Role/s Entity of an Account.
 * @author gvargas
 *
 */
public class UserRole extends BaseEntity<Long>{
	
	private String username;
	private String role;
	private Long accountId;
	
	public UserRole(){}
	
	public UserRole(String username, String role,Long accountId) {
		this.username = username;
		this.role = role;
		this.accountId = accountId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getAuthority() {
		return role;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
	public Long getAccountId() {
		return accountId;
	}

	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}
	
}
