com.acss.core.orm
=================

The base artifact needed by the archetype-repository to generate / quickstart repository development.
