package com.acss.core.orm;

import java.util.List;

import org.jooq.Condition;

/**
 * The Generic DAO Interface for Read-only Repository
 * @author gvargas
 * @param T - The Aggregate root Class.
 * @param Tkey - The key of the Aggregate root Class
 */
public interface ReadOnlyRepository<T,TKey> {
	
	/**
	 * Finds all Records
	 * @return List of Entity.
	 */
	public List<T> findAll();
	/**
	 * Finds Record by Unique Id.
	 * @param id
	 * @return Entity.
	 */
	public T findById(TKey id);
	/**
	 * Finds Records based on the defined condition
	 * @param condition
	 * @return List of Entity.
	 */
	public List<T> findUsingCondition(Condition condition);
}
