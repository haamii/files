package com.acss.core.orm;

import org.jooq.DSLContext;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * A simple gateway implementation for simple CRUD method only applicable for
 * a table.
 * This could be use for entities but fetch method should be avoided if it's an internal part
 * of an aggregate.
 * 
 * 
 * @author gvargas
 *
 * @param <TKey>
 * 
 * @param <TRECORD>
 */
public abstract class BasicGatewayImpl<TKey
		, TRECORD extends org.jooq.impl.UpdatableRecordImpl<TRECORD>>
		implements DomainGateway<TKey, TRECORD> {
	
	@Autowired
	protected DSLContext jooq;
		
	/**
	 * Updates a single record specified by id
	 */
	public void update(TRECORD data) {
		jooq.attach(data);
		data.update();
	}
	
	/**
	 * Deletes a single record specified by id
	 */
	public void delete(TRECORD data) {
		//attached with the currently define context.
		jooq.attach(data);
		//delete the record
		data.delete();
	}
	
	/**
	 * Persist a single record
	 */
	public TRECORD persist(TRECORD data) {
		//attached with the currently define context.
		jooq.attach(data);
		data.store();
		return data;
	}
}
