package com.acss.core.model.deskcontact;

public class PaymentRejectModel {
	
	private String agreementCd;
	private String emi;
	private String remark;
	private String returnRemark;
	
	public final static String MODEL_ATTRIB_KEY = "paymentReject";
	
	public PaymentRejectModel(){}

	public String getAgreementCd() {
		return agreementCd;
	}

	public void setAgreementCd(String agreementCd) {
		this.agreementCd = agreementCd;
	}

	public String getEmi() {
		return emi;
	}

	public void setEmi(String emi) {
		this.emi = emi;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getReturnRemark() {
		return returnRemark;
	}

	public void setReturnRemark(String returnRemark) {
		this.returnRemark = returnRemark;
	}	
	

}
