package com.acss.core.model.feedbackreport;

public class FeedbackResultModel {
	
	private String agreementCd;
	private String contactresult;
	private String comments;
	private String credate;
	
	/**
	 * @return the agreementCd
	 */
	public String getAgreementCd() {
		return agreementCd;
	}
	/**
	 * @param agreementCd the agreementCd to set
	 */
	public void setAgreementCd(String agreementCd) {
		this.agreementCd = agreementCd;
	}

	/**
	 * @return the contactresult
	 */
	public String getContactresult() {
		return contactresult;
	}
	/**
	 * @param contactresult the contactresult to set
	 */
	public void setContactresult(String contactresult) {
		this.contactresult = contactresult;
	}
	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}
	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}
	/**
	 * @return the credate
	 */
	public String getCredate() {
		return credate;
	}
	/**
	 * @param credate the credate to set
	 */
	public void setCredate(String credate) {
		this.credate = credate;
	}
	
}
