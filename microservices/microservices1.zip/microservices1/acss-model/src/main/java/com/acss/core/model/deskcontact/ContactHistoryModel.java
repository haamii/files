package com.acss.core.model.deskcontact;

public class ContactHistoryModel {

	private String agreementCd;
	private String credate;
	private String comments;
	private String type;
	private String contactResult;
	
	public final static String MODEL_ATTRIB_KEY = "contactHistory";

	public ContactHistoryModel() {}

	public String getAgreementCd() {
		return agreementCd;
	}

	public void setAgreementCd(String agreementCd) {
		this.agreementCd = agreementCd;
	}

	public String getCredate() {
		return credate;
	}

	public void setCredate(String credate) {
		this.credate = credate;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getContactResult() {
		return contactResult;
	}

	public void setContactResult(String contactResult) {
		this.contactResult = contactResult;
	}

}
