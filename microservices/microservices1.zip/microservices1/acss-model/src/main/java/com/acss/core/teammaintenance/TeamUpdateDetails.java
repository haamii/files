package com.acss.core.teammaintenance;

import java.util.List;

import com.acss.core.model.BaseEntity;

public class TeamUpdateDetails extends BaseEntity{
	
	private Integer teamID;
	private String teamName;
	private String name;
	private String userCd;
	private Integer bucket;
	private String collectorType;
	private Integer status;
	private String branchnm;
	private Integer agencyCode;
	private String areaGroup;
	private String collectors;
	private String bucketEdit;
	private String collectorTypeEdit;
	private List<String> collectorList;
	private List<AreaGroup> areaList;
	private List<Collector> teamCollector;
	private List<String> existingAreas;
	private List<String> existingCollectors;
	
	public static final String UPDATE_MODEL_ATTRIB_KEY = "updateTeamDetails";

	/**
	 * @return the areaList
	 */
	public List<AreaGroup> getAreaList() {
		return areaList;
	}
	/**
	 * @param areaList the areaList to set
	 */
	public void setAreaList(List<AreaGroup> areaList) {
		this.areaList = areaList;
	}
	/**
	 * @return the teamCollector
	 */
	public List<Collector> getTeamCollector() {
		return teamCollector;
	}
	/**
	 * @param teamCollector the teamCollector to set
	 */
	public void setTeamCollector(List<Collector> teamCollector) {
		this.teamCollector = teamCollector;
	}
	/**
	 * @return the teamID
	 */
	public Integer getTeamID() {
		return teamID;
	}
	/**
	 * @param teamID the teamID to set
	 */
	public void setTeamID(Integer teamID) {
		this.teamID = teamID;
	}
	/**
	 * @return the teamName
	 */
	public String getTeamName() {
		return teamName;
	}
	/**
	 * @param teamName the teamName to set
	 */
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	/**
	 * @return the userCd
	 */
	public String getUserCd() {
		return userCd;
	}
	/**
	 * @param userCd the userCd to set
	 */
	public void setUserCd(String userCd) {
		this.userCd = userCd;
	}
	/**
	 * @return the bucket
	 */
	public Integer getBucket() {
		return bucket;
	}
	/**
	 * @param bucket the bucket to set
	 */
	public void setBucket(Integer bucket) {
		this.bucket = bucket;
	}
	/**
	 * @return the status
	 */
	public Integer getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(Integer status) {
		this.status = status;
	}

	/**
	 * @return the branchnm
	 */
	public String getBranchnm() {
		return branchnm;
	}
	/**
	 * @param branchnm the branchnm to set
	 */
	public void setBranchnm(String branchnm) {
		this.branchnm = branchnm;
	}
	/**
	 * @return the agencyCode
	 */
	public Integer getAgencyCode() {
		return agencyCode;
	}
	/**
	 * @param agencyCode the agencyCode to set
	 */
	public void setAgencyCode(Integer agencyCode) {
		this.agencyCode = agencyCode;
	}
	/**
	 * @return the areaGroup
	 */
	public String getAreaGroup() {
		return areaGroup;
	}
	/**
	 * @param areaGroup the areaGroup to set
	 */
	public void setAreaGroup(String areaGroup) {
		this.areaGroup = areaGroup;
	}
	/**
	 * @return the collectorList
	 */
	public List<String> getCollectorList() {
		return collectorList;
	}
	/**
	 * @param collectorList the collectorList to set
	 */
	public void setCollectorList(List<String> collectorList) {
		this.collectorList = collectorList;
	}
	/**
	 * @return the collectors
	 */
	public String getCollectors() {
		return collectors;
	}
	/**
	 * @param collectors the collectors to set
	 */
	public void setCollectors(String collectors) {
		this.collectors = collectors;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the existingAreas
	 */
	public List<String> getExistingAreas() {
		return existingAreas;
	}
	/**
	 * @param existingAreas the existingAreas to set
	 */
	public void setExistingAreas(List<String> existingAreas) {
		this.existingAreas = existingAreas;
	}
	/**
	 * @return the existingCollectors
	 */
	public List<String> getExistingCollectors() {
		return existingCollectors;
	}
	/**
	 * @param existingCollectors the existingCollectors to set
	 */
	public void setExistingCollectors(List<String> existingCollectors) {
		this.existingCollectors = existingCollectors;
	}
	/**
	 * @return the bucketEdit
	 */
	public String getBucketEdit() {
		return bucketEdit;
	}
	/**
	 * @param bucketEdit the bucketEdit to set
	 */
	public void setBucketEdit(String bucketEdit) {
		this.bucketEdit = bucketEdit;
	}
	/**
	 * @return the collectorType
	 */
	public String getCollectorType() {
		return collectorType;
	}
	/**
	 * @param collectorType the collectorType to set
	 */
	public void setCollectorType(String collectorType) {
		this.collectorType = collectorType;
	}
	/**
	 * @return the collectorTypeEdit
	 */
	public String getCollectorTypeEdit() {
		return collectorTypeEdit;
	}
	/**
	 * @param collectorTypeEdit the collectorTypeEdit to set
	 */
	public void setCollectorTypeEdit(String collectorTypeEdit) {
		this.collectorTypeEdit = collectorTypeEdit;
	}
	
}
