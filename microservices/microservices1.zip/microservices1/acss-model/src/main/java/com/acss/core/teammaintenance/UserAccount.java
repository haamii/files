package com.acss.core.teammaintenance;

public class UserAccount {
	
	private String userCd;
	private String name;
	
	/**
	 * @return the userCd
	 */
	public String getUserCd() {
		return userCd;
	}
	/**
	 * @param userCd the userCd to set
	 */
	public void setUserCd(String userCd) {
		this.userCd = userCd;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
}
