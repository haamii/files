package com.acss.core.model.importdata;

public class ContactResultImportDTO {

	private String syscode;
	private String agreementCd;
	private String customerCd;
	private int yearmonth;
	private String date;
	private int code;
	private String remarks;
	private long num;
	private byte type;
	
	public String getSyscode() {
		return syscode;
	}
	public void setSyscode(String syscode) {
		this.syscode = syscode;
	}
	public String getAgreementCd() {
		return agreementCd;
	}
	public void setAgreementCd(String agreementCd) {
		this.agreementCd = agreementCd;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getCustomerCd() {
		return customerCd;
	}
	public void setCustomerCd(String customerCd) {
		this.customerCd = customerCd;
	}
	public int getYearmonth() {
		return yearmonth;
	}
	public void setYearmonth(int yearmonth) {
		this.yearmonth = yearmonth;
	}
	public long getNum() {
		return num;
	}
	public void setNum(long num) {
		this.num = num;
	}
	public byte getType() {
		return type;
	}
	public void setType(byte type) {
		this.type = type;
	}
	
}
