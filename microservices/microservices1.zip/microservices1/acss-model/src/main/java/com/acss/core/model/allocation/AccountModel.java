package com.acss.core.model.allocation;

public class AccountModel {
	
	private int billed;
	private int paid;
	private int allocated;
	private int remaining;
	
	public AccountModel(){
		
	}
	
	public AccountModel(int billed, int paid, int allocated, int remaining) {
		this.billed = billed;
		this.paid = paid;
		this.allocated = allocated;
		this.remaining = remaining;
	}

	/**
	 * @return the billed
	 */
	public int getBilled() {
		return billed;
	}

	/**
	 * @param billed the billed to set
	 */
	public void setBilled(int billed) {
		this.billed = billed;
	}

	/**
	 * @return the paid
	 */
	public int getPaid() {
		return paid;
	}

	/**
	 * @param paid the paid to set
	 */
	public void setPaid(int paid) {
		this.paid = paid;
	}

	/**
	 * @return the allocated
	 */
	public int getAllocated() {
		return allocated;
	}

	/**
	 * @param allocated the allocated to set
	 */
	public void setAllocated(int allocated) {
		this.allocated = allocated;
	}

	/**
	 * @return the remaining
	 */
	public int getRemaining() {
		return remaining;
	}

	/**
	 * @param remaining the remaining to set
	 */
	public void setRemaining(int remaining) {
		this.remaining = remaining;
	}

}
