/**
 * 
 */
package com.acss.core.model.useraccount;

/**
 * User Account Information DTO
 * @author sgalvez
 */
public class UserAccountUpdateDTO {

	private String userCd;
	private String name;
	private String password; 
	private String role;
	private String branchnm;

	public final static String MODEL_ATTRIB_KEY = "userAccountForm";

	public UserAccountUpdateDTO() {
		super();
	}

	public UserAccountUpdateDTO(String userCd, String name, String password, String role, String branchnm) {
		super();
		this.userCd = userCd;
		this.name = name;
		this.password = password;
		this.role = role;
		this.branchnm = branchnm;
	}

	public String getUserCd() {
		return userCd;
	}

	public void setUserCd(String userCd) {
		this.userCd = userCd;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getBranchnm() {
		return branchnm;
	}

	public void setBranchnm(String branchnm) {
		this.branchnm = branchnm;
	}
		
}
