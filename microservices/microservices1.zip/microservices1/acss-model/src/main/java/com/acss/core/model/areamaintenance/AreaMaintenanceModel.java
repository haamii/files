package com.acss.core.model.areamaintenance;

import java.math.BigDecimal;


public class AreaMaintenanceModel {
	
	private BigDecimal postid;
	private String postcode;
	private String citynm;
	private String areanm;
	private String districtnm;
	private String branchnm;
	private String area;
	private BigDecimal postidassigned;
	/**
	 * @return the postid
	 */
	public BigDecimal getPostid() {
		return postid;
	}
	/**
	 * @param postid the postid to set
	 */
	public void setPostid(BigDecimal postid) {
		this.postid = postid;
	}
	/**
	 * @return the postcode
	 */
	public String getPostcode() {
		return postcode;
	}
	/**
	 * @param postcode the postcode to set
	 */
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	/**
	 * @return the citynm
	 */
	public String getCitynm() {
		return citynm;
	}
	/**
	 * @param citynm the citynm to set
	 */
	public void setCitynm(String citynm) {
		this.citynm = citynm;
	}
	/**
	 * @return the areanm
	 */
	public String getAreanm() {
		return areanm;
	}
	/**
	 * @param areanm the areanm to set
	 */
	public void setAreanm(String areanm) {
		this.areanm = areanm;
	}
	/**
	 * @return the districtnm
	 */
	public String getDistrictnm() {
		return districtnm;
	}
	/**
	 * @param districtnm the districtnm to set
	 */
	public void setDistrictnm(String districtnm) {
		this.districtnm = districtnm;
	}
	/**
	 * @return the branchnm
	 */
	public String getBranchnm() {
		return branchnm;
	}
	/**
	 * @param branchnm the branchnm to set
	 */
	public void setBranchnm(String branchnm) {
		this.branchnm = branchnm;
	}
	/**
	 * @return the area
	 */
	public String getArea() {
		return area;
	}
	/**
	 * @param area the area to set
	 */
	public void setArea(String area) {
		this.area = area;
	}
	/**
	 * @return the postidassigned
	 */
	public BigDecimal getPostidassigned() {
		return postidassigned;
	}
	/**
	 * @param postidassigned the postidassigned to set
	 */
	public void setPostidassigned(BigDecimal postidassigned) {
		this.postidassigned = postidassigned;
	}

	
	
	
	
}