package com.acss.core.model.customerpayment;

public class CustPDCHistory {
	private String pduedate;
	private String pcheque;
	private String pamount;
	private String pbank;
	private String pstatus;
	private String pject;
	private String pmark;
	
	public CustPDCHistory(){}
	


	public String getPstatus() {
		return pstatus;
	}
	public void setPstatus(String pstatus) {
		this.pstatus = pstatus;
	}
	public String getPbank() {
		return pbank;
	}
	public void setPbank(String pbank) {
		this.pbank = pbank;
	}
	public String getPamount() {
		return pamount;
	}
	public void setPamount(String pamount) {
		this.pamount = pamount;
	}
	public String getPcheque() {
		return pcheque;
	}
	public void setPcheque(String pcheque) {
		this.pcheque = pcheque;
	}
	public String getPduedate() {
		return pduedate;
	}
	public void setPduedate(String pduedate) {
		this.pduedate = pduedate;
	}



	public String getPject() {
		return pject;
	}



	public void setPject(String pject) {
		this.pject = pject;
	}



	public String getPmark() {
		return pmark;
	}



	public void setPmark(String pmark) {
		this.pmark = pmark;
	}
}
