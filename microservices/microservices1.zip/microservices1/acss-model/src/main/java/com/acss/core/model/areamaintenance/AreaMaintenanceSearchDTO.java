package com.acss.core.model.areamaintenance;

import java.util.ArrayList;
import java.util.List;

import com.acss.core.model.areamaintenance.AreaSummary;
import com.acss.core.model.areamaintenance.Branch;


/**
 * DTO for application search criteria.
 *
 */
public class AreaMaintenanceSearchDTO {
	
	private String branchnm;
	private String areanm;
	private String postcd;
	
	private List<AreaSummary> areaStats;
	private List<Branch> branches;
	
	public AreaMaintenanceSearchDTO() {
		areaStats = new ArrayList<>();
		branches = new ArrayList<>();
	}
	
	/**
	 * Append all present parameters as query string in the GET request
	 * @param uri
	 * @return uri with parameters.
	 */
	public String appendParameters(String uri){
		uri=branchnm!=null&&branchnm.length()>0?uri+"branchName="+branchnm+"&":uri;
		uri=areanm!=null&&areanm.length()>0?uri+"area="+areanm:uri;
		uri=postcd!=null&&postcd.length()>0?uri+"postCode="+postcd:uri;
		return uri;
	}
	
	public AreaMaintenanceSearchDTO(String branchnm, String area, String postcode) {
		this.branchnm = branchnm;
		this.areanm = area;
		this.postcd = postcode;
	}

	/**
	 * @return the branchnm
	 */
	public String getBranchnm() {
		return branchnm;
	}

	/**
	 * @param branchnm the branchnm to set
	 */
	public void setBranchnm(String branchnm) {
		this.branchnm = branchnm;
	}

	/**
	 * @return the area
	 */
	public String getAreanm() {
		return areanm;
	}

	/**
	 * @param area the area to set
	 */
	public void setAreanm(String areanm) {
		this.areanm = areanm;
	}

	/**
	 * @return the areaStats
	 */
	public List<AreaSummary> getAreaStats() {
		return areaStats;
	}

	/**
	 * @param areaStats the areaStats to set
	 */
	public void setAreaStats(List<AreaSummary> areaStats) {
		this.areaStats = areaStats;
	}

	/**
	 * @return the branches
	 */
	public List<Branch> getBranches() {
		return branches;
	}

	/**
	 * @param branches the branches to set
	 */
	public void setBranches(List<Branch> branches) {
		this.branches = branches;
	}
	
	
}
