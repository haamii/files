/**
 * 
 */
package com.acss.core.model.staffmaintenance;

import java.util.List;

/**
 * @author jarnonobal
 *
 */
public class UserAccountModel {

	private String userCd;
	private String userName;

	public UserAccountModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserAccountModel(String userCd, String userName) {
		super();
		this.userCd = userCd;
		this.userName = userName;
	}

	/**
	 * @return the userCd
	 */
	public String getUserCd() {
		return userCd;
	}

	/**
	 * @param userCd the userCd to set
	 */
	public void setUserCd(String userCd) {
		this.userCd = userCd;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
}
