package com.acss.core.teammaintenance;

public class Collector {
	
	private String userCd;
	private String name;
	private String remainingAccounts;
	/**
	 * @return the userCd
	 */
	public String getUserCd() {
		return userCd;
	}
	/**
	 * @param userCd the userCd to set
	 */
	public void setUserCd(String userCd) {
		this.userCd = userCd;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the remainingAccounts
	 */
	public String getRemainingAccounts() {
		return remainingAccounts;
	}
	/**
	 * @param remainingAccounts the remainingAccounts to set
	 */
	public void setRemainingAccounts(String remainingAccounts) {
		this.remainingAccounts = remainingAccounts;
	}

}
