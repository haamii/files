package com.acss.core.model.fieldorder;

public class AllocatedTable {
	
	private String acustomercode;
	private String aagreementno;
	private String aarea;
	private String aperiod;
	private String adelaystatus;
	private String atotalos;
	private String apenalty;
	private String acustomerbillamount;
	private String atotalpayable;
	private String auserid;
	private String ausername;
	
	public AllocatedTable(){}
	
	public String getAcustomercode() {
		return acustomercode;
	}
	public void setAcustomercode(String acustomercode) {
		this.acustomercode = acustomercode;
	}

	public String getAagreementno() {
		return aagreementno;
	}

	public void setAagreementno(String aagreementno) {
		this.aagreementno = aagreementno;
	}

	public String getAperiod() {
		return aperiod;
	}

	public void setAperiod(String aperiod) {
		this.aperiod = aperiod;
	}

	public String getAarea() {
		return aarea;
	}

	public void setAarea(String aarea) {
		this.aarea = aarea;
	}

	public String getAdelaystatus() {
		return adelaystatus;
	}

	public void setAdelaystatus(String adelaystatus) {
		this.adelaystatus = adelaystatus;
	}

	public String getAtotalos() {
		return atotalos;
	}

	public void setAtotalos(String atotalos) {
		this.atotalos = atotalos;
	}

	public String getApenalty() {
		return apenalty;
	}

	public void setApenalty(String apenalty) {
		this.apenalty = apenalty;
	}

	public String getAcustomerbillamount() {
		return acustomerbillamount;
	}

	public void setAcustomerbillamount(String acustomerbillamount) {
		this.acustomerbillamount = acustomerbillamount;
	}

	public String getAtotalpayable() {
		return atotalpayable;
	}

	public void setAtotalpayable(String atotalpayable) {
		this.atotalpayable = atotalpayable;
	}

	public String getAuserid() {
		return auserid;
	}

	public void setAuserid(String auserid) {
		this.auserid = auserid;
	}

	public String getAusername() {
		return ausername;
	}

	public void setAusername(String ausername) {
		this.ausername = ausername;
	}

}
