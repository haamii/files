package com.acss.core.teammaintenance;

public class CollectorModel {
	
	private String name;
	private String branchnm;
	private String id;
	private String type;
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the branchnm
	 */
	public String getBranchnm() {
		return branchnm;
	}
	/**
	 * @param branchnm the branchnm to set
	 */
	public void setBranchnm(String branchnm) {
		this.branchnm = branchnm;
	}
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

}
