/**
 * 
 */
package com.acss.core.model.paidcasesreport;

import java.math.BigDecimal;

/**
 * @author jpetronio
 *
 */
public class PaidCasesResultModel {
	 private int no;
	 private String agreementCd;
	 private String name;
	 private BigDecimal emi;
	 private BigDecimal bounceCharges;
	 private BigDecimal latePaymentCharges;
	 private BigDecimal pickUpCharges;
	 private BigDecimal foreclosure;
	 private BigDecimal totalAmount;
	 private String modeOfPayment;
	 private String dateOfPayment;
	 private String area;
	 private String chequeNo;
	 private String bankName;
	 private String chequeDate;
	 private String chequeStatus;
	 private String transactionId;
	 private String callerName;
	
	 //constructors
	 public PaidCasesResultModel() {
		super();
	}

	public PaidCasesResultModel(int no, String agreementCd, String name, BigDecimal emi, BigDecimal bounceCharges,
			BigDecimal latePaymentCharges, BigDecimal pickUpCharges, BigDecimal foreclosure, BigDecimal totalAmount,
			String modeOfPayment, String dateOfPayment, String area, String chequeNo, String bankName,
			String chequeDate, String chequeStatus, String transactionId, String callerName) {
		super();
		this.no = no;
		this.agreementCd = agreementCd;
		this.name = name;
		this.emi = emi;
		this.bounceCharges = bounceCharges;
		this.latePaymentCharges = latePaymentCharges;
		this.pickUpCharges = pickUpCharges;
		this.foreclosure = foreclosure;
		this.totalAmount = totalAmount;
		this.modeOfPayment = modeOfPayment;
		this.dateOfPayment = dateOfPayment;
		this.area = area;
		this.chequeNo = chequeNo;
		this.bankName = bankName;
		this.chequeDate = chequeDate;
		this.chequeStatus = chequeStatus;
		this.transactionId = transactionId;
		this.callerName = callerName;
	}

	//setters
	public void setNo(int no) {
		this.no = no;
	}

	public void setAgreementCd(String agreementCd) {
		this.agreementCd = agreementCd;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setEmi(BigDecimal emi) {
		this.emi = emi;
	}

	public void setBounceCharges(BigDecimal bounceCharges) {
		this.bounceCharges = bounceCharges;
	}

	public void setLatePaymentCharges(BigDecimal latePaymentCharges) {
		this.latePaymentCharges = latePaymentCharges;
	}

	public void setPickUpCharges(BigDecimal pickUpCharges) {
		this.pickUpCharges = pickUpCharges;
	}

	public void setForeclosure(BigDecimal foreclosure) {
		this.foreclosure = foreclosure;
	}

	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}

	public void setModeOfPayment(String modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}

	public void setDateOfPayment(String dateOfPayment) {
		this.dateOfPayment = dateOfPayment;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public void setChequeDate(String chequeDate) {
		this.chequeDate = chequeDate;
	}

	public void setChequeStatus(String chequeStatus) {
		this.chequeStatus = chequeStatus;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public void setCallerName(String callerName) {
		this.callerName = callerName;
	}
	
	//getters

	public int getNo() {
		return no;
	}

	public String getAgreementCd() {
		return agreementCd;
	}

	public String getName() {
		return name;
	}

	public BigDecimal getEmi() {
		return emi;
	}

	public BigDecimal getBounceCharges() {
		return bounceCharges;
	}

	public BigDecimal getLatePaymentCharges() {
		return latePaymentCharges;
	}

	public BigDecimal getPickUpCharges() {
		return pickUpCharges;
	}

	public BigDecimal getForeclosure() {
		return foreclosure;
	}

	public BigDecimal getTotalAmount() {
		return totalAmount;
	}

	public String getModeOfPayment() {
		return modeOfPayment;
	}

	public String getDateOfPayment() {
		return dateOfPayment;
	}

	public String getArea() {
		return area;
	}

	public String getChequeNo() {
		return chequeNo;
	}

	public String getBankName() {
		return bankName;
	}

	public String getChequeDate() {
		return chequeDate;
	}

	public String getChequeStatus() {
		return chequeStatus;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public String getCallerName() {
		return callerName;
	}
	 
	 
	 
	 
}
