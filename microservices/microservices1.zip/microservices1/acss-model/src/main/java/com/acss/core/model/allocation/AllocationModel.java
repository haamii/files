package com.acss.core.model.allocation;

public class AllocationModel {
	
	private String collectorCd;
	private String accountCode;
	private int ownAccount;
	private int accountAllocated;
	private int totalAllocated;
	private int totalAllocatedcopy;
	private String userName;
	
	public AllocationModel(String collectorCd, String accountCode,
			int ownAccount, int accountAllocated, int totalAllocated,int totalAllocatedcopy, String userName) {
		this.collectorCd = collectorCd;
		this.accountCode = accountCode;
		this.ownAccount = ownAccount;
		this.accountAllocated = accountAllocated;
		this.totalAllocated = totalAllocated;
		this.totalAllocatedcopy = totalAllocatedcopy;
		this.userName = userName;
	}
	
	public AllocationModel() {}
	
	/**
	 * @return the collectorCd
	 */
	public String getCollectorCd() {
		return collectorCd;
	}
	
	/**
	 * @param collectorCd the collectorCd to set
	 */
	public void setCollectorCd(String collectorCd) {
		this.collectorCd = collectorCd;
	}

	/**
	 * @return the accountCode
	 */
	public String getAccountCode() {
		return accountCode;
	}

	/**
	 * @param accountCode the accountCode to set
	 */
	public void setAccountCode(String accountCode) {
		this.accountCode = accountCode;
	}

	/**
	 * @return the ownAccount
	 */
	public int getOwnAccount() {
		return ownAccount;
	}

	/**
	 * @param ownAccount the ownAccount to set
	 */
	public void setOwnAccount(int ownAccount) {
		this.ownAccount = ownAccount;
	}

	/**
	 * @return the accountAllocated
	 */
	public int getAccountAllocated() {
		return accountAllocated;
	}

	/**
	 * @param accountAllocated the accountAllocated to set
	 */
	public void setAccountAllocated(int accountAllocated) {
		this.accountAllocated = accountAllocated;
	}

	/**
	 * @return the totalAllocated
	 */
	public int getTotalAllocated() {
		return totalAllocated;
	}

	/**
	 * @param totalAllocated the totalAllocated to set
	 */
	public void setTotalAllocated(int totalAllocated) {
		this.totalAllocated = totalAllocated;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getTotalAllocatedcopy() {
		return totalAllocatedcopy;
	}

	public void setTotalAllocatedcopy(int totalAllocatedcopy) {
		this.totalAllocatedcopy = totalAllocatedcopy;
	}
	
	
	
}
