package com.acss.core.model.allocation;

import java.util.List;

public class AllocationCriteriaModel {
	private String branchName;
	private List<String> areas;
	
	public AllocationCriteriaModel(){}
	
	public AllocationCriteriaModel(String branchName, List<String> areas) {
		this.branchName = branchName;
		this.areas = areas;
	}

	/**
	 * @return the branchName
	 */
	public String getBranchName() {
		return branchName;
	}

	/**
	 * @param branchName the branchName to set
	 */
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	/**
	 * @return the areas
	 */
	public List<String> getAreas() {
		return areas;
	}
	/**
	 * @param areas the areas to set
	 */
	public void setAreas(List<String> areas) {
		this.areas = areas;
	}
	
}
