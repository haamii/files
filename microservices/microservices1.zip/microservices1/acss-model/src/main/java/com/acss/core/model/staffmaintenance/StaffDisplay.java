package com.acss.core.model.staffmaintenance;

public class StaffDisplay {
	private String accountname;
	private String accountcode;
	private String positiontype;
	private String branchnm;
	private Byte bucket;
	
	public StaffDisplay(String accountname,String accountcode,String positiontype,String branchnm,Byte bucket){
		this.accountname =accountname;
		this.accountcode = accountcode;
		this.positiontype = positiontype;
		this.setBranchnm(branchnm);
		this.bucket=bucket;
	}
	
	
	public StaffDisplay() {}


	public String getAccountName() {
		return accountname;
	}
	public void setAccountName(String accountname) {
		this.accountname = accountname;
	}
	public String getAccountcode() {
		return accountcode;
	}
	public void setAccountcode(String accountcode) {
		this.accountcode = accountcode;
	}
	public String getPositiontype() {
		return positiontype;
	}
	public void setPositiontype(String positiontype) {
		this.positiontype = positiontype;
	}


	public String getBranchnm() {
		return branchnm;
	}


	public void setBranchnm(String branchnm) {
		this.branchnm = branchnm;
	}


	public Byte getBucket() {
		return bucket;
	}


	public void setBucket(Byte bucket) {
		this.bucket = bucket;
	}
	
	
}
