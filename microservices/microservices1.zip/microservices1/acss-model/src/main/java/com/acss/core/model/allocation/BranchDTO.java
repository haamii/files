package com.acss.core.model.allocation;

import java.util.List;

/**
 * The model class for the Allocation Module
 * 
 */
public class BranchDTO {
	
	private String branchName;
	private List<String> areas;
	
	public BranchDTO() {}
	
	
	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}


	public List<String> getAreas() {
		return areas;
	}
	
	public void setAreas(List<String> areas) {
		this.areas = areas;
	}

}
