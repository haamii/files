package com.acss.core.model.areamaintenance;

import com.acss.core.model.BaseEntity;

public class AreaDetails extends BaseEntity{
	private String branchnm;
	private String area;
	private String postid;
	private String postcode;
	private String citynm;
	private String areanm;
	private String districtnm;

	/**
	 * Append all present parameters as query string in the GET request
	 * @param uri
	 * @return uri with parameters.
	 */
	public String appendParameters(String uri){
		uri=branchnm!=null&&branchnm.length()>0?uri+"branchName="+branchnm+"&":uri;
		uri=postcode!=null&&postcode.length()>0?uri+"postCode="+postcode:uri;
		return uri;
	}
	
	
	public String getBranchnm() {
		return branchnm;
	}
	public void setBranchnm(String branchnm) {
		this.branchnm = branchnm;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getPostid() {
		return postid;
	}
	public void setPostid(String postid) {
		this.postid = postid;
	}
	public String getPostcode() {
		return postcode;
	}
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	public String getCitynm() {
		return citynm;
	}
	public void setCitynm(String citynm) {
		this.citynm = citynm;
	}
	public String getAreanm() {
		return areanm;
	}
	public void setAreanm(String areanm) {
		this.areanm = areanm;
	}
	public String getDistrictnm() {
		return districtnm;
	}
	public void setDistrictnm(String districtnm) {
		this.districtnm = districtnm;
	}
	
}
