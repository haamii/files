package com.acss.core.model.customerpayment;

public class CustomerInstallmentSummary {
	private String totschedPrincipal;
	private String totschedInterest;
	private String totschedPenalty;
	private String totschedBouncecharge;
	private String totschedOthercharge;
	
	private String payPrincipal;
	private String payInterest;
	private String payPenalty;
	private String payBouncecharge;
	private String payOthercharge;
	
	private String totOsPrincipal;
	private String totOsInterest;
	private String totOsPenalty;
	private String totOsBouncecharge;
	private String totOsOthercharge;
	
	private String postPayPrincipal;
	private String postPayInterest;
	private String postPayPenalty;
	private String postPayBouncecharge;
	private String postPayOthercharge;
	
	private String currOSPrincipal;
	private String currOSInterest;
	private String currOSPenalty;
	private String currOSBouncecharge;
	private String currOSOthercharge;
	
	public CustomerInstallmentSummary(){}
	
	public String getTotschedPenalty() {
		return totschedPenalty;
	}
	public void setTotschedPenalty(String totschedPenalty) {
		this.totschedPenalty = totschedPenalty;
	}
	public String getTotschedPrincipal() {
		return totschedPrincipal;
	}
	public void setTotschedPrincipal(String totschedPrincipal) {
		this.totschedPrincipal = totschedPrincipal;
	}
	public String getTotschedInterest() {
		return totschedInterest;
	}
	public void setTotschedInterest(String totschedInterest) {
		this.totschedInterest = totschedInterest;
	}
	public String getTotschedBouncecharge() {
		return totschedBouncecharge;
	}
	public void setTotschedBouncecharge(String totschedBouncecharge) {
		this.totschedBouncecharge = totschedBouncecharge;
	}
	public String getTotschedOthercharge() {
		return totschedOthercharge;
	}
	public void setTotschedOthercharge(String totschedOthercharge) {
		this.totschedOthercharge = totschedOthercharge;
	}
	public String getPayPrincipal() {
		return payPrincipal;
	}
	public void setPayPrincipal(String payPrincipal) {
		this.payPrincipal = payPrincipal;
	}
	public String getPayInterest() {
		return payInterest;
	}
	public void setPayInterest(String payInterest) {
		this.payInterest = payInterest;
	}
	public String getPayPenalty() {
		return payPenalty;
	}
	public void setPayPenalty(String payPenalty) {
		this.payPenalty = payPenalty;
	}
	public String getPayBouncecharge() {
		return payBouncecharge;
	}
	public void setPayBouncecharge(String payBouncecharge) {
		this.payBouncecharge = payBouncecharge;
	}
	public String getPayOthercharge() {
		return payOthercharge;
	}
	public void setPayOthercharge(String payOthercharge) {
		this.payOthercharge = payOthercharge;
	}
	public String getTotOsPrincipal() {
		return totOsPrincipal;
	}
	public void setTotOsPrincipal(String totOsPrincipal) {
		this.totOsPrincipal = totOsPrincipal;
	}
	public String getTotOsInterest() {
		return totOsInterest;
	}
	public void setTotOsInterest(String totOsInterest) {
		this.totOsInterest = totOsInterest;
	}
	public String getTotOsPenalty() {
		return totOsPenalty;
	}
	public void setTotOsPenalty(String totOsPenalty) {
		this.totOsPenalty = totOsPenalty;
	}
	public String getTotOsBouncecharge() {
		return totOsBouncecharge;
	}
	public void setTotOsBouncecharge(String totOsBouncecharge) {
		this.totOsBouncecharge = totOsBouncecharge;
	}
	public String getTotOsOthercharge() {
		return totOsOthercharge;
	}
	public void setTotOsOthercharge(String totOsOthercharge) {
		this.totOsOthercharge = totOsOthercharge;
	}
	public String getPostPayPrincipal() {
		return postPayPrincipal;
	}
	public void setPostPayPrincipal(String postPayPrincipal) {
		this.postPayPrincipal = postPayPrincipal;
	}
	public String getPostPayInterest() {
		return postPayInterest;
	}
	public void setPostPayInterest(String postPayInterest) {
		this.postPayInterest = postPayInterest;
	}
	public String getPostPayBouncecharge() {
		return postPayBouncecharge;
	}
	public void setPostPayBouncecharge(String postPayBouncecharge) {
		this.postPayBouncecharge = postPayBouncecharge;
	}
	public String getPostPayPenalty() {
		return postPayPenalty;
	}
	public void setPostPayPenalty(String postPayPenalty) {
		this.postPayPenalty = postPayPenalty;
	}
	public String getPostPayOthercharge() {
		return postPayOthercharge;
	}
	public void setPostPayOthercharge(String postPayOthercharge) {
		this.postPayOthercharge = postPayOthercharge;
	}

	public String getCurrOSPrincipal() {
		return currOSPrincipal;
	}

	public void setCurrOSPrincipal(String currOSPrincipal) {
		this.currOSPrincipal = currOSPrincipal;
	}

	public String getCurrOSInterest() {
		return currOSInterest;
	}

	public void setCurrOSInterest(String currOSInterest) {
		this.currOSInterest = currOSInterest;
	}

	public String getCurrOSPenalty() {
		return currOSPenalty;
	}

	public void setCurrOSPenalty(String currOSPenalty) {
		this.currOSPenalty = currOSPenalty;
	}

	public String getCurrOSBouncecharge() {
		return currOSBouncecharge;
	}

	public void setCurrOSBouncecharge(String currOSBouncecharge) {
		this.currOSBouncecharge = currOSBouncecharge;
	}

	public String getCurrOSOthercharge() {
		return currOSOthercharge;
	}

	public void setCurrOSOthercharge(String currOSOthercharge) {
		this.currOSOthercharge = currOSOthercharge;
	}
	
	public void init(){
		totschedPrincipal = "0";
		totschedInterest = "0";
		totschedPenalty= "0";
		totschedBouncecharge= "0";
		totschedOthercharge= "0";
		
		payPrincipal= "0";
		payInterest= "0";
		payPenalty= "0";
		payBouncecharge= "0";
		payOthercharge= "0";
		
		totOsPrincipal= "0";
		totOsInterest= "0";
		totOsPenalty= "0";
		totOsBouncecharge= "0";
		totOsOthercharge= "0";
		
		postPayPrincipal= "0";
		postPayInterest= "0";
		postPayPenalty= "0";
		postPayBouncecharge= "0";
		postPayOthercharge= "0";
		
		currOSPrincipal= "0";
		currOSInterest= "0";
		currOSPenalty= "0";
		currOSBouncecharge= "0";
		currOSOthercharge= "0";
	}

}
