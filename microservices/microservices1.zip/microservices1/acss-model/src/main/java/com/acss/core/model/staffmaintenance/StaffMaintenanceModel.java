/**
 * 
 */
package com.acss.core.model.staffmaintenance;

import java.math.BigDecimal;

import com.acss.core.model.BaseEntity;

/**
 * @author jarnonobal
 *
 */
public class StaffMaintenanceModel extends BaseEntity{
	
	public String accountCode;	
	public String branch;
	public String accountName;
	public String collectorCd;
	public String password;
	public String positionType;
	public Byte bucket;
	/**
	 * @return the accountCode
	 */
	public String getAccountCode() {
		return accountCode;
	}
	/**
	 * @param accountCode the accountCode to set
	 */
	public void setAccountCode(String accountCode) {
		this.accountCode = accountCode;
	}
	
	public String getAccountName() {
		return accountName;
	}
	/**
	 * @param accountCode the accountCode to set
	 */
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	
	public String getPassword() {
		return password;
	}
	/**
	 * @param accountCode the accountCode to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	
	/**
	 * 
	 * @return the branch
	 */
	public String getBranch() {
		return branch;
	}
	/**
	 * @param branch the branch to set
	 */
	public void setBranch(String branch) {
		this.branch = branch;
	}
	/**
	 * @return the positionType
	 */
	public String getPositionType() {
		return positionType;
	}
	/**
	 * @param positionType the positionType to set
	 */
	public void setPositionType(String positionType) {
		this.positionType = positionType;
	}
	/**
	 * @return the collectorCd
	 */
	public String getCollectorCd() {
		return collectorCd;
	}
	/**
	 * @param collectorCd the collectorCd to set
	 */
	public void setCollectorCd(String collectorCd) {
		this.collectorCd = collectorCd;
	}
	
	
	public Byte getBucket() {
		return bucket;
	}
	/**
	 * @param collectorCd the collectorCd to set
	 */
	public void setBucket(Byte bucket) {
		this.bucket = bucket;
	}
	
	
}
