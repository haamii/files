package com.acss.core.model.dataentry.common.constants;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public enum RefRelationship {
	
	MOTHER(1,"refrelationship.mother","MOTHER"),
	FATHER(2,"refrelationship.father","FATHER"),
	BROTHER(3,"refrelationship.brother","BROTHER"),
	SISTER(4,"refrelationship.sister","SISTER"),
	AUNTIE(6,"refrelationship.auntie","AUNTIE"),
	UNCLE(7,"refrelationship.uncle","UNCLE"),
	COUSIN(8,"refrelationship.cousin","COUSIN"),
	REFERRAL(9,"refrelationship.referral","REFERRAL"),
	OTHERREF(5,"refrelationship.other","OTHER");
	
	private int code;
	private String value;
	private String dbValue;
	
	public final static String MODEL_ATTRIB_KEY = "refRelationshipList";
	
	public final static class BootstrapSingleton {
		public static final Map<String, RefRelationship> lookupByValue = new HashMap<String, RefRelationship>();
		public static final Map<BigDecimal, RefRelationship> lookupByCode = new HashMap<BigDecimal, RefRelationship>();
	}
	
	RefRelationship(int code, String value,String dbValue) {
		this.code = code;
		this.value = value;
		this.dbValue = dbValue;
		BootstrapSingleton.lookupByValue.put(value, this);
		BootstrapSingleton.lookupByCode.put(new BigDecimal(code), this);
	}
	
	public int getCode() {
		return code;
	}

	public String getValue() {
		return value;
	}
	
	public String getDbValue(){
		return dbValue;
	}
}
