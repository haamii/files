package com.acss.core.model.fieldorder;

import java.util.List;
import java.util.Map;

import com.acss.core.model.BaseEntity;
import com.acss.core.model.allocation.BranchDTO;
import com.acss.core.model.allocation.ContactResultDTO;
/**
 * 
 * @author jangolluan
 * @since 2016
 * @version 0.01
 * TRANSFER OBJECT ONLY FOR FIELD ORDER MODULES
 * PUT ALL MODELS AND PARAMETERS HERE FOR FLEXIBILTY AND MAINTAINABILITY OF MODULES
 */
public class FieldOrderDTO extends BaseEntity{
	public final static String MODEL_ATTRIB_KEY = "fieldOrder";
	
	private List<Branch> branches;
	
	private FieldOrderSearch fieldOrderSearch;
	
	private UnallocatedTable unallocTable;
	
	private RemainingAccountModelMap remAccModelMap;
	
	private AllocatedCount allocatedCount;
	
	private List<FieldCollectorsWithAccounts> fieldCollectorsWithAccounts;
	
	private List<UnallocatedTable> unallocatedTable;
	
	private List<BranchDTO> branchdto;
	
	private List<UserNameMCollAccount> userNameMCollAccount;
	
	private List<UserNameMCollAgency> userNameMCollAgency;
	
	private List<CollectionTeam> collectionTeam;
	
	private List<UserDetails> userdetails;
	
	private List<AllocatedTable> allocatedTable;
	
	private AllocatedTable alloctable;
	
	private List<String> agreements;
	
	private List<RemainingAccountModelMap> remainingAccountModelMap;
	
	private List<RemainingAccountsTable> remainingAccountTable;
	
	private String accountToAllocate;
	
	private List<ContactResultDTO> contactResult;

	public FieldOrderDTO(){}

	public List<Branch> getBranches() {
		return branches;
	}

	public void setBranches(List<Branch> branches) {
		this.branches = branches;
	}

	public FieldOrderSearch getFieldOrderSearch() {
		return fieldOrderSearch;
	}

	public void setFieldOrderSearch(FieldOrderSearch fieldOrderSearch) {
		this.fieldOrderSearch = fieldOrderSearch;
	}

	public List<BranchDTO> getBranchdto() {
		return branchdto;
	}

	public void setBranchdto(List<BranchDTO> branchdto) {
		this.branchdto = branchdto;
	}

	public List<UserNameMCollAccount> getUserNameMCollAccount() {
		return userNameMCollAccount;
	}

	public void setUserNameMCollAccount(List<UserNameMCollAccount> userNameMCollAccount) {
		this.userNameMCollAccount = userNameMCollAccount;
	}

	public List<UserNameMCollAgency> getUserNameMCollAgency() {
		return userNameMCollAgency;
	}

	public void setUserNameMCollAgency(List<UserNameMCollAgency> userNameMCollAgency) {
		this.userNameMCollAgency = userNameMCollAgency;
	}

	public List<CollectionTeam> getCollectionTeam() {
		return collectionTeam;
	}

	public void setCollectionTeam(List<CollectionTeam> collectionTeam) {
		this.collectionTeam = collectionTeam;
	}

	public List<UserDetails> getUserdetails() {
		return userdetails;
	}

	public void setUserdetails(List<UserDetails> userdetails) {
		this.userdetails = userdetails;
	}

	public List<AllocatedTable> getAllocatedTable() {
		return allocatedTable;
	}

	public void setAllocatedTable(List<AllocatedTable> allocatedTable) {
		this.allocatedTable = allocatedTable;
	}

	public AllocatedCount getAllocatedCount() {
		return allocatedCount;
	}

	public void setAllocatedCount(AllocatedCount allocatedCount) {
		this.allocatedCount = allocatedCount;
	}

	public List<UnallocatedTable> getUnallocatedTable() {
		return unallocatedTable;
	}

	public void setUnallocatedTable(List<UnallocatedTable> unallocatedTable) {
		this.unallocatedTable = unallocatedTable;
	}

	public List<FieldCollectorsWithAccounts> getFieldCollectorsWithAccounts() {
		return fieldCollectorsWithAccounts;
	}

	public void setFieldCollectorsWithAccounts(
			List<FieldCollectorsWithAccounts> fieldCollectorsWithAccounts) {
		this.fieldCollectorsWithAccounts = fieldCollectorsWithAccounts;
	}

	public AllocatedTable getAlloctable() {
		return alloctable;
	}

	public void setAlloctable(AllocatedTable alloctable) {
		this.alloctable = alloctable;
	}

	public List<String> getAgreements() {
		return agreements;
	}

	public void setAgreements(List<String> agreements) {
		this.agreements = agreements;
	}

	public List<RemainingAccountModelMap> getRemainingAccountModelMap() {
		return remainingAccountModelMap;
	}

	public void setRemainingAccountModelMap(List<RemainingAccountModelMap> remainingAccountModelMap) {
		this.remainingAccountModelMap = remainingAccountModelMap;
	}

	public List<RemainingAccountsTable> getRemainingAccountTable() {
		return remainingAccountTable;
	}

	public void setRemainingAccountTable(List<RemainingAccountsTable> remainingAccountTable) {
		this.remainingAccountTable = remainingAccountTable;
	}

	public RemainingAccountModelMap getRemAccModelMap() {
		return remAccModelMap;
	}

	public void setRemAccModelMap(RemainingAccountModelMap remAccModelMap) {
		this.remAccModelMap = remAccModelMap;
	}

	public UnallocatedTable getUnallocTable() {
		return unallocTable;
	}

	public void setUnallocTable(UnallocatedTable unallocTable) {
		this.unallocTable = unallocTable;
	}

	public String getAccountToAllocate() {
		return accountToAllocate;
	}

	public void setAccountToAllocate(String accountToAllocate) {
		this.accountToAllocate = accountToAllocate;
	}

	public List<ContactResultDTO> getContactResult() {
		return contactResult;
	}

	public void setContactResult(List<ContactResultDTO> contactResult) {
		this.contactResult = contactResult;
	}

}
