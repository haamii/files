package com.acss.core.model.deskcontact;

import java.math.BigDecimal;

public class AccountCollectionModel { 
	
	private Integer groupId;
	private String agreementCd;
	private String applicationType; //EXP. AG.
	private String customerCd;
	private String agentName;
	private String agreementDate;
	private String period;
	private Integer delayStatus;
	private BigDecimal totalOs;
	private BigDecimal needPayCompensation; //PREMIUM
	private BigDecimal totalPay;
	private BigDecimal curBillAmount;
	private String sysAppCd;
	private Integer yearMonth;
	private Integer product;
	private String repoStatus;
	private BigDecimal penalty;
	private String type;
	private String id;
	private BigDecimal mobileNo;
	private String homeTel;
	private String corpTel;
	private String name;
	
	public final static String MODEL_ATTRIB_KEY = "accountDetail";

	public AccountCollectionModel(Integer groupId, String agreementCd, String applicationType,
			String customerCd, String agentName, String agreementDate,
			String period,
			Integer delayStatus, BigDecimal totalOs,
			BigDecimal needPayCompensation, BigDecimal totalPay,
			BigDecimal curBillAmount, String sysAppCd, Integer yearMonth, 
			Integer product, String repoStatus, BigDecimal penalty, String type, String id) {
		this.groupId = groupId;
		this.agreementCd = agreementCd;
		this.applicationType = applicationType;
		this.customerCd = customerCd;
		this.agentName = agentName;
		this.agreementDate = agreementDate;
		this.setPeriod(period);
		this.delayStatus = delayStatus;
		this.totalOs = totalOs;
		this.needPayCompensation = needPayCompensation;
		this.totalPay = totalPay;
		this.curBillAmount = curBillAmount;
		this.sysAppCd = sysAppCd;
		this.yearMonth = yearMonth;
		this.product = product;
		this.repoStatus = repoStatus;
		this.penalty = penalty;
		this.setId(id);
	}

	public AccountCollectionModel(){}
	
	/**
	 * @return the groupId
	 */
	public Integer getGroupId() {
		return groupId;
	}
	/**
	 * @param groupId the groupId to set
	 */
	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}
	/**
	 * @return the agreementCd
	 */
	public String getAgreementCd() {
		return agreementCd;
	}
	/**
	 * @param agreementCd the agreementCd to set
	 */
	public void setAgreementCd(String agreementCd) {
		this.agreementCd = agreementCd;
	}
	/**
	 * @return the applicationType
	 */
	public String getApplicationType() {
		return applicationType;
	}
	/**
	 * @param applicationType the applicationType to set
	 */
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}
	/**
	 * @return the customerCd
	 */
	public String getCustomerCd() {
		return customerCd;
	}
	/**
	 * @param customerCd the customerCd to set
	 */
	public void setCustomerCd(String customerCd) {
		this.customerCd = customerCd;
	}
	/**
	 * @return the agentName
	 */
	public String getAgentName() {
		return agentName;
	}
	/**
	 * @param agentName the agentName to set
	 */
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	/**
	 * @return the agreementDate
	 */
	public String getAgreementDate() {
		return agreementDate;
	}
	/**
	 * @param agreementDate the agreementDate to set
	 */
	public void setAgreementDate(String agreementDate) {
		this.agreementDate = agreementDate;
	}
	/**
	 * @return the delayStatus
	 */
	public Integer getDelayStatus() {
		return delayStatus;
	}
	/**
	 * @param delayStatus the delayStatus to set
	 */
	public void setDelayStatus(Integer delayStatus) {
		this.delayStatus = delayStatus;
	}
	/**
	 * @return the totalOs
	 */
	public BigDecimal getTotalOs() {
		return totalOs;
	}
	/**
	 * @param totalOs the totalOs to set
	 */
	public void setTotalOs(BigDecimal totalOs) {
		this.totalOs = totalOs;
	}
	/**
	 * @return the compensation
	 */
	public BigDecimal getNeedPayCompensation() {
		return needPayCompensation;
	}
	/**
	 * @param compensation the compensation to set
	 */
	public void setNeedPayCompensation(BigDecimal needPayCompensation) {
		this.needPayCompensation = needPayCompensation;
	}
	/**
	 * @return the totalPay
	 */
	public BigDecimal getTotalPay() {
		return totalPay;
	}
	/**
	 * @param totalPay the totalPay to set
	 */
	public void setTotalPay(BigDecimal totalPay) {
		this.totalPay = totalPay;
	}
	/**
	 * @return the curBillAmount
	 */
	public BigDecimal getCurBillAmount() {
		return curBillAmount;
	}
	/**
	 * @param curBillAmount the curBillAmount to set
	 */
	public void setCurBillAmount(BigDecimal curBillAmount) {
		this.curBillAmount = curBillAmount;
	}
	
	/**
	 * @return the sysAppCd
	 */
	public String getSysAppCd() {
		return sysAppCd;
	}

	/**
	 * @param sysAppCd the sysAppCd to set
	 */
	public void setSysAppCd(String sysAppCd) {
		this.sysAppCd = sysAppCd;
	}

	/**
	 * @return the yearMonth
	 */
	public Integer getYearMonth() {
		return yearMonth;
	}

	/**
	 * @param yearMonth the yearMonth to set
	 */
	public void setYearMonth(Integer yearMonth) {
		this.yearMonth = yearMonth;
	}

	/**
	 * @return the product
	 */
	public Integer getProduct() {
		return product;
	}

	/**
	 * @param product the product to set
	 */
	public void setProduct(Integer product) {
		this.product = product;
	}

	/**
	 * @return the repoStatus
	 */
	public String getRepoStatus() {
		return repoStatus;
	}

	/**
	 * @param repoStatus the repoStatus to set
	 */
	public void setRepoStatus(String repoStatus) {
		this.repoStatus = repoStatus;
	}

	/**
	 * @return the penalty
	 */
	public BigDecimal getPenalty() {
		return penalty;
	}

	/**
	 * @param penalty the penalty to set
	 */
	public void setPenalty(BigDecimal penalty) {
		this.penalty = penalty;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the period
	 */
	public String getPeriod() {
		return period;
	}

	/**
	 * @param period the period to set
	 */
	public void setPeriod(String period) {
		this.period = period;
	}

	/**
	 * @return the mobileNo
	 */
	public BigDecimal getMobileNo() {
		return mobileNo;
	}

	/**
	 * @param mobileNo the mobileNo to set
	 */
	public void setMobileNo(BigDecimal mobileNo) {
		this.mobileNo = mobileNo;
	}

	/**
	 * @return the homeTel
	 */
	public String getHomeTel() {
		return homeTel;
	}

	/**
	 * @param homeTel the homeTel to set
	 */
	public void setHomeTel(String homeTel) {
		this.homeTel = homeTel;
	}

	/**
	 * @return the corpTel
	 */
	public String getCorpTel() {
		return corpTel;
	}

	/**
	 * @param corpTel the corpTel to set
	 */
	public void setCorpTel(String corpTel) {
		this.corpTel = corpTel;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	

	
}
