package com.acss.core.model.customerpayment;

public class CustomerACHHistory {
	private String atransactionid;
	private String astatus;
	private String aduedate;
	private String aamountdue;
	private String areconciledate;
	private String areconcileamount;
	private String arejectedreason;
	private String aremarks;
	
	public CustomerACHHistory(){}
	
	public String appendParameters(String uri){		
		uri=atransactionid!=null&&atransactionid.length()>0?uri+"atransactionid="+atransactionid+"&":uri;
		uri=astatus!=null&&astatus.length()>0?uri+"astatus="+astatus+"&":uri;
		uri=aduedate!=null&&aduedate.length()>0?uri+"aduedate="+aduedate+"&":uri;
		uri=aamountdue!=null&&aamountdue.length()>0?uri+"aamountdue="+aamountdue+"&":uri;
		uri=areconciledate!=null&&areconciledate.length()>0?uri+"areconciledate="+areconciledate+"&":uri;
		uri=areconcileamount!=null&&areconcileamount.length()>0?uri+"areconcileamount="+areconcileamount+"&":uri;
		uri=arejectedreason!=null&&arejectedreason.length()>0?uri+"arejectedreason="+arejectedreason+"&":uri;
		uri=aremarks!=null&&aremarks.length()>0?uri+"aremarks="+aremarks+"&":uri;
		return uri;
	}

	public String getAtransactionid() {
		return atransactionid;
	}

	public void setAtransactionid(String atransactionid) {
		this.atransactionid = atransactionid;
	}

	public String getAstatus() {
		return astatus;
	}

	public void setAstatus(String astatus) {
		this.astatus = astatus;
	}

	public String getAduedate() {
		return aduedate;
	}

	public void setAduedate(String aduedate) {
		this.aduedate = aduedate;
	}

	public String getAamountdue() {
		return aamountdue;
	}

	public void setAamountdue(String aamountdue) {
		this.aamountdue = aamountdue;
	}

	public String getAreconciledate() {
		return areconciledate;
	}

	public void setAreconciledate(String areconciledate) {
		this.areconciledate = areconciledate;
	}

	public String getAreconcileamount() {
		return areconcileamount;
	}

	public void setAreconcileamount(String areconcileamount) {
		this.areconcileamount = areconcileamount;
	}

	public String getAremarks() {
		return aremarks;
	}

	public void setAremarks(String aremarks) {
		this.aremarks = aremarks;
	}

	public String getArejectedreason() {
		return arejectedreason;
	}

	public void setArejectedreason(String arejectedreason) {
		this.arejectedreason = arejectedreason;
	} 
}
