package com.acss.core.model;

import java.math.BigDecimal;

import org.joda.time.DateTime;
import org.joda.time.LocalTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

/**
 * Base Entity Class with a Key as generic.
 * @author gvargas
 * @param <TKey> - the unique key.
 */
public class BaseEntity{
	protected String crePerson;
	protected String creProId;
	protected BigDecimal creDate;
	protected BigDecimal creTime;
	protected String updPerson;
	protected String updProId;
	protected BigDecimal updDate;
	protected BigDecimal updTime;
	protected BigDecimal delflag;
	protected Integer updCnt = 0;
	
	/**
	 * Sets everything into current date.
	 */
	public BaseEntity() {
		//this should be parameterized.
	}
	
	/**
	 * only credate and cretime on create.
	 */
	public void prepareForCreate(String crePerson, String creProId){
		DateTimeFormatter dateFormat = DateTimeFormat.forPattern("yyyyMMdd");
		DateTimeFormatter timeFormat = DateTimeFormat.forPattern("HHmmss");
		
		DateTime now = new DateTime();
		LocalTime time = new LocalTime();
		
		BigDecimal currentDate = new BigDecimal(now.toString(dateFormat));
		this.creDate = currentDate;
		
		BigDecimal currentTime = new BigDecimal(time.toString(timeFormat));

		this.creTime = currentTime;
		
		this.delflag = new BigDecimal(0);
		
		this.crePerson = crePerson;
		this.creProId = creProId;		

	}
	
	/**
	 * clears the credate and cretime to exclude it on update.
	 */
	public void prepareForUpdate(String updPerson, String updProId){
		DateTime now = new DateTime();
		LocalTime time = new LocalTime();
		DateTimeFormatter dateFormat = DateTimeFormat.forPattern("yyyyMMdd");
		DateTimeFormatter timeFormat = DateTimeFormat.forPattern("HHmmss");
		BigDecimal currentDate = new BigDecimal(now.toString(dateFormat));
		
		this.updDate = currentDate;
		BigDecimal currentTime = new BigDecimal(time.toString(timeFormat));
		this.updTime = currentTime;
//		this.updCnt = new BigDecimal(1); //TODO: this should be a trigger
		
		this.updPerson = updPerson;
		this.updProId = updProId;
	}
	
	public BigDecimal getCreDate() {
		return creDate;
	}
	public void setCreDate(BigDecimal creDate) {
		this.creDate = creDate;
	}
	/**
	 * Returns current date always.
	 * @return
	 */
	public BigDecimal getCreTime() {
		return creTime;
	}
	public void setCreTime(BigDecimal creTime) {
		this.creTime = creTime;
	}
	public BigDecimal getUpdDate() {
		return updDate;
	}
	public void setUpdDate(BigDecimal updDate) {
		this.updDate = updDate;
	}
	public BigDecimal getUpdTime() {
		return updTime;
	}
	public void setUpdTime(BigDecimal updTime) {
		this.updTime = updTime;
	}
	public BigDecimal getDelflag() {
		return delflag;
	}
	public void setDelflag(BigDecimal delflag) {
		this.delflag = delflag;
	}

	public String getCrePerson() {
		return crePerson;
	}

	public void setCrePerson(String crePerson) {
		this.crePerson = crePerson;
	}

	public String getUpdPerson() {
		return updPerson;
	}

	public void setUpdPerson(String updPerson) {
		this.updPerson = updPerson;
	}

	public Integer getUpdCnt() {
		return updCnt;
	}

	public void setUpdCnt(Integer updCnt) {
		this.updCnt = updCnt;
	}

	public String getCreProId() {
		return creProId;
	}

	public void setCreProId(String creProId) {
		this.creProId = creProId;
	}

	public String getUpdProId() {
		return updProId;
	}

	public void setUpdProId(String updProId) {
		this.updProId = updProId;
	}
	
}
