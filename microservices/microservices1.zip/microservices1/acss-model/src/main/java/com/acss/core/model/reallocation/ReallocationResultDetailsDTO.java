package com.acss.core.model.reallocation;

import java.util.List;

public class ReallocationResultDetailsDTO {
	
	private List<CollectorDTO> accountHolderIds;	
	private List<ReallocationSearchModel> searchResult;
	private List<CollectorDTO> reallocateToCollector;	
//	private String searchUrl; //to be deleted
	
	public final static String MODEL_ATTRIB_KEY = "reallocationDetail";

	public ReallocationResultDetailsDTO(List<CollectorDTO> accountHolderIds, List<ReallocationSearchModel> searchResult) {
		this.accountHolderIds = accountHolderIds;
		this.searchResult = searchResult;
	}
	
	public ReallocationResultDetailsDTO(List<CollectorDTO> reallocateToCollector){
		this.reallocateToCollector = reallocateToCollector;
	}
	
	public ReallocationResultDetailsDTO(){}

	/**
	 * @return the accountHolderIds
	 */
	public List<CollectorDTO> getAccountHolderIds() {
		return accountHolderIds;
	}

	/**
	 * @param accountHolderIds the accountHolderIds to set
	 */
	public void setAccountHolderIds(List<CollectorDTO> accountHolderIds) {
		this.accountHolderIds = accountHolderIds;
	}

	/**
	 * @return the searchResult
	 */
	public List<ReallocationSearchModel> getSearchResult() {
		return searchResult;
	}

	/**
	 * @param searchResult the searchResult to set
	 */
	public void setSearchResult(List<ReallocationSearchModel> searchResult) {
		this.searchResult = searchResult;
	}

	/**
	 * @return the reallocateToCollector
	 */
	public List<CollectorDTO> getReallocateToCollector() {
		return reallocateToCollector;
	}

	/**
	 * @param reallocateToCollector the reallocateToCollector to set
	 */
	public void setReallocateToCollector(List<CollectorDTO> reallocateToCollector) {
		this.reallocateToCollector = reallocateToCollector;
	}

//	/**
//	 * @return the searchUrl
//	 */
//	public String getSearchUrl() {
//		return searchUrl;
//	}
//
//	/**
//	 * @param searchUrl the searchUrl to set
//	 */
//	public void setSearchUrl(String searchUrl) {
//		this.searchUrl = searchUrl;
//	}	
	

}
