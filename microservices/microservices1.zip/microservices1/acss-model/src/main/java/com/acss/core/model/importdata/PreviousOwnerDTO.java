package com.acss.core.model.importdata;

public class PreviousOwnerDTO {

	private String agreementCd;
	private String category;
	private String empId;
	private String fieldCollectorName;
	private String bucket;
	
	public String getAgreementCd() {
		return agreementCd;
	}
	public void setAgreementCd(String agreementCd) {
		this.agreementCd = agreementCd;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getFieldCollectorName() {
		return fieldCollectorName;
	}
	public void setFieldCollectorName(String fieldCollectorName) {
		this.fieldCollectorName = fieldCollectorName;
	}
	public String getBucket() {
		return bucket;
	}
	public void setBucket(String bucket) {
		this.bucket = bucket;
	}
	
}
