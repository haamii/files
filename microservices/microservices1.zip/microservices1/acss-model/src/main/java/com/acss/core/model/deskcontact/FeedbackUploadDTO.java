package com.acss.core.model.deskcontact;

import com.acss.core.model.BaseEntity;

/**
 * @author sgalvez
 *
 */

public class FeedbackUploadDTO extends BaseEntity {

	String agreementCd; 
	String code; 
	String remark; 
	String status; 
	String reason; 
	String fileName;
	
	public final static String MODEL_ATTRIB_KEY = "feedbackUploadForm";
	
	public FeedbackUploadDTO(String agreementCd, String code, String remark, String status, String reason,
			String fileName) {
		super();
		this.agreementCd = agreementCd;
		this.code = code;
		this.remark = remark;
		this.status = status;
		this.reason = reason;
		this.fileName = fileName;
	}
	
	public FeedbackUploadDTO() {}

	public String getAgreementCd() {
		return agreementCd;
	}

	public void setAgreementCd(String agreementCd) {
		this.agreementCd = agreementCd;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	
}
