package com.acss.core.model.fieldorder;

public class FieldCollectorsWithAccounts {
	public FieldCollectorsWithAccounts(){}
	public String getUsercd() {
		return usercd;
	}
	public void setUsercd(String usercd) {
		this.usercd = usercd;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCountagreement() {
		return countagreement;
	}
	public void setCountagreement(String countagreement) {
		this.countagreement = countagreement;
	}
	private String usercd;
	private String name;
	private String countagreement;
}
