package com.acss.core.model.reallocation;

import com.acss.core.model.BaseEntity;

public class ReallocationSaveDTO extends BaseEntity{
	
	private String[] agreementCdList;
	private String reallocateToCollector;
	
	public ReallocationSaveDTO(){}
	
	public ReallocationSaveDTO(String[] agreementCdList,
			String reallocateToCollector) {
		this.agreementCdList = agreementCdList;
		this.reallocateToCollector = reallocateToCollector;
	}
	/**
	 * @return the agreementCd
	 */
	public String[] getAgreementCdList() {
		return agreementCdList;
	}
	/**
	 * @param agreementCd the agreementCd to set
	 */
	public void setAgreementCdList(String[] agreementCdList) {
		this.agreementCdList = agreementCdList;
	}
	/**
	 * @return the reallocateToCollector
	 */
	public String getReallocateToCollector() {
		return reallocateToCollector;
	}
	/**
	 * @param reallocateToCollector the reallocateToCollector to set
	 */
	public void setReallocateToCollector(String reallocateToCollector) {
		this.reallocateToCollector = reallocateToCollector;
	}
	
	

}
