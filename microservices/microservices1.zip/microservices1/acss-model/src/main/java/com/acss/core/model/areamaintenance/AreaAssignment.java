package com.acss.core.model.areamaintenance;

import java.math.BigDecimal;

public class AreaAssignment {
	String area;
	BigDecimal postidassigned;
	
	public AreaAssignment(){
		postidassigned = new BigDecimal(0);
	}
	
	public AreaAssignment(String areaName,BigDecimal assignedPost){
		this.area = areaName;
		this.postidassigned = assignedPost;
	}

	/**
	 * @return the area
	 */
	public String getArea() {
		return area;
	}

	/**
	 * @param area the area to set
	 */
	public void setArea(String area) {
		this.area = area;
	}

	/**
	 * @return the postidassigned
	 */
	public BigDecimal getPostidassigned() {
		return postidassigned;
	}

	/**
	 * @param postidassigned the postidassigned to set
	 */
	public void setPostidassigned(BigDecimal postidassigned) {
		this.postidassigned = postidassigned;
	}
	
}
