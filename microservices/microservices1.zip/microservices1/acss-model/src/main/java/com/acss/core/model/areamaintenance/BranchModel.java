package com.acss.core.model.areamaintenance;



public class BranchModel {
	
	private String branchnm;

	/**
	 * @return the branchnm
	 */
	public String getBranchnm() {
		return branchnm;
	}
	/**
	 * @param branchnm the branchnm to set
	 */
	public void setBranchnm(String branchnm) {
		this.branchnm = branchnm;
	}

}