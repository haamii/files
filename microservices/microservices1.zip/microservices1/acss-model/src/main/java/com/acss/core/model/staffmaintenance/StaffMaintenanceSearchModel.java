/**
 * 
 */
package com.acss.core.model.staffmaintenance;

import com.acss.core.model.BaseEntity;

/**
 * @author jarnonobal
 *
 */
public class StaffMaintenanceSearchModel extends BaseEntity{
	
	private String username;
	private String accountcode;
	private String branchnm;
	private String positiontype;
	private String positiontypecode;
	private String accountname;
	private String collectorcd;
	private Byte bucket;
	private StaffDisplay staffDisplay;
	
	public StaffMaintenanceSearchModel(){
		staffDisplay = new StaffDisplay();
	}
	
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return the accountcode
	 */
	public String getAccountcode() {
		return accountcode;
	}

	/**
	 * @param accountcode the accountcode to set
	 */
	public void setAccountcode(String accountcode) {
		this.accountcode = accountcode;
	}

	/**
	 * @return the branchnm
	 */
	public String getBranchnm() {
		return branchnm;
	}

	/**
	 * @param branchnm the branchnm to set
	 */
	public void setBranchnm(String branchnm) {
		this.branchnm = branchnm;
	}

	/**
	 * @return the positiontype
	 */
	public String getPositiontype() {
		return positiontype;
	}

	/**
	 * @param positiontype the positiontype to set
	 */
	public void setPositiontype(String positiontype) {
		this.positiontype = positiontype;
	}

	/**
	 * @return the collectorcd
	 */
	public String getCollectorcd() {
		return collectorcd;
	}

	/**
	 * @param collectorcd the collectorcd to set
	 */
	public void setCollectorcd(String collectorcd) {
		this.collectorcd = collectorcd;
	}

	public String getAccountname() {
		return accountname;
	}

	public void setAccountname(String accountname) {
		this.accountname = accountname;
	}

	public StaffDisplay getStaffDisplay() {
		return staffDisplay;
	}

	public void setStaffDisplay(StaffDisplay staffDisplay) {
		this.staffDisplay = staffDisplay;
	}

	public Byte getBucket() {
		return bucket;
	}

	public void setBucket(Byte bucket) {	
		this.bucket = bucket;
	}

	public String getPositiontypecode() {
		return positiontypecode;
	}

	public void setPositiontypecode(String positiontypecode) {
		this.positiontypecode = positiontypecode;
	}
	
}
