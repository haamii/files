package com.acss.core.model.fieldorder;

public class RemainingAccountModelMap {
	private String agreementcd;
	private String prevfieldcollectorid;
	private String priority;
	private String lastmonthpaid;
	
	public RemainingAccountModelMap(){}
	
	public String getAgreementcd() {
		return agreementcd;
	}
	public void setAgreementcd(String agreementcd) {
		this.agreementcd = agreementcd;
	}
	public String getPrevfieldcollectorid() {
		return prevfieldcollectorid;
	}
	public void setPrevfieldcollectorid(String prevfieldcollectorid) {
		this.prevfieldcollectorid = prevfieldcollectorid;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getLastmonthpaid() {
		return lastmonthpaid;
	}

	public void setLastmonthpaid(String lastmonthpaid) {
		this.lastmonthpaid = lastmonthpaid;
	}
}
