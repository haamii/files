package com.acss.core.model.customerpayment;

public class CustomerAgreement {
	private String agreementno;
	
	public CustomerAgreement(){}

	public String getAgreementno() {
		return agreementno;
	}

	public void setAgreementno(String agreementno) {
		this.agreementno = agreementno;
	}
}
