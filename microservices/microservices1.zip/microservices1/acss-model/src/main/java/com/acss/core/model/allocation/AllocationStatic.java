package com.acss.core.model.allocation;

public interface AllocationStatic {

	static final String SUPERVISOR = "SUPERVISOR";
	static final String DESKCALLER = "DESK_CALLER";

}
