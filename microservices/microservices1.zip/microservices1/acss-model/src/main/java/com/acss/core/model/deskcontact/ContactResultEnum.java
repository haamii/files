package com.acss.core.model.deskcontact;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * @author cvicente
 *
 */
public enum ContactResultEnum {
	 ANF(1,"ADDRESS NOT FOUND",6,4),
	 BPTP(2, "BROKEN PROMISE TO PAY",4,3),
	 CB(3, "CALL BACK",8,3),
	 DISP(4, "DISPUTE",8,3),
	 DL(5, "DOOR LOCK",8,4),
	 FRC(6, "FORECLOSED",8,3),
	 LM(7,"LEFT MESSAGE",8,3),
	 NCP(8,"NOT CONTACTABLE ON PHONE",6,4), 
	 NIS(9,"NOT IN SERVICE",6,4),
	 NRC(10,"NOT REACHABLE",6,4),
	 OOA(11,"OUT OF AREA",6,4),
	 OST(12,"OUT OF STATION",6,4),
	 PAID(13,"PAID",3,6),
	 PTP(14,"PROMISE TO PAY",2,5),
	 PTPB(15,"PROMISE TO PAY AT BANK",2,5),
	 PTPC(16,"PROMISE TO PAY COUNTER",2,5),
	 PTPF(17,"PROMISE TO PAY AT FIELD",2,5),
	 PU(18,"PICK-UP",8,2),
	 RNR(19,"RINGING",8,2),
	 RTPI(20,"REFUSE TO PAY INTENTIONAL",4,3),
	 RTPT(21,"REFUSE TO PAY TEMPORARY",4,3),
	 SKIP(22,"SKIP",8,6),
	 STL(23,"SETTLEMENT",8,6),
	 SWO(24,"SWITCH OFF",5,4);
	
	private int code;
	private String value;
	private int contactResultGroup;
	private int priorityGroup;
	
	private final static class BootstrapSingleton {
		public static final Map<String, ContactResultEnum> lookupByValue = new HashMap<String, ContactResultEnum>();
		public static final Map<BigDecimal, ContactResultEnum> lookupByCode = new HashMap<BigDecimal, ContactResultEnum>();
	}
	
	ContactResultEnum(int code, String value, int contactResultGroup, int priorityGroup) {
		this.code = code;
		this.value = value;
		this.contactResultGroup = contactResultGroup;
		this.priorityGroup = priorityGroup;
		
		BootstrapSingleton.lookupByValue.put(value, this);
		BootstrapSingleton.lookupByCode.put(new BigDecimal(code), this);
	}
	
	public int getCode() {
		return code;
	}

	public String getValue() {
		return value;
	}
	
	public int getContactResultGroup() {
		return contactResultGroup;
	}
	
	public int getPriorityGroup() {
		return priorityGroup;
	}
	
	public static String getEnumByString(String code){
        for(ContactResultEnum e : ContactResultEnum.values()){
            if(code.equals(String.valueOf(e.getCode()))) return e.value;
        }
        return "-";
    }
	
	public static String getEnumNameByCode(String code){
        for(ContactResultEnum e : ContactResultEnum.values()){
            if(code.equals(String.valueOf(e.getCode()))) return e.name();
        }
        return "-";
    }
	
	public static int getNumericCodeByCode(String code){
        for(ContactResultEnum e : ContactResultEnum.values()){
            if(code.equalsIgnoreCase(String.valueOf(e))) return e.getCode();
        }
        return 0;
    }
	
}
