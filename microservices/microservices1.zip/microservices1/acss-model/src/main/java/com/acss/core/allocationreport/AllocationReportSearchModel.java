/**
 * 
 */
package com.acss.core.allocationreport;

/**
 * @author jarnonobal
 *
 */
public class AllocationReportSearchModel {
	
	private String branch;
	private String areaGroup;
	private Integer bucket;
	private String userName;

	public AllocationReportSearchModel(String branch, String areaGroup, Integer bucket, String userName) {
		super();
		this.branch = branch;
		this.areaGroup = areaGroup;
		this.bucket = bucket;
		this.userName = userName;
	}
	/**
	 * @return the branch
	 */
	public String getBranch() {
		return branch;
	}
	/**
	 * @param branch the branch to set
	 */
	public void setBranch(String branch) {
		this.branch = branch;
	}
	/**
	 * @return the areaGroup
	 */
	public String getAreaGroup() {
		return areaGroup;
	}
	/**
	 * @param areaGroup the areaGroup to set
	 */
	public void setAreaGroup(String areaGroup) {
		this.areaGroup = areaGroup;
	}
	/**
	 * @return the bucket
	 */
	public Integer getBucket() {
		return bucket;
	}
	/**
	 * @param bucket the bucket to set
	 */
	public void setBucket(Integer bucket) {
		this.bucket = bucket;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
}
