package com.acss.core.model.deskcontact;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * @author sgalvez
 *
 */
public enum ModeOfPaymentEnum {
	ECS(1,"ECS"),
	PDC(2, "PDC"),
	OVER_THE_COUNTER(3,"OVER THE COUNTER"),
	ACH_D(4, "ACH-D"),
	ACH_M(5, "ACH-M");
	
	private int code;
	private String value;
	
	private final static class BootstrapSingleton {
		public static final Map<String, ModeOfPaymentEnum> lookupByValue = new HashMap<String, ModeOfPaymentEnum>();
		public static final Map<BigDecimal, ModeOfPaymentEnum> lookupByCode = new HashMap<BigDecimal, ModeOfPaymentEnum>();
	}
	
	ModeOfPaymentEnum(int code, String value) {
		this.code = code;
		this.value = value;
		BootstrapSingleton.lookupByValue.put(value, this);
		BootstrapSingleton.lookupByCode.put(new BigDecimal(code), this);
	}
	
	public int getCode() {
		return code;
	}

	public String getValue() {
		return value;
	}
}
