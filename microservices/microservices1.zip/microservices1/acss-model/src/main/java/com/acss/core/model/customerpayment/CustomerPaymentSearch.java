package com.acss.core.model.customerpayment;

import java.math.BigDecimal;

public class CustomerPaymentSearch {
	
	private String customercode;
	private String customername;
	private String idcardno;
	private String agreementno;
	private String paymentstatus;
	private BigDecimal payment;
	
	public CustomerPaymentSearch(){}
	
	public String appendParameters(String uri){		
		uri=customercode!=null&&customercode.length()>0?uri+"customercode="+customercode+"&":uri;
		uri=customername!=null&&customername.length()>0?uri+"customername="+customername+"&":uri;
		uri=idcardno!=null&&idcardno.length()>0?uri+"idcardno="+idcardno+"&":uri;
		uri=agreementno!=null&&agreementno.length()>0?uri+"agreementno="+agreementno+"&":uri;
		uri=paymentstatus!=null&&paymentstatus.length()>0?uri+"paymentstatus="+paymentstatus+"&":uri;

		return uri;
	}
	
	public String getCustomercode() {
		return customercode;
	}
	public void setCustomercode(String customercode) {
		this.customercode = customercode;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public String getIdcardno() {
		return idcardno;
	}

	public void setIdcardno(String idcardno) {
		this.idcardno = idcardno;
	}

	public String getAgreementno() {
		return agreementno;
	}

	public void setAgreementno(String agreementno) {
		this.agreementno = agreementno;
	}

	public String getPaymentstatus() {
		return paymentstatus;
	}

	public void setPaymentstatus(String paymentstatus) {
		this.paymentstatus = paymentstatus;
	}

	public BigDecimal getPayment() {
		return payment;
	}

	public void setPayment(BigDecimal payment) {
		this.payment = payment;
	}

}
