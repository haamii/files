package com.acss.core.model.areamaintenance;

import java.util.ArrayList;
import java.util.List;

public class SearchAreaCriteria {
	private List<String> branchList;
	private List<String> branchListForArea;
	private String selectedBranch;
	private String area;
	private String postidassigned;
	

	public SearchAreaCriteria(){
		branchList = new ArrayList<String>();
		branchListForArea = new ArrayList<String>();
	}
	
	/**
	 * Append all present parameters as query string in the GET request
	 * @param uri
	 * @return uri with parameters.
	 */
	public String appendParameters(String uri){
		
		//for recode
		area = area.contains("%") ? "withpercent" : area;
		
		uri=selectedBranch!=null&&selectedBranch.length()>0?uri+"branchName="+selectedBranch+"&":uri;
		uri=area!=null&&area.length()>0?uri+"area="+area:uri;
		return uri;
	}
	
	/**
	 * @return the branchList
	 */
	public List<String> getBranchList() {
		return branchList;
	}
	/**
	 * @param branchList the branchList to set
	 */
	public void setBranchList(List<String> branchList) {
		this.branchList = branchList;
	}
	/**
	 * @return the area
	 */
	public String getArea() {
		return area;
	}
	/**
	 * @param area the area to set
	 */
	public void setArea(String area) {
		this.area = area;
	}
	/**
	 * @return the selectedBranch
	 */
	public String getSelectedBranch() {
		return selectedBranch;
	}
	/**
	 * @param selectedBranch the selectedBranch to set
	 */
	public void setSelectedBranch(String selectedBranch) {
		this.selectedBranch = selectedBranch;
	}

	public String getPostidassigned() {
		return postidassigned;
	}

	public void setPostidassigned(String postidassigned) {
		this.postidassigned = postidassigned;
	}

	public List<String> getBranchListForArea() {
		return branchListForArea;
	}

	public void setBranchListForArea(List<String> branchListForArea) {
		this.branchListForArea = branchListForArea;
	}
	
	
	
}
