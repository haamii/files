/**
 * 
 */
package com.acss.core.model.staffmaintenance;

import com.acss.core.model.BaseEntity;

/**
 * @author jarnonobal
 *
 */
public class StaffMaintenanceCreate extends BaseEntity{
	
	private String inputUserCd;
	private String inputUserName;
	private String inputBranch;
	private String inputPositionType;
	private String inputPassword;
	private Byte inputBucket;
	
	public StaffMaintenanceCreate() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public StaffMaintenanceCreate(String inputUserCd, String inputUserName, String inputBranch,
			String inputPositionType,String inputPassword,Byte inputBucket) {
		super();
		this.inputUserCd = inputUserCd;
		this.inputUserName = inputUserName;
		this.inputBranch = inputBranch;
		this.inputPositionType = inputPositionType;
		this.inputPassword=inputPassword;
		this.inputBucket=inputBucket;
	}
	
	public String appendParameters(String uri){
		
		if (null!=inputUserCd)
			uri=!inputUserCd.isEmpty()?uri+"inputUserCd="+inputUserCd+"&":uri;
		
		if (null!=inputUserName)
			uri=!inputUserName.isEmpty()?uri+"inputUserName="+inputUserName+"&":uri;
		
		if (null!=inputBranch)
			uri=!inputBranch.isEmpty()?uri+"inputBranch="+inputBranch+"&":uri;
		
		if (null!=inputPositionType)
			uri=!inputPositionType.isEmpty()?uri+"inputPositionType="+inputPositionType+"&":uri;
		
		if (null!=inputPassword)
			uri=!inputPassword.isEmpty()?uri+"inputPassword="+inputPassword+"&":uri;
		
		if (null!=inputBucket)
			uri=!inputBucket.equals(null)?uri+"inputBucket="+inputBucket+"&":uri;
		
		if (null!=crePerson)
			uri=!crePerson.equals(null)?uri+"crePerson="+crePerson+"&":uri;
		
		if (null!=creProId)
			uri=!creProId.equals(null)?uri+"creProId="+creProId+"&":uri;
		
		return uri;
	}
	
	/**
	 * @return the inputUserCd
	 */
	public String getInputUserCd() {
		return inputUserCd;
	}
	/**
	 * @param inputUserCd the inputUserCd to set
	 */
	public void setInputUserCd(String inputUserCd) {
		this.inputUserCd = inputUserCd;
	}
	/**
	 * @return the inputUserName
	 */
	public String getInputUserName() {
		return inputUserName;
	}
	/**
	 * @param inputUserName the inputUserName to set
	 */
	public void setInputUserName(String inputUserName) {
		this.inputUserName = inputUserName;
	}
	/**
	 * @return the inputBranch
	 */
	public String getInputBranch() {
		return inputBranch;
	}
	/**
	 * @param inputBranch the inputBranch to set
	 */
	public void setInputBranch(String inputBranch) {
		this.inputBranch = inputBranch;
	}
	/**
	 * @return the inputPositionType
	 */
	public String getInputPositionType() {
		return inputPositionType;
	}
	/**
	 * @param inputPositionType the inputPositionType to set
	 */
	public void setInputPositionType(String inputPositionType) {
		this.inputPositionType = inputPositionType;
	}

	public String getInputPassword() {
		return inputPassword;
	}

	public void setInputPassword(String inputPassword) {
		this.inputPassword = inputPassword;
	}
	
	public Byte getInputBucket() {
		return inputBucket;
	}

	public void setInputBucket(Byte inputBucket) {
		this.inputBucket = inputBucket;
	}
	
}
