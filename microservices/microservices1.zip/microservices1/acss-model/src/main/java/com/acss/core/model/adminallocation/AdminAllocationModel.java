package com.acss.core.model.adminallocation;

public class AdminAllocationModel {

	private String customerGroup;
	private int openingAccount;
	private int freezed;
	private int desk;
	private int field;
	private int agency;
	
	public static final String MODEL_ATTRIB_KEY = "adminAllocationForm";
	
	public AdminAllocationModel() {}
	
	
	public AdminAllocationModel(String customerGroup, int openingAccount, int freezed, int desk, int field) {
		this.customerGroup = customerGroup;
		this.openingAccount = openingAccount;
		this.freezed = freezed;
		this.desk = desk;
		this.field = field;
	}
	
	public AdminAllocationModel(String customerGroup, int openingAccount, int freezed, int desk, int field, int agency) {
		this.customerGroup = customerGroup;
		this.openingAccount = openingAccount;
		this.freezed = freezed;
		this.desk = desk;
		this.field = field;
		this.agency = agency;
	}

	public String getCustomerGroup() {
		return customerGroup;
	}

	public void setCustomerGroup(String customerGroup) {
		this.customerGroup = customerGroup;
	}

	public int getOpeningAccount() {
		return openingAccount;
	}

	public void setOpeningAccount(int openingAccount) {
		this.openingAccount = openingAccount;
	}

	public int getFreezed() {
		return freezed;
	}

	public void setFreezed(int freezed) {
		this.freezed = freezed;
	}

	public int getDesk() {
		return desk;
	}

	public void setDesk(int desk) {
		this.desk = desk;
	}

	public int getField() {
		return field;
	}

	public void setField(int field) {
		this.field = field;
	}

	public int getAgency() {
		return agency;
	}

	public void setAgency(int agency) {
		this.agency = agency;
	}

}
