package com.acss.core.model.areamaintenance;


public class Branch {
	String code;
	String value;
	
	public Branch(){}
	
	public Branch(String code,String value){
		this.code = code;
		this.value = value;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}


	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}


	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}


	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	
	
}
