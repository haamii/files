package com.acss.core.model.adminallocation;

import java.util.List;

import com.acss.core.model.allocation.BranchDTO;

public class AdminAllocationDTO {

	private List<BranchDTO> branches;
	private String jsonAdminAllocStorage;
	private String jsonAdminAllocStorageCopy;
	private String branch;
	private String userName;
	private String strTotal;
	private String openingTotal;
	private String freezedTotal;
	private String deskTotal;
	private String fieldTotal;
	private String agencyTotal;

	public String getJsonAdminAllocStorage() {
		return jsonAdminAllocStorage;
	}

	public void setJsonAdminAllocStorage(String jsonAdminAllocStorage) {
		this.jsonAdminAllocStorage = jsonAdminAllocStorage;
	}

	public String getJsonAdminAllocStorageCopy() {
		return jsonAdminAllocStorageCopy;
	}

	public void setJsonAdminAllocStorageCopy(String jsonAdminAllocStorageCopy) {
		this.jsonAdminAllocStorageCopy = jsonAdminAllocStorageCopy;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getStrTotal() {
		return strTotal;
	}

	public void setStrTotal(String strTotal) {
		this.strTotal = strTotal;
	}

	public String getOpeningTotal() {
		return openingTotal;
	}

	public void setOpeningTotal(String openingTotal) {
		this.openingTotal = openingTotal;
	}

	public String getFreezedTotal() {
		return freezedTotal;
	}

	public void setFreezedTotal(String freezedTotal) {
		this.freezedTotal = freezedTotal;
	}

	public String getDeskTotal() {
		return deskTotal;
	}

	public void setDeskTotal(String deskTotal) {
		this.deskTotal = deskTotal;
	}

	public String getFieldTotal() {
		return fieldTotal;
	}

	public void setFieldTotal(String fieldTotal) {
		this.fieldTotal = fieldTotal;
	}

	public String getAgencyTotal() {
		return agencyTotal;
	}

	public void setAgencyTotal(String agencyTotal) {
		this.agencyTotal = agencyTotal;
	}

	public List<BranchDTO> getBranches() {
		return branches;
	}

	public void setBranches(List<BranchDTO> branches) {
		this.branches = branches;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

}
