/**
 * 
 */
package com.acss.core.ecsachpdcreject;

import java.math.BigDecimal;

import com.acss.core.model.BaseEntity;

/**
 * @author jpetronio
 *
 */
public class PaymentRejectDTO extends BaseEntity{
	private String agreementCd;
	private String emi;
	private String remark;
	private String returnRemark;
	private String status;
	private String reason;
	private String fileName;
	
	public final static String MODEL_ATTRIB_KEY = "paymentRejectForm";
	//constructors
	public PaymentRejectDTO() {
		super();
	}
	public PaymentRejectDTO(String agreementCd, String emi, String remark, String returnRemark, String status,
			String reason, String fileName) {
		super();
		this.agreementCd = agreementCd;
		this.emi = emi;
		this.remark = remark;
		this.returnRemark = returnRemark;
		this.status = status;
		this.reason = reason;
		this.fileName = fileName;
	}
	
	//setters
	
	public void setAgreementCd(String agreementCd) {
		this.agreementCd = agreementCd;
	}
	public void setEmi(String emi) {
		this.emi = emi;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public void setReturnRemark(String returnRemark) {
		this.returnRemark = returnRemark;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	//getters
	public String getAgreementCd() {
		return agreementCd;
	}
	public String getEmi() {
		return emi;
	}
	public String getRemark() {
		return remark;
	}
	public String getReturnRemark() {
		return returnRemark;
	}
	public String getStatus() {
		return status;
	}
	public String getReason() {
		return reason;
	}
	public String getFileName() {
		return fileName;
	}
	public static String getModelAttribKey() {
		return MODEL_ATTRIB_KEY;
	}	
	
}
