package com.acss.core.model.dataentry.common.constants;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public enum NatureOfBusiness {

	ACCOMODATION_HOTEL(1,"natureofbusiness.hotel","ACCOMODATION / HOTEL"),
	AGENCY(2,"natureofbusiness.agency","AGENCY"),
	AGRICULTURE(3,"natureofbusiness.agri","AGRICULTURE"),
	ARMY_POLICE(4,"natureofbusiness.army","ARMY / POLICE"),
	AUTOMOTIVE_CARDEALER(5,"natureofbusiness.cardealer","AUTOMOTIVE / CAR DEALER"),
	BANKING_FINANCING(6,"natureofbusiness.finance","BANKING / FINANCING"),
	BEAUTY_WELLNESS(7,"natureofbusiness.wellness","BEAUTY / WELLNESS"),
	BUSINESS_SERVICES(8,"natureofbusiness.business","BUSINESS SERVICES"),
	CALL_CENTER(9,"natureofbusiness.callcenter","CALL CENTER"),
	CONSTRUCTION(10,"natureofbusiness.construction","CONSTRUCTION"),
	CONSULTANCY(11,"natureofbusiness.consultancy","CONSULTANCY / PROFESSIONAL SERVICES"),
	DIRECT_SELLING(12,"natureofbusiness.selling","DIRECT SELLING"),
	EDUCATION_LEARNING(13,"natureofbusiness.education","EDUCATION / LEARNING"),
	ENTERTAINMENT_MEDIA(14,"natureofbusiness.media","ENTERTAINMENT / MEDIA"),
	GOVERNMENT(15,"natureofbusiness.government","GOVERNMENT"),
	INSURANCE_SECURITIES(16,"natureofbusiness.insurance","INSURANCE / SECURITIES"),
	MANUFACTURING(17,"natureofbusiness.manu","MANUFACTURING"),
	MEDICAL_CLINIC(18,"natureofbusiness.clinic","MEDICAL / CLINIC"),
	MINING_RESOURCES(19,"natureofbusiness.mining","MINING / RESOURCES"),
	PHARMACEUTICAL(20,"natureofbusiness.pharma","PHARMACEUTICAL"),
	PRINTING_PUBLISHING(21,"natureofbusiness.printing","PRINTING / PUBLISHING"),
	REAL_ESTATE_DEVELOPER(22,"natureofbusiness.realestate","REAL ESTATE / DEVELOPER"),
	RENTAL_LEASING(23,"natureofbusiness.rental","RENTAL / LEASING"),
	SOCIAL_SERVICES(24,"natureofbusiness.social","SOCIAL SERVICES"),
	RESTAURANT_FOOD_STALL(25,"natureofbusiness.resto","RESTAURANT / FOOD STALL"),
	RETAIL_MERCHANDISING(26,"natureofbusiness.retail","RETAIL / MERCHANDISING"),
	SECURITY_SERVICES(27,"natureofbusiness.security","SECURITY SERVICES"),
	SPORTS_RECREATION(28,"natureofbusiness.sports","SPORTS / RECREATION"),
	TRADING_BROKERAGE(29,"natureofbusiness.trade","TRADING / BROKERAGE"),
	TRAVEL_LEISURE(30,"natureofbusiness.travel","TRAVEL / LEISURE"),
	TRANSPORTATION(31,"natureofbusiness.transpo","TRANSPORTATION"),
	UTILITIES(32,"natureofbusiness.utilities","UTILITIES"),
	WHOLESALE_DISTRIBUTOR(33,"natureofbusiness.wholesale","WHOLESALE / DISTRIBUTOR"),
	NA(34,"natureofbusiness.na","NA"),
	OTHERS(35,"natureofbusiness.others","OTHERS");
	
	private int code;
	private String value;
	private String dbValue;
	
	public final static String MODEL_ATTRIB_KEY = "natureOfBusinessList";
	
	public final static class BootstrapSingleton {
		public static final Map<String, NatureOfBusiness> lookupByValue = new HashMap<String, NatureOfBusiness>();
		public static final Map<BigDecimal, NatureOfBusiness> lookupByCode = new HashMap<BigDecimal, NatureOfBusiness>();
	}
	
	NatureOfBusiness(int code, String value,String dbValue) {
		this.code = code;
		this.value = value;
		this.dbValue = dbValue;
		BootstrapSingleton.lookupByValue.put(value, this);
		BootstrapSingleton.lookupByCode.put(new BigDecimal(code), this);
	}
	
	public int getCode() {
		return code;
	}

	public String getValue() {
		return value;
	}
	
	public String getDbValue(){
		return dbValue;
	}
}
