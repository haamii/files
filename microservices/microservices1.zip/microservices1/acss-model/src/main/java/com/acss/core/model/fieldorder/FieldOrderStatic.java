package com.acss.core.model.fieldorder;

/**
 * 
 * @author joliveros
 *
 */
public interface FieldOrderStatic {
	static final String FIELDORDER_MAINPAGE = "fieldorder/fieldOrder";
	static final String FIELDORDER_FILLUSERS = "ajax/fieldOrder/filluser";
	static final String FIELDORDER_FILLUSERSUNDER = "ajax/fieldOrder/filluserunder";
	static final String FIELDORDER_ALLOCATEDUSERS = "fragments/fieldorder/_users :: allocatedUser";
	static final String FIELDORDER_ALLOCATEDUSERSUNDER = "fragments/fieldorder/_usersunder :: allocatedUserUnder";
	static final String FIELDORDER_FRAGMENTSGROUPBOX = "fragments/fieldorder/_userGroupBox :: allocatedUserGroupBox";
	static final String FIELDORDER_UPDATEALLOC="ajax/fieldorder/updateallocatedacc";
	static final String FIELDORDER_REDIRECT="redirect:/fieldOrder";
	static final String FIELDORDER_REMAININGACCOUNTS="ajax/fieldOrder/remacctable";
	static final String FIELDORDER_FILLALLOCTABLE="ajax/fieldOrder/alloctable";
	static final String FIELDORDER_FILLUNALLOCTABLE="ajax/fieldOrder/unalloctable";
	static final String FIELDORDER_FILLUNALLOCTABLEHIDDEN="ajax/fieldOrder/unalloctablehidden";
	
	
	static final String FIELDORDER_FILLGROUPBOXUNALLOC="ajax/fieldOrder/fillGroupBoxalloc";
	static final String FIELDORDER_INITTEMP="ajax/fieldOrder/initTemp";
	
	static final String HEADERLINK = "fieldOrder";
	static final String HEADERLINK_UPDATEALLOC = "updalloc";
	static final String HEADERLINK_UPDATEUNALLOC = "updunalloc";
	
	static final String RSFIELDORDER_BRANCH_URL_KEY = "rs.utils.brancharea.url";
	static final String RSFIELDORDER_TEAM_URL_KEY = "rs.fieldorder.team.url";
	static final String RSFIELDORDER_USERID_URL_KEY = "rs.fieldorder.userid.url";
	static final String RSFIELDORDER_FILLALLOCATEDTABLE_URL_KEY = "rs.fieldorder.fillallocatedtable.url";
	static final String RSFIELDORDER_UPDATEALLOCACC = "rs.fieldorder.updateallocacc.url";
	static final String RSFIELDORDER_UPDATEUNALLOCACC = "rs.fieldorder.updateunallocacc.url";
	static final String RSFIELDORDER_GETUNALLOCACCOUNTS = "rs.fieldorder.getunallocaccounts.url";
	static final String RSFIELDORDER_GETUNALLOCACCTABLE = "rs.fieldorder.getunallocacctable.url";
	static final String RSFIELDORDER_GETFORHIDDEN = "rs.fieldorder.getunallocacctablehidden.url";
	static final String RSFIELDORDER_INITTEMP="rs.fieldorder.inittemp.url";
	
	
	static final String ENDPOINT_GETBRANCH = "getBranch";
	static final String ENDPOINT_GETTEAM = "getTeam";
	static final String ENDPOINT_GETUSERID = "getUserID";
	static final String ENDPOINT_FILLALLOCTABLE = "fillAllocTable";
	static final String ENDPOINT_UPDATEALLOC = "updateAllocAcc";
	static final String ENDPOINT_GETUNALLOCACCOUNTS = "getunallocaccounts";
	static final String ENDPOINT_GETUNALLOCTABLE = "getunalloctable";
	static final String ENDPOINT_UPDATEUNALLOC="updateUnAllocAcc";
	static final String ENDPOINT_INITTEMP="initTemp";
	static final String ENDPOINT_GETUNALLOCFORHIDDEN="getunalloctablehidden";
	
		
	static final String COMMANDGETBRANCH = "GETBRANCH";
	static final String COMMANDGETTEAM = "GETTEAM";
	static final String COMMANDGETUSERID = "GETUSERID";
	static final String COMMANDFILLALLOCTABLE = "FILLALLOCTABLE";
	static final String COMMAND_UPDATEALLOC = "COMMANDUPDATEALLOC";
	static final String COMMAND_UPDATEUNALLOC = "COMMANDUPDATEUNALLOC";
	static final String COMMAND_GETUNALLOCACC = "GETUNALLOCACC";
	static final String COMMAND_GETUNALLOCACCTABLE = "GETUNALLOCACCTABLE";
	static final String COMMAND_INITTEMP = "INITTEMP";
	static final String COMMAND_GETUNALLOCACCTABLEHIDDEN = "GETHIDDEN";
	static final String COMMAND_DEFAULTCOMMAND = "";
	
	static final String COMMAND_GETBRANCH = "getbranch";
	static final String COMMAND_RETRIEVETEAM = "retrieveteam";
	static final String COMMAND_RETRIEVEMCOLLECTIONACCOUNT = "retrievemcollaccount";
	static final String COMMAND_RETRIEVEMCOLLAGENCY = "retrieveMcollAgency";
	static final String COMMAND_RETRIEVEALLOCTABLE = "retrieveAllocTable";
	static final String COMMAND_GETREMAININGACCMODELMAP = "retaccmodelmap";
	static final String COMMAND_RETRIEVEUNALLOCTABLE = "retunalloc";
	
	
	static final String SUCCESSMESSAGE_ID="view.fieldorder.update.success";
	static final String ALLOCATEDSUCCESSMESSAGE_ID="view.fieldorder.allocated.update.success";
	
	
	static final String SEARCHPARAM_TEAMID="teamid";
	static final String SEARCHPARAM_BUCKET="bucket";
	static final String SEARCHPARAM_USERID="userid";
	static final String SEARCHPARAM_BRANCH="branchsearch";
	static final String SEARCHPARAM_AREA="areaGroup";
	
	static final String NAME_REMAININGACCOUNTS="Remaining Accounts";
	
	static final String SCRID="SCR000009";
}
