package com.acss.core.model.customerpayment;

public class CustomerECSHistory {
	private String etransactionid;
	private String estatus;
	private String eduedate;
	private String eamountdue;
	private String ereconciledate;
	private String ereconcileamount;
	private String erejectedreason;
	private String eremarks;
	
	public CustomerECSHistory(){}
	
	public String appendParameters(String uri){		
		uri=etransactionid!=null&&etransactionid.length()>0?uri+"etransactionid="+etransactionid+"&":uri;
		uri=estatus!=null&&estatus.length()>0?uri+"estatus="+estatus+"&":uri;
		uri=eduedate!=null&&eduedate.length()>0?uri+"eduedate="+eduedate+"&":uri;
		uri=eamountdue!=null&&eamountdue.length()>0?uri+"eamountdue="+eamountdue+"&":uri;
		uri=ereconciledate!=null&&ereconciledate.length()>0?uri+"ereconciledate="+ereconciledate+"&":uri;
		uri=ereconcileamount!=null&&ereconcileamount.length()>0?uri+"ereconcileamount="+ereconcileamount+"&":uri;
		uri=erejectedreason!=null&&erejectedreason.length()>0?uri+"erejectedreason="+erejectedreason+"&":uri;
		uri=eremarks!=null&&eremarks.length()>0?uri+"eremarks="+eremarks+"&":uri;
		return uri;
	}

	public String getEtransactionid() {
		return etransactionid;
	}

	public void setEtransactionid(String etransactionid) {
		this.etransactionid = etransactionid;
	}

	public String getEstatus() {
		return estatus;
	}

	public void setEstatus(String estatus) {
		this.estatus = estatus;
	}

	public String getEduedate() {
		return eduedate;
	}

	public void setEduedate(String eduedate) {
		this.eduedate = eduedate;
	}

	public String getEamountdue() {
		return eamountdue;
	}

	public void setEamountdue(String eamountdue) {
		this.eamountdue = eamountdue;
	}

	public String getEreconciledate() {
		return ereconciledate;
	}

	public void setEreconciledate(String ereconciledate) {
		this.ereconciledate = ereconciledate;
	}

	public String getEreconcileamount() {
		return ereconcileamount;
	}

	public void setEreconcileamount(String ereconcileamount) {
		this.ereconcileamount = ereconcileamount;
	}

	public String getErejectedreason() {
		return erejectedreason;
	}

	public void setErejectedreason(String erejectedreason) {
		this.erejectedreason = erejectedreason;
	}

	public String getEremarks() {
		return eremarks;
	}

	public void setEremarks(String eremarks) {
		this.eremarks = eremarks;
	}
	
}
