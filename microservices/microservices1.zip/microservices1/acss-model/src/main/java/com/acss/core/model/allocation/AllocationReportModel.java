package com.acss.core.model.allocation;

import java.math.BigDecimal;

public class AllocationReportModel {

	private String agreementCd;
	private String name;
	private String saleDate;
	private BigDecimal financeAmount;
	private BigDecimal paidPrincipal;
	private String customerCd;
	private String nowAddress;
	private String city;
	private String district;
	private Integer nowZipCode;
	private String mobileNo;
	private String corpAddress;
	private String officePhone;
	private BigDecimal emi;
	private String bucketBom;
	private BigDecimal outstandingAmount;
	private BigDecimal overdueAmount;
	private BigDecimal curBlcPrincipal;
	private BigDecimal needPayBounceCharge;
	private BigDecimal needPayCompensation;
	private String email;
	private String paymentType;
	private Integer numberOfInstalment;
	private String birthday;
	private String employmentsType;
	private String corpName;
	private String position;
	private String departmentType;
	private String nowHouseOwnerRelateType;
	private String businessType;
	private BigDecimal salary;
	private String bankName;
	private String referenceAddress;
	private String referenceMobile;
	private String storeCd;
	private String storeName;
	private String storeCity;
	private String hpLastDay;
	private String lastPaymentDate;
	private String reasonOfLastBounce;
	private BigDecimal delinquentAmount;
	private String hpFirstDay;
	private String productDescription;
	private BigDecimal outstandingBalance;
	private String writeOffDate;
	private String collectorId;
	private String contactResult;
	private Integer noOfAttempts;
	private String grouping;
	private String groupId;
	private String lastPaymentMode;
	private String allocateToField;
	private String previousAllocateToField;
	
	public final static String MODEL_ATTRIB_KEY = "alocationReportModel";

	// constructors
	public AllocationReportModel() {
		super();
	}

	public AllocationReportModel(String agreementCd, String name, String saleDate, BigDecimal financeAmount,
			BigDecimal paidPrincipal, String customerCd, String nowAddress, String city, String district,
			Integer nowZipCode, String mobileNo, String corpAddress, String officePhone, BigDecimal emi,
			String bucketBom, BigDecimal outstandingAmount, BigDecimal overdueAmount, BigDecimal curBlcPrincipal,
			BigDecimal needPayBounceCharge, BigDecimal needPayCompensation, String email, String paymentType,
			Integer numberOfInstalment, String birthday, String employmentsType, String corpName, String position,
			String departmentType, String nowHouseOwnerRelateType, String businessType, BigDecimal salary,
			String bankName, String referenceAddress, String referenceMobile, String storeCd, String storeName,
			String storeCity, String hpLastDay, String lastPaymentDate, String reasonOfLastBounce,
			BigDecimal delinquentAmount, String hpFirstDay, String productDescription, BigDecimal outstandingBalance,
			String writeOffDate, String collectorId, String contactResult, Integer noOfAttempts, String grouping,
			String groupId, String lastPaymentMode, String allocateToField, String previousAllocateToField) {
		super();
		this.agreementCd = agreementCd;
		this.name = name;
		this.saleDate = saleDate;
		this.financeAmount = financeAmount;
		this.paidPrincipal = paidPrincipal;
		this.customerCd = customerCd;
		this.nowAddress = nowAddress;
		this.city = city;
		this.district = district;
		this.nowZipCode = nowZipCode;
		this.mobileNo = mobileNo;
		this.corpAddress = corpAddress;
		this.officePhone = officePhone;
		this.emi = emi;
		this.bucketBom = bucketBom;
		this.outstandingAmount = outstandingAmount;
		this.overdueAmount = overdueAmount;
		this.curBlcPrincipal = curBlcPrincipal;
		this.needPayBounceCharge = needPayBounceCharge;
		this.needPayCompensation = needPayCompensation;
		this.email = email;
		this.paymentType = paymentType;
		this.numberOfInstalment = numberOfInstalment;
		this.birthday = birthday;
		this.employmentsType = employmentsType;
		this.corpName = corpName;
		this.position = position;
		this.departmentType = departmentType;
		this.nowHouseOwnerRelateType = nowHouseOwnerRelateType;
		this.businessType = businessType;
		this.salary = salary;
		this.bankName = bankName;
		this.referenceAddress = referenceAddress;
		this.referenceMobile = referenceMobile;
		this.storeCd = storeCd;
		this.storeName = storeName;
		this.storeCity = storeCity;
		this.hpLastDay = hpLastDay;
		this.lastPaymentDate = lastPaymentDate;
		this.reasonOfLastBounce = reasonOfLastBounce;
		this.delinquentAmount = delinquentAmount;
		this.hpFirstDay = hpFirstDay;
		this.productDescription = productDescription;
		this.outstandingBalance = outstandingBalance;
		this.writeOffDate = writeOffDate;
		this.collectorId = collectorId;
		this.contactResult = contactResult;
		this.noOfAttempts = noOfAttempts;
		this.grouping = grouping;
		this.groupId = groupId;
		this.lastPaymentMode = lastPaymentMode;
		this.allocateToField = allocateToField;
		this.previousAllocateToField = previousAllocateToField;
	}

	// setters

	public void setAgreementCd(String agreementCd) {
		this.agreementCd = agreementCd;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setSaleDate(String saleDate) {
		this.saleDate = saleDate;
	}

	public void setFinanceAmount(BigDecimal financeAmount) {
		this.financeAmount = financeAmount;
	}

	public void setPaidPrincipal(BigDecimal paidPrincipal) {
		this.paidPrincipal = paidPrincipal;
	}

	public void setCustomerCd(String customerCd) {
		this.customerCd = customerCd;
	}

	public void setNowAddress(String nowAddress) {
		this.nowAddress = nowAddress;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public void setNowZipCode(Integer nowZipCode) {
		this.nowZipCode = nowZipCode;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public void setCorpAddress(String corpAddress) {
		this.corpAddress = corpAddress;
	}

	public void setOfficePhone(String officePhone) {
		this.officePhone = officePhone;
	}

	public void setEmi(BigDecimal emi) {
		this.emi = emi;
	}

	public void setBucketBom(String bucketBom) {
		this.bucketBom = bucketBom;
	}

	public void setOutstandingAmount(BigDecimal outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}

	public void setOverdueAmount(BigDecimal overdueAmount) {
		this.overdueAmount = overdueAmount;
	}

	public void setCurBlcPrincipal(BigDecimal curBlcPrincipal) {
		this.curBlcPrincipal = curBlcPrincipal;
	}

	public void setNeedPayBounceCharge(BigDecimal needPayBounceCharge) {
		this.needPayBounceCharge = needPayBounceCharge;
	}

	public void setNeedPayCompensation(BigDecimal needPayCompensation) {
		this.needPayCompensation = needPayCompensation;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public void setNumberOfInstalment(Integer numberOfInstalment) {
		this.numberOfInstalment = numberOfInstalment;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public void setEmploymentsType(String employmentsType) {
		this.employmentsType = employmentsType;
	}

	public void setCorpName(String corpName) {
		this.corpName = corpName;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public void setDepartmentType(String departmentType) {
		this.departmentType = departmentType;
	}

	public void setNowHouseOwnerRelateType(String nowHouseOwnerRelateType) {
		this.nowHouseOwnerRelateType = nowHouseOwnerRelateType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public void setReferenceAddress(String referenceAddress) {
		this.referenceAddress = referenceAddress;
	}

	public void setReferenceMobile(String referenceMobile) {
		this.referenceMobile = referenceMobile;
	}

	public void setStoreCd(String storeCd) {
		this.storeCd = storeCd;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	public void setStoreCity(String storeCity) {
		this.storeCity = storeCity;
	}

	public void setHpLastDay(String hpLastDay) {
		this.hpLastDay = hpLastDay;
	}

	public void setLastPaymentDate(String lastPaymentDate) {
		this.lastPaymentDate = lastPaymentDate;
	}

	public void setReasonOfLastBounce(String reasonOfLastBounce) {
		this.reasonOfLastBounce = reasonOfLastBounce;
	}

	public void setDelinquentAmount(BigDecimal delinquentAmount) {
		this.delinquentAmount = delinquentAmount;
	}

	public void setHpFirstDay(String hpFirstDay) {
		this.hpFirstDay = hpFirstDay;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public void setOutstandingBalance(BigDecimal outstandingBalance) {
		this.outstandingBalance = outstandingBalance;
	}

	public void setWriteOffDate(String writeOffDate) {
		this.writeOffDate = writeOffDate;
	}

	public void setCollectorId(String collectorId) {
		this.collectorId = collectorId;
	}

	public void setContactResult(String contactResult) {
		this.contactResult = contactResult;
	}

	public void setNoOfAttempts(Integer noOfAttempts) {
		this.noOfAttempts = noOfAttempts;
	}

	public void setGrouping(String grouping) {
		this.grouping = grouping;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public void setLastPaymentMode(String lastPaymentMode) {
		this.lastPaymentMode = lastPaymentMode;
	}

	public void setAllocateToField(String allocateToField) {
		this.allocateToField = allocateToField;
	}

	public void setPreviousAllocateToField(String previousAllocateToField) {
		this.previousAllocateToField = previousAllocateToField;
	}

	// getters
	public String getAgreementCd() {
		return agreementCd;
	}

	public String getName() {
		return name;
	}

	public String getSaleDate() {
		return saleDate;
	}

	public BigDecimal getFinanceAmount() {
		return financeAmount;
	}

	public BigDecimal getPaidPrincipal() {
		return paidPrincipal;
	}

	public String getCustomerCd() {
		return customerCd;
	}

	public String getNowAddress() {
		return nowAddress;
	}

	public String getCity() {
		return city;
	}

	public String getDistrict() {
		return district;
	}

	public Integer getNowZipCode() {
		return nowZipCode;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public String getCorpAddress() {
		return corpAddress;
	}

	public String getOfficePhone() {
		return officePhone;
	}

	public BigDecimal getEmi() {
		return emi;
	}

	public String getBucketBom() {
		return bucketBom;
	}

	public BigDecimal getOutstandingAmount() {
		return outstandingAmount;
	}

	public BigDecimal getOverdueAmount() {
		return overdueAmount;
	}

	public BigDecimal getCurBlcPrincipal() {
		return curBlcPrincipal;
	}

	public BigDecimal getNeedPayBounceCharge() {
		return needPayBounceCharge;
	}

	public BigDecimal getNeedPayCompensation() {
		return needPayCompensation;
	}

	public String getEmail() {
		return email;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public Integer getNumberOfInstalment() {
		return numberOfInstalment;
	}

	public String getBirthday() {
		return birthday;
	}

	public String getEmploymentsType() {
		return employmentsType;
	}

	public String getCorpName() {
		return corpName;
	}

	public String getPosition() {
		return position;
	}

	public String getDepartmentType() {
		return departmentType;
	}

	public String getNowHouseOwnerRelateType() {
		return nowHouseOwnerRelateType;
	}

	public String getBusinessType() {
		return businessType;
	}

	public BigDecimal getSalary() {
		return salary;
	}

	public String getBankName() {
		return bankName;
	}

	public String getReferenceAddress() {
		return referenceAddress;
	}

	public String getReferenceMobile() {
		return referenceMobile;
	}

	public String getStoreCd() {
		return storeCd;
	}

	public String getStoreName() {
		return storeName;
	}

	public String getStoreCity() {
		return storeCity;
	}

	public String getHpLastDay() {
		return hpLastDay;
	}

	public String getLastPaymentDate() {
		return lastPaymentDate;
	}

	public String getReasonOfLastBounce() {
		return reasonOfLastBounce;
	}

	public BigDecimal getDelinquentAmount() {
		return delinquentAmount;
	}

	public String getHpFirstDay() {
		return hpFirstDay;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public BigDecimal getOutstandingBalance() {
		return outstandingBalance;
	}

	public String getWriteOffDate() {
		return writeOffDate;
	}

	public String getCollectorId() {
		return collectorId;
	}

	public String getContactResult() {
		return contactResult;
	}

	public Integer getNoOfAttempts() {
		return noOfAttempts;
	}

	public String getGrouping() {
		return grouping;
	}

	public String getGroupId() {
		return groupId;
	}

	public String getLastPaymentMode() {
		return lastPaymentMode;
	}

	public String getAllocateToField() {
		return allocateToField;
	}

	public String getPreviousAllocateToField() {
		return previousAllocateToField;
	}

}
