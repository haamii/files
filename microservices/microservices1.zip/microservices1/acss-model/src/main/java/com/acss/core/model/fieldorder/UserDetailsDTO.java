package com.acss.core.model.fieldorder;

import java.util.List;

public class UserDetailsDTO {
	public final static String MODEL_ATTRIB_KEY = "userdet";
	private List<UserDetails> userdetails;
	
	public UserDetailsDTO(){}

	public List<UserDetails> getUserdetails() {
		return userdetails;
	}

	public void setUserdetails(List<UserDetails> userdetails) {
		this.userdetails = userdetails;
	}
}
