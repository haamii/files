package com.acss.core.model.deskcontact;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.acss.core.model.BaseEntity;

public class ContactResultSaveDTO extends BaseEntity {
	
	private String agreementCd;
	private Integer action;
	private Integer contactResult; 
	private Integer subAction;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date promiseDate; 
	private Integer contactTo; 
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date followUpDateFrom;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date followUpDateTo; 
	private String comment; 
	private String otherAddress; 
	private Integer modeOfPayment; 
	private String transactionId;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date dateOfPayment; 
	private String chequeNo;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date chequeDate; 
	private Integer chequeStatus;
	private String bankName; 
	private BigDecimal emi; 
	private BigDecimal bounceCharges; 
	private BigDecimal latePaymentCharges; 
	private BigDecimal pickUpCharges; 
	private BigDecimal foreclosure; 
	private BigDecimal totalAmount;
	
	public ContactResultSaveDTO(String agreementCd, Integer action, Integer contactResult, Integer subAction,
			Date promiseDate, Integer contactTo, Date followUpDateFrom, Date followUpDateTo, String comment,
			String otherAddress, Integer modeOfPayment, String transactionId, Date dateOfPayment, String chequeNo,
			Date chequeDate, Integer chequeStatus, String bankName, BigDecimal emi, BigDecimal bounceCharges,
			BigDecimal latePaymentCharges, BigDecimal pickUpCharges, BigDecimal foreclosure, BigDecimal totalAmount) {
		super();
		this.agreementCd = agreementCd;
		this.action = action;
		this.contactResult = contactResult;
		this.subAction = subAction;
		this.promiseDate = promiseDate;
		this.contactTo = contactTo;
		this.followUpDateFrom = followUpDateFrom;
		this.followUpDateTo = followUpDateTo;
		this.comment = comment;
		this.otherAddress = otherAddress;
		this.modeOfPayment = modeOfPayment;
		this.transactionId = transactionId;
		this.dateOfPayment = dateOfPayment;
		this.chequeNo = chequeNo;
		this.chequeDate = chequeDate;
		this.chequeStatus = chequeStatus;
		this.bankName = bankName;
		this.emi = emi;
		this.bounceCharges = bounceCharges;
		this.latePaymentCharges = latePaymentCharges;
		this.pickUpCharges = pickUpCharges;
		this.foreclosure = foreclosure;
		this.totalAmount = totalAmount;
	}
	
	public ContactResultSaveDTO(){}
	
	public String getAgreementCd() {
		return agreementCd;
	}
	public void setAgreementCd(String agreementCd) {
		this.agreementCd = agreementCd;
	}
	public Integer getAction() {
		return action;
	}
	public void setAction(Integer action) {
		this.action = action;
	}
	public Integer getContactResult() {
		return contactResult;
	}
	public void setContactResult(Integer contactResult) {
		this.contactResult = contactResult;
	}
	public Integer getSubAction() {
		return subAction;
	}
	public void setSubAction(Integer subAction) {
		this.subAction = subAction;
	}
	public Date getPromiseDate() {
		return promiseDate;
	}
	public void setPromiseDate(Date promiseDate) {
		this.promiseDate = promiseDate;
	}
	public Integer getContactTo() {
		return contactTo;
	}
	public void setContactTo(Integer contactTo) {
		this.contactTo = contactTo;
	}
	public Date getFollowUpDateFrom() {
		return followUpDateFrom;
	}
	public void setFollowUpDateFrom(Date followUpDateFrom) {
		this.followUpDateFrom = followUpDateFrom;
	}
	public Date getFollowUpDateTo() {
		return followUpDateTo;
	}
	public void setFollowUpDateTo(Date followUpDateTo) {
		this.followUpDateTo = followUpDateTo;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getOtherAddress() {
		return otherAddress;
	}
	public void setOtherAddress(String otherAddress) {
		this.otherAddress = otherAddress;
	}
	public Integer getModeOfPayment() {
		return modeOfPayment;
	}
	public void setModeOfPayment(Integer modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public Date getDateOfPayment() {
		return dateOfPayment;
	}
	public void setDateOfPayment(Date dateOfPayment) {
		this.dateOfPayment = dateOfPayment;
	}
	public String getChequeNo() {
		return chequeNo;
	}
	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}
	public Date getChequeDate() {
		return chequeDate;
	}
	public void setChequeDate(Date chequeDate) {
		this.chequeDate = chequeDate;
	}
	public Integer getChequeStatus() {
		return chequeStatus;
	}
	public void setChequeStatus(Integer chequeStatus) {
		this.chequeStatus = chequeStatus;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public BigDecimal getEmi() {
		return emi;
	}
	public void setEmi(BigDecimal emi) {
		this.emi = emi;
	}
	public BigDecimal getBounceCharges() {
		return bounceCharges;
	}
	public void setBounceCharges(BigDecimal bounceCharges) {
		this.bounceCharges = bounceCharges;
	}
	public BigDecimal getLatePaymentCharges() {
		return latePaymentCharges;
	}
	public void setLatePaymentCharges(BigDecimal latePaymentCharges) {
		this.latePaymentCharges = latePaymentCharges;
	}
	public BigDecimal getPickUpCharges() {
		return pickUpCharges;
	}
	public void setPickUpCharges(BigDecimal pickUpCharges) {
		this.pickUpCharges = pickUpCharges;
	}
	public BigDecimal getForeclosure() {
		return foreclosure;
	}
	public void setForeclosure(BigDecimal foreclosure) {
		this.foreclosure = foreclosure;
	}
	public BigDecimal getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}
	
	public String getSyscode() {
		return agreementCd!=null?agreementCd.substring(20, 32):null;
	}
	
	public Integer getYearMonth() {
		return agreementCd!=null?Integer.parseInt(agreementCd.substring(33,39)):null;
	}
	
	public String getCustomerCd() {
		return agreementCd!=null?agreementCd.substring(40):null;
	}
	
	public Integer getFollowUpDateFromInt() {
		return setDateToYYYYMMDD(followUpDateFrom);
	}
	
	public Integer getFollowUpDateToInt() {
		return setDateToYYYYMMDD(followUpDateTo);
	}
	
	public Integer getPromiseDateInt() {
		return setDateToYYYYMMDD(promiseDate);
	}
	
	public Integer getDateOfPaymentInt() {
		return setDateToYYYYMMDD(dateOfPayment);
	}
	
	public Integer getChequeDateInt() {
		return setDateToYYYYMMDD(chequeDate);
	}
	
	public byte getContactResultGroup(){
		byte contactResultGroup = 0;
		if (contactResult!=null){
			for(ContactResultEnum result :  ContactResultEnum.values()){
				if (result.getCode() == contactResult)
					contactResultGroup = (byte) result.getContactResultGroup();
			}
		}
		return contactResultGroup;		
	}
	
	public byte getPriorityGroup() {
		byte priorityGroup = 0;
		if (contactResult!=null){
			for(ContactResultEnum result :  ContactResultEnum.values()){
				if (result.getCode() == contactResult)
					priorityGroup = (byte) result.getPriorityGroup();
			}
		}
		return priorityGroup;
	}
	
	public Integer setDateToYYYYMMDD(Date date) {
		Integer returnDate = null;
		if (date!=null) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			returnDate = Integer.valueOf(sdf.format(date));
		} return returnDate;
	}

}
