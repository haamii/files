package com.acss.core.model.deskcontact;

import java.math.BigDecimal;

public class ContactResultModel {
	
	private String contactResultGroup;
	private Integer account;
	private BigDecimal billAmount;
	private BigDecimal os;
	
	public final static String MODEL_ATTRIB_KEY = "contactDetail";
	
	/**
	 * @return the contactResultGroup
	 */
	public String getContactResultGroup() {
		return contactResultGroup;
	}
	/**
	 * @param contactResultGroup the contactResultGroup to set
	 */
	public void setContactResultGroup(String contactResultGroup) {
		this.contactResultGroup = contactResultGroup;
	}
	/**
	 * @return the account
	 */
	public Integer getAccount() {
		return account;
	}
	/**
	 * @param account the account to set
	 */
	public void setAccount(Integer account) {
		this.account = account;
	}
	/**
	 * @return the billAmount
	 */
	public BigDecimal getBillAmount() {
		return billAmount;
	}
	/**
	 * @param billAmount the billAmount to set
	 */
	public void setBillAmount(BigDecimal billAmount) {
		this.billAmount = billAmount;
	}
	/**
	 * @return the os
	 */
	public BigDecimal getOs() {
		return os;
	}
	/**
	 * @param os the os to set
	 */
	public void setOs(BigDecimal os) {
		this.os = os;
	}
	
	

}
