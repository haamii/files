package com.acss.core.model.reallocation;

public class CollectorModelReallocation {
	
	private String collectorCd;
	private String accountCode;
	private String delayStatus;
	/**
	 * @return the collectorCd
	 */
	public String getCollectorCd() {
		return collectorCd;
	}
	/**
	 * @param collectorCd the collectorCd to set
	 */
	public void setCollectorCd(String collectorCd) {
		this.collectorCd = collectorCd;
	}
	/**
	 * @return the accountCode
	 */
	public String getAccountCode() {
		return accountCode;
	}
	/**
	 * @param accountCode the accountCode to set
	 */
	public void setAccountCode(String accountCode) {
		this.accountCode = accountCode;
	}
	/**
	 * @return the delayStatus
	 */
	public String getDelayStatus() {
		return delayStatus;
	}
	/**
	 * @param delayStatus the delayStatus to set
	 */
	public void setDelayStatus(String delayStatus) {
		this.delayStatus = delayStatus;
	}
	
	

}
