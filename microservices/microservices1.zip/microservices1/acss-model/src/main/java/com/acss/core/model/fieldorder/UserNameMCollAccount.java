package com.acss.core.model.fieldorder;

public class UserNameMCollAccount {
	private String usercd;
	private String username;
	
	public UserNameMCollAccount(){}
	
	public String getUsercd() {
		return usercd;
	}
	public void setUsercd(String usercd) {
		this.usercd = usercd;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
}
