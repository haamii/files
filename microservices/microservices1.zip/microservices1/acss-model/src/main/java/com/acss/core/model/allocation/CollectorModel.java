package com.acss.core.model.allocation;

public class CollectorModel {
	
	private String collectorCd;
	private String accountCode;
	private String userName;
	/**
	 * @return the collectorCd
	 */
	public String getCollectorCd() {
		return collectorCd;
	}
	/**
	 * @param collectorCd the collectorCd to set
	 */
	public void setCollectorCd(String collectorCd) {
		this.collectorCd = collectorCd;
	}
	/**
	 * @return the accountCode
	 */
	public String getAccountCode() {
		return accountCode;
	}
	/**
	 * @param accountCode the accountCode to set
	 */
	public void setAccountCode(String accountCode) {
		this.accountCode = accountCode;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

}
