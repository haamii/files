package com.acss.core.model.fieldorder;

public class AllocatedCount {
	
	public AllocatedCount(){}
	
	private String count;
	
	private String agreementcd;
	
	private String prevfieldcollectorid;

	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}

	public String getAgreementcd() {
		return agreementcd;
	}

	public void setAgreementcd(String agreementcd) {
		this.agreementcd = agreementcd;
	}

	public String getPrevfieldcollectorid() {
		return prevfieldcollectorid;
	}

	public void setPrevfieldcollectorid(String prevfieldcollectorid) {
		this.prevfieldcollectorid = prevfieldcollectorid;
	}
}
