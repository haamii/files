package com.acss.core.model.fieldorder;

public class UnallocatedTable {
	
	private String uuserid;
	private String uname;
	private String uownaccounts;
	private String uaccounttoallocate;
	private String utotalallocation;
	private String uaccounttoallocatecopy;
	
	public UnallocatedTable(){}
	
	public String getUuserid() {
		return uuserid;
	}
	public void setUuserid(String uuserid) {
		this.uuserid = uuserid;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUownaccounts() {
		return uownaccounts;
	}

	public void setUownaccounts(String uownaccounts) {
		this.uownaccounts = uownaccounts;
	}

	public String getUaccounttoallocate() {
		return uaccounttoallocate;
	}

	public void setUaccounttoallocate(String uaccounttoallocate) {
		this.uaccounttoallocate = uaccounttoallocate;
	}

	public String getUtotalallocation() {
		return utotalallocation;
	}

	public void setUtotalallocation(String utotalallocation) {
		this.utotalallocation = utotalallocation;
	}

	public String getUaccounttoallocatecopy() {
		return uaccounttoallocatecopy;
	}

	public void setUaccounttoallocatecopy(String uaccounttoallocatecopy) {
		this.uaccounttoallocatecopy = uaccounttoallocatecopy;
	}
}
