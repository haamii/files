package com.acss.core.model.fieldorder;

public class UserNameMCollAgency {
	private String usercd;
	private String username;
	
	public UserNameMCollAgency(){}
	
	public String getUsercd() {
		return usercd;
	}
	public void setUsercd(String usercd) {
		this.usercd = usercd;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
}
