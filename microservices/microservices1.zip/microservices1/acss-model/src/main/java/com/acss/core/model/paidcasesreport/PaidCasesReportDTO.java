/**
 * 
 */
package com.acss.core.model.paidcasesreport;

import java.util.List;

/**
 * @author jpetronio
 *
 */
public class PaidCasesReportDTO {

	private PaidCasesSearchModel paidCasesSearch;
	private List<PaidCasesResultModel> paidCasesResult;

	public final static String MODEL_ATTRIB_KEY = "paidCasesForm";

	public PaidCasesReportDTO() {
		super();
	}

	public PaidCasesReportDTO(PaidCasesSearchModel paidCasesSearch, List<PaidCasesResultModel> paidCasesResult) {
		super();
		this.paidCasesSearch = paidCasesSearch;
		this.paidCasesResult = paidCasesResult;
	}

	public void setPaidCasesSearch(PaidCasesSearchModel paidCasesSearch) {
		this.paidCasesSearch = paidCasesSearch;
	}

	public void setPaidCasesResult(List<PaidCasesResultModel> paidCasesResult) {
		this.paidCasesResult = paidCasesResult;
	}

	public PaidCasesSearchModel getPaidCasesSearch() {
		return paidCasesSearch;
	}

	public List<PaidCasesResultModel> getPaidCasesResult() {
		return paidCasesResult;
	}

	public static String getModelAttribKey() {
		return MODEL_ATTRIB_KEY;
	}
	
	
	
}
