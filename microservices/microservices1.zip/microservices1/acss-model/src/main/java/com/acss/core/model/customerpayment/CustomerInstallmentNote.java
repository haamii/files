package com.acss.core.model.customerpayment;

public class CustomerInstallmentNote {
	private String iterm;
	private String iperiod;
	private String iinstallment;
	private String ibalprincipal;
	private String ibalinterest;
	private String ibalpenalty;
	private String ibalbouncecharge;
	private String ibalothercharge;
	
	public CustomerInstallmentNote(){}
	
	public String appendParameters(String uri){		
		uri=iterm!=null&&iterm.length()>0?uri+"iterm="+iterm+"&":uri;
		uri=iperiod!=null&&iperiod.length()>0?uri+"iperiod="+iperiod+"&":uri;
		uri=iinstallment!=null&&iinstallment.length()>0?uri+"iinstallment="+iinstallment+"&":uri;
		uri=ibalprincipal!=null&&ibalprincipal.length()>0?uri+"ibalprincipal="+ibalprincipal+"&":uri;
		uri=ibalinterest!=null&&ibalinterest.length()>0?uri+"ibalinterest="+ibalinterest+"&":uri;
		uri=ibalpenalty!=null&&ibalpenalty.length()>0?uri+"ibalpenalty="+ibalpenalty+"&":uri;
		uri=ibalbouncecharge!=null&&ibalbouncecharge.length()>0?uri+"ibalbouncecharge="+ibalbouncecharge+"&":uri;
		uri=ibalothercharge!=null&&ibalothercharge.length()>0?uri+"ibalothercharge="+ibalothercharge+"&":uri;
		return uri;
	}

	public String getIterm() {
		return iterm;
	}

	public void setIterm(String iterm) {
		this.iterm = iterm;
	}

	public String getIperiod() {
		return iperiod;
	}

	public void setIperiod(String iperiod) {
		this.iperiod = iperiod;
	}

	public String getIinstallment() {
		return iinstallment;
	}

	public void setIinstallment(String iinstallment) {
		this.iinstallment = iinstallment;
	}

	public String getIbalprincipal() {
		return ibalprincipal;
	}

	public void setIbalprincipal(String ibalprincipal) {
		this.ibalprincipal = ibalprincipal;
	}

	public String getIbalinterest() {
		return ibalinterest;
	}

	public void setIbalinterest(String ibalinterest) {
		this.ibalinterest = ibalinterest;
	}

	public String getIbalpenalty() {
		return ibalpenalty;
	}

	public void setIbalpenalty(String ibalpenalty) {
		this.ibalpenalty = ibalpenalty;
	}

	public String getIbalbouncecharge() {
		return ibalbouncecharge;
	}

	public void setIbalbouncecharge(String ibalbouncecharge) {
		this.ibalbouncecharge = ibalbouncecharge;
	}

	public String getIbalothercharge() {
		return ibalothercharge;
	}

	public void setIbalothercharge(String ibalothercharge) {
		this.ibalothercharge = ibalothercharge;
	}
}
