package com.acss.core.model.deskcontact;

import java.math.BigDecimal;

public class CustomerInfoModel {
	
	private String customerCd;
	private String name;
	private BigDecimal totalOS;
	private BigDecimal totalPay;
	private int account;
	private String type;
	private int bucketBom;
	private int delayStatus;
	private String followUpDate;
	private String lastAccount;
	private String creDate;
	private String creTime;
	private String contactResult;
	private String action;
	private String followUpDateTo;
	private String name1;
	private String name2;
	private BigDecimal mobileNo1;
	private BigDecimal mobileNo2;
	private String homeTel1;
	private String homeTel2;
	private String corpTel1;
	
	public final static String MODEL_ATTRIB_KEY = "customerInfo";
	
	public CustomerInfoModel(){}
	
	public CustomerInfoModel(String customerCd, String name,
			BigDecimal totalOS, BigDecimal totalPay, int account, String type,
			int bucketBom, int delayStatus, String followUpDate,
			String lastAccount, String creDate, String creTime,
			String contactResult, String action, String followUpDateTo,
			String name1, String name2, BigDecimal mobileNo1, BigDecimal mobileNo2,
			String homeTel1, String homeTel2, String corpTel1) {
		this.customerCd = customerCd;
		this.name = name;
		this.totalOS = totalOS;
		this.totalPay = totalPay;
		this.account = account;
		this.type = type;
		this.bucketBom = bucketBom;
		this.delayStatus = delayStatus;
		this.followUpDate = followUpDate;
		this.lastAccount = lastAccount;
		this.creDate = creDate;
		this.creTime = creTime;
		this.contactResult = contactResult;
		this.action = action;
		this.followUpDateTo = followUpDateTo;
		this.name1 = name1;
		this.name2 = name2;
		this.mobileNo1 = mobileNo1;
		this.mobileNo2 = mobileNo2;
		this.homeTel1 = homeTel1;
		this.homeTel2 = homeTel2;
		this.corpTel1 = corpTel1;
	}
	/**
	 * @return the customerCd
	 */
	public String getCustomerCd() {
		return customerCd;
	}
	/**
	 * @param customerCd the customerCd to set
	 */
	public void setCustomerCd(String customerCd) {
		this.customerCd = customerCd;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the totalOS
	 */
	public BigDecimal getTotalOS() {
		return totalOS;
	}
	/**
	 * @param totalOS the totalOS to set
	 */
	public void setTotalOS(BigDecimal totalOS) {
		this.totalOS = totalOS;
	}
	/**
	 * @return the totalPay
	 */
	public BigDecimal getTotalPay() {
		return totalPay;
	}
	/**
	 * @param totalPay the totalPay to set
	 */
	public void setTotalPay(BigDecimal totalPay) {
		this.totalPay = totalPay;
	}
	/**
	 * @return the account
	 */
	public int getAccount() {
		return account;
	}
	/**
	 * @param account the account to set
	 */
	public void setAccount(int account) {
		this.account = account;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the bucketBom
	 */
	public int getBucketBom() {
		return bucketBom;
	}
	/**
	 * @param bucketBom the bucketBom to set
	 */
	public void setBucketBom(int bucketBom) {
		this.bucketBom = bucketBom;
	}
	/**
	 * @return the delayStatus
	 */
	public int getDelayStatus() {
		return delayStatus;
	}
	/**
	 * @param delayStatus the delayStatus to set
	 */
	public void setDelayStatus(int delayStatus) {
		this.delayStatus = delayStatus;
	}
	/**
	 * @return the followUpDate
	 */
	public String getFollowUpDate() {
		return followUpDate;
	}
	/**
	 * @param followUpDate the followUpDate to set
	 */
	public void setFollowUpDate(String followUpDate) {
		this.followUpDate = followUpDate;
	}
	/**
	 * @return the lastAccount
	 */
	public String getLastAccount() {
		return lastAccount;
	}
	/**
	 * @param lastAccount the lastAccount to set
	 */
	public void setLastAccount(String lastAccount) {
		this.lastAccount = lastAccount;
	}
	/**
	 * @return the creDate
	 */
	public String getCreDate() {
		return creDate;
	}
	/**
	 * @param creDate the creDate to set
	 */
	public void setCreDate(String creDate) {
		this.creDate = creDate;
	}
	/**
	 * @return the creTime
	 */
	public String getCreTime() {
		return creTime;
	}
	/**
	 * @param creTime the creTime to set
	 */
	public void setCreTime(String creTime) {
		this.creTime = creTime;
	}
	/**
	 * @return the contactResult
	 */
	public String getContactResult() {
		return contactResult;
	}
	/**
	 * @param contactResult the contactResult to set
	 */
	public void setContactResult(String contactResult) {
		this.contactResult = contactResult;
	}
	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}
	/**
	 * @return the followUpDateTo
	 */
	public String getFollowUpDateTo() {
		return followUpDateTo;
	}
	/**
	 * @param followUpDateTo the followUpDateTo to set
	 */
	public void setFollowUpDateTo(String followUpDateTo) {
		this.followUpDateTo = followUpDateTo;
	}

	/**
	 * @return the name1
	 */
	public String getName1() {
		return name1;
	}

	/**
	 * @param name1 the name1 to set
	 */
	public void setName1(String name1) {
		this.name1 = name1;
	}

	/**
	 * @return the name2
	 */
	public String getName2() {
		return name2;
	}

	/**
	 * @param name2 the name2 to set
	 */
	public void setName2(String name2) {
		this.name2 = name2;
	}

	/**
	 * @return the mobileNo1
	 */
	public BigDecimal getMobileNo1() {
		return mobileNo1;
	}

	/**
	 * @param mobileNo1 the mobileNo1 to set
	 */
	public void setMobileNo1(BigDecimal mobileNo1) {
		this.mobileNo1 = mobileNo1;
	}

	/**
	 * @return the mobileNo2
	 */
	public BigDecimal getMobileNo2() {
		return mobileNo2;
	}

	/**
	 * @param mobileNo2 the mobileNo2 to set
	 */
	public void setMobileNo2(BigDecimal mobileNo2) {
		this.mobileNo2 = mobileNo2;
	}

	/**
	 * @return the homeTel1
	 */
	public String getHomeTel1() {
		return homeTel1;
	}

	/**
	 * @param homeTel1 the homeTel1 to set
	 */
	public void setHomeTel1(String homeTel1) {
		this.homeTel1 = homeTel1;
	}

	/**
	 * @return the homeTel2
	 */
	public String getHomeTel2() {
		return homeTel2;
	}

	/**
	 * @param homeTel2 the homeTel2 to set
	 */
	public void setHomeTel2(String homeTel2) {
		this.homeTel2 = homeTel2;
	}

	/**
	 * @return the corpTel1
	 */
	public String getCorpTel1() {
		return corpTel1;
	}

	/**
	 * @param corpTel1 the corpTel1 to set
	 */
	public void setCorpTel1(String corpTel1) {
		this.corpTel1 = corpTel1;
	}
	
	
}
