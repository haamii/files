package com.acss.core.model.feedbackreport;

public class FeedbackSearchModel {
	
	private Integer lastCallDateFrom;
	private Integer lastCallDateTo;
	private Integer feedback;
	
	public FeedbackSearchModel(Integer lastCallDateFrom, Integer lastCallDateTo, Integer feedback) {
		super();
		this.lastCallDateFrom = lastCallDateFrom;
		this.lastCallDateTo = lastCallDateTo;
		this.feedback = feedback;
	}
	/**
	 * @return the lastCallDateFrom
	 */
	public Integer getLastCallDateFrom() {
		return lastCallDateFrom;
	}
	/**
	 * @param lastCallDateFrom the lastCallDateFrom to set
	 */
	public void setLastCallDateFrom(Integer lastCallDateFrom) {
		this.lastCallDateFrom = lastCallDateFrom;
	}
	/**
	 * @return the lastCallDateTo
	 */
	public Integer getLastCallDateTo() {
		return lastCallDateTo;
	}
	/**
	 * @param lastCallDateTo the lastCallDateTo to set
	 */
	public void setLastCallDateTo(Integer lastCallDateTo) {
		this.lastCallDateTo = lastCallDateTo;
	}
	/**
	 * @return the feedback
	 */
	public Integer getFeedback() {
		return feedback;
	}
	/**
	 * @param feedback the feedback to set
	 */
	public void setFeedback(Integer feedback) {
		this.feedback = feedback;
	}
}
