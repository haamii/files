package com.acss.core.model;

import java.math.BigDecimal;

import org.joda.time.DateTime;
import org.joda.time.LocalTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

/**
 * Utility Class for Date Manipulations and Conversions.
 * The most common operation will be converting
 * DateTime object into BigDecimal with YYYYMMDD format and
 * LocalTime object into BigDecimal with HHMMSS format.
 * 
 * @author gvargas
 *
 */
public class ACSSDateUtil {
	
	private static final String PROPERTY_NAME_CONFIG_DATE_FORMAT = "yyyyMMdd";
	private static final String PROPERTY_NAME_CONFIG_TIME_FORMAT = "HHmmss";
	private static final String PROPERTY_NAME_CONFIG_DATETIME_FORMAT = "yyyyMMddHHmmss";

	private final static DateTimeFormatter dateFormat = DateTimeFormat
			.forPattern(PROPERTY_NAME_CONFIG_DATE_FORMAT);

	private final static DateTimeFormatter timeFormat = DateTimeFormat
			.forPattern(PROPERTY_NAME_CONFIG_TIME_FORMAT);
	
	private final static DateTimeFormatter dateTimeFormat = DateTimeFormat
			.forPattern(PROPERTY_NAME_CONFIG_DATETIME_FORMAT);
	
	/**
	 * Transforms from BigDecimal with this format YYYYMMDDHHmmss into DateTime object.
	 * @param date
	 * @return
	 */
	public static DateTime getDateAsDateTimeFromBigDecimalDateTime(BigDecimal datetime){
		return dateTimeFormat.parseDateTime(datetime.toString());
	}
	
	/**
	 * Transforms the DateTime(now) Object into BigDecimal Date used by the Old
	 * HPS Database structure.
	 * from DateTime(now) into YYYYMMDDHHmmss in BigDecimal Type.
	 * @return BigDecimal
	 */
	public static BigDecimal getDateAsYYYYMMDDHHmmssFromDateTime() {

		DateTime now = new DateTime();
		return new BigDecimal(now.toString(dateTimeFormat));
	}
	
	/**
	 * Transforms the DateTime Object into BigDecimal Date used by the Old HPS
	 * Database structure.
	 * from DateTime into YYYYMMDDHHmmss in BigDecimal Type.
	 * @param jodaDateTime
	 * @return BigDecimal (in YYYYMMDDHHmmss)
	 */
	public static BigDecimal getDateAsYYYYMMDDHHmmssFromDateTime(DateTime jodaDateTime) {
		DateTime now = jodaDateTime;
		return new BigDecimal(now.toString(dateTimeFormat));
	}
	
	/**
	 * Transforms from BigDecimal with this format YYYYMMDD into DateTime object.
	 * 
	 * @param date
	 * @return
	 */
	public static DateTime getDateAsDateTimeFromBigDecimal(BigDecimal date) {
		return dateFormat.parseDateTime(date.toString());
	}

	/**
	 * Transforms the DateTime Object into BigDecimal Date used by the Old HPS
	 * Database structure.
	 * from DateTime into YYYYMMDD in BigDecimal Type.
	 * @param jodaDateTime
	 * @return BigDecimal (in YYYYMMDD)
	 */
	public static BigDecimal getDateAsYYYYMMDDFromDateTime(DateTime jodaDateTime) {

		DateTime now = jodaDateTime==null?new DateTime():jodaDateTime;

		return new BigDecimal(now.toString(dateFormat));
	}

	/**
	 * Transforms the DateTime(now) Object into BigDecimal Date used by the Old
	 * HPS Database structure.
	 * from DateTime(now) into YYYYMMDD in BigDecimal Type.
	 * @return BigDecimal
	 */
	public static BigDecimal getDateAsYYYYMMDDFromDateTime() {

		DateTime now = new DateTime();
		return new BigDecimal(now.toString(dateFormat));
	}
	
	/**
	 * Transforms the LocalTime Object into BigDecimal Time used by the old HPS Database
	 * structure.
	 * from LocalTime into HHMMSS in BigDecimal Type.
	 * 
	 * @param jodaDateTime
	 * @return BigDecimal
	 */
	public static BigDecimal getTimeAsHHMMSSFromLocalTime(LocalTime jodaDateTime) {

		LocalTime now = jodaDateTime;
		return new BigDecimal(now.toString(timeFormat));
	}
	
	/**
	 * Transforms the BigDecimal Object into LocalTime Time
	 * from BigDecimal into HHMMSS in LocalTime Type.
	 * 
	 * @param date
	 * @return LocalTime
	 */
	public static LocalTime getTimeAsLocalTimeFromBigDecimal(BigDecimal date) {
		//format the number into 6 digit padded by zeroes.
		String convertThis = String.format("%06d", date.intValue());
		return timeFormat.parseLocalTime(convertThis);
	}
	
	/**
	 * Transforms the DateTime(now) Object into BigDecimal Time used by the Old
	 * HPS Database structure.
	 * from DateTime(now) into HHMMSS in BigDecimal Type.
	 * @return
	 */
	public static BigDecimal getTimeAsHHMMSSFromDateTime() {
		LocalTime now = new LocalTime();
		return new BigDecimal(now.toString(timeFormat));
	}
}
