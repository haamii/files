/**
 * 
 */
package com.acss.core.model.deskcontact;

import java.math.BigDecimal;

/**
 * @author cvicente
 *
 */
public class CollectionResultModel {
	
	private Integer beginAccount;
	private BigDecimal beginBillAmount;
	private BigDecimal beginOs;
	private Integer resultAccount;
	private BigDecimal resultBillAmount;
	private BigDecimal resultOs;
	
	public final static String MODEL_ATTRIB_KEY = "collectionDetail";
	
	public CollectionResultModel(Integer beginAccount, BigDecimal beginBillAmount,
			BigDecimal beginOs, Integer resultAccount, BigDecimal resultBillAmount, BigDecimal resultOs) {
		this.beginAccount = beginAccount;
		this.beginBillAmount = beginBillAmount;
		this.beginOs = beginOs;
		this.resultAccount = resultAccount;
		this.resultBillAmount = resultBillAmount;
		this.resultOs = resultOs;
	}
	
	public CollectionResultModel(){}
	
	/**
	 * @return the beginAccount
	 */
	public Integer getBeginAccount() {
		return beginAccount;
	}
	/**
	 * @param beginAccount the beginAccount to set
	 */
	public void setBeginAccount(Integer beginAccount) {
		this.beginAccount = beginAccount;
	}
	/**
	 * @return the beginBillAmount
	 */
	public BigDecimal getBeginBillAmount() {
		return beginBillAmount;
	}
	/**
	 * @param beginBillAmount the beginBillAmount to set
	 */
	public void setBeginBillAmount(BigDecimal beginBillAmount) {
		this.beginBillAmount = beginBillAmount;
	}
	/**
	 * @return the beginOs
	 */
	public BigDecimal getBeginOs() {
		return beginOs;
	}
	/**
	 * @param beginOs the beginOs to set
	 */
	public void setBeginOs(BigDecimal beginOs) {
		this.beginOs = beginOs;
	}
	/**
	 * @return the resultAccount
	 */
	public Integer getResultAccount() {
		return resultAccount;
	}
	/**
	 * @param resultAccount the resultAccount to set
	 */
	public void setResultAccount(Integer resultAccount) {
		this.resultAccount = resultAccount;
	}
	/**
	 * @return the resultBillAmount
	 */
	public BigDecimal getResultBillAmount() {
		return resultBillAmount;
	}
	/**
	 * @param resultBillAmount the resultBillAmount to set
	 */
	public void setResultBillAmount(BigDecimal resultBillAmount) {
		this.resultBillAmount = resultBillAmount;
	}
	/**
	 * @return the resultOs
	 */
	public BigDecimal getResultOs() {
		return resultOs;
	}
	/**
	 * @param resultOs the resultOs to set
	 */
	public void setResultOs(BigDecimal resultOs) {
		this.resultOs = resultOs;
	}
	
	public String getAccountPercent(Integer parmBeginAccount, Integer parmResultAccount) {
		Float accountPercentage = (float) (parmResultAccount*100.0F/parmBeginAccount);
		BigDecimal bd = new BigDecimal(Float.toString(accountPercentage));
		bd = bd.setScale(2, BigDecimal.ROUND_HALF_UP);
		return bd.toString();
	}
	
	public String getBillAmountPercentage(BigDecimal parmBeginBillAmount, BigDecimal parmResultBillAmount) {
		BigDecimal percent = new BigDecimal("100");
		BigDecimal billAmountPercentage = parmResultBillAmount.multiply(percent)
				.divide(parmBeginBillAmount,2, BigDecimal.ROUND_HALF_UP);
		return billAmountPercentage.toString();
	}
	
	public String getTotalOSPercentage(BigDecimal parmBeginOS, BigDecimal parmResultOS) {
		BigDecimal percent = new BigDecimal("100");
		BigDecimal resultOSPercentage = parmResultOS.multiply(percent)
				.divide(parmBeginOS,2, BigDecimal.ROUND_HALF_UP);
		return resultOSPercentage.toString();
	}

}
