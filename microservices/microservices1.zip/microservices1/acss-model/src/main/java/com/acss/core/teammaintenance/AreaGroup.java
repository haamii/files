package com.acss.core.teammaintenance;

public class AreaGroup {
	
	private String teamId;
	private String areaGroup;
	private String remainingAccounts;
	
	/**
	 * @return the teamId
	 */
	public String getTeamId() {
		return teamId;
	}
	/**
	 * @param teamId the teamId to set
	 */
	public void setTeamId(String teamId) {
		this.teamId = teamId;
	}
	/**
	 * @return the areaGroup
	 */
	public String getAreaGroup() {
		return areaGroup;
	}
	/**
	 * @param areaGroup the areaGroup to set
	 */
	public void setAreaGroup(String areaGroup) {
		this.areaGroup = areaGroup;
	}
	/**
	 * @return the remainingAccounts
	 */
	public String getRemainingAccounts() {
		return remainingAccounts;
	}
	/**
	 * @param remainingAccounts the remainingAccounts to set
	 */
	public void setRemainingAccounts(String remainingAccounts) {
		this.remainingAccounts = remainingAccounts;
	}
	
}
