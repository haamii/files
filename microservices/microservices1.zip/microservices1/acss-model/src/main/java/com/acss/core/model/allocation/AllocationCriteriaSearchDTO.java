package com.acss.core.model.allocation;

import java.util.List;

import com.acss.core.model.BaseEntity;
import com.acss.core.model.fieldorder.RemainingAccountModelMap;


/**
 * DTO for allocation searching.
 *
 */
public class AllocationCriteriaSearchDTO extends BaseEntity{
	
	private String area;
	private Integer delayStatus;
	private String branch;
	private Integer remainingAccounts;
	private String allCollectors;
	private String jsonallocstorage;
	private List<RemainingAccountModelMap> remainingAccountModelMap; 
	private RemainingAccountModelMap remAccount;
	private List<AccountAllocationDTO> allocate;
	private String accountToAllocate;
	private Integer category;
	private Integer customerGroup;
	
	public final static String MODEL_ATTRIB_KEY = "allocationSearchForm";

	public AllocationCriteriaSearchDTO() {}
	
	/**
	 * Append all present parameters as query string in the GET request
	 * @param uri
	 * @return uri with parameters.
	 */
	public String appendParameters(String uri){
		uri=area!=null?uri+"area="+area+"&":uri;
		uri=delayStatus!=null?uri+"delayStatus="+delayStatus+"&":uri;
		uri=branch!=null?uri+"branch="+branch+"&":uri;
		uri=remainingAccounts!=null?uri+"remainingAccounts="+remainingAccounts+"&":uri;
		uri=allCollectors!=null?uri+"allCollectors="+allCollectors+"&":uri;
		uri=category!=null?uri+"category="+category+"&":uri;
		uri=customerGroup!=null?uri+"customerGroup="+customerGroup+"&":uri;
		return uri;
	}
	
	public AllocationCriteriaSearchDTO(String area, Integer delayStatus, String branch, Integer category, Integer customerGroup) {
		this.area = area;
		this.delayStatus = delayStatus;
		this.branch = branch;
		this.category = category;
		this.customerGroup = customerGroup;
	}
	
	public AllocationCriteriaSearchDTO(String branch, Integer remainingAccounts) {
		this.branch = branch;
		this.remainingAccounts = remainingAccounts;
	}
	
	public AllocationCriteriaSearchDTO(String branch, String allCollectors, Integer remainingAccounts) {
		this.branch = branch;
		this.remainingAccounts = remainingAccounts;
		this.allCollectors = allCollectors;
	}
	
	public AllocationCriteriaSearchDTO(String area, String branch, Integer delayStatus, Integer remainingAccounts, Integer category) {
		this.area = area;
		this.delayStatus = delayStatus;
		this.branch = branch;
		this.remainingAccounts = remainingAccounts;
		this.category = category;
	}

	/**
	 * @return the area
	 */
	public String getArea() {
		return area;
	}

	/**
	 * @param area the area to set
	 */
	public void setArea(String area) {
		this.area = area;
	}

	public Integer getDelayStatus() {
		return delayStatus;
	}

	public void setDelayStatus(Integer delayStatus) {
		this.delayStatus = delayStatus;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public Integer getRemainingAccounts() {
		return remainingAccounts;
	}

	public void setRemainingAccounts(Integer remainingAccounts) {
		this.remainingAccounts = remainingAccounts;
	}

	/**
	 * @return the allCollectors
	 */
	public String getAllCollectors() {
		return allCollectors;
	}

	/**
	 * @param allCollectors the allCollectors to set
	 */
	public void setAllCollectors(String allCollectors) {
		this.allCollectors = allCollectors;
	}

	public List<RemainingAccountModelMap> getRemainingAccountModelMap() {
		return remainingAccountModelMap;
	}

	public void setRemainingAccountModelMap(List<RemainingAccountModelMap> remainingAccountModelMap) {
		this.remainingAccountModelMap = remainingAccountModelMap;
	}

	public String getJsonallocstorage() {
		return jsonallocstorage;
	}

	public void setJsonallocstorage(String jsonallocstorage) {
		this.jsonallocstorage = jsonallocstorage;
	}

	public List<AccountAllocationDTO> getAllocate() {
		return allocate;
	}

	public void setAllocate(List<AccountAllocationDTO> allocate) {
		this.allocate = allocate;
	}

	public String getAccountToAllocate() {
		return accountToAllocate;
	}

	public void setAccountToAllocate(String accountToAllocate) {
		this.accountToAllocate = accountToAllocate;
	}

	public RemainingAccountModelMap getRemAccount() {
		return remAccount;
	}

	public void setRemAccount(RemainingAccountModelMap remAccount) {
		this.remAccount = remAccount;
	}
	
	/**
	 * @return the category
	 */
	public Integer getCategory() {
		return category;
	}

	/**
	 * @param category the category to set
	 */
	public void setCategory(Integer category) {
		this.category = category;
	}

	/**
	 * @return the customerGroup
	 */
	public Integer getCustomerGroup() {
		return customerGroup;
	}

	/**
	 * @param customerGroup the customerGroup to set
	 */
	public void setCustomerGroup(Integer customerGroup) {
		this.customerGroup = customerGroup;
	}
	
	
}
