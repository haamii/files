package com.acss.core.model.deskcontact;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * @author sgalvez
 *
 */
public enum ChequeStatusEnum {
	CLEARED(0,"CHQ CLEARED"),
	BOUNCED(1, "BOUNCED");
	
	private int code;
	private String value;
	
	private final static class BootstrapSingleton {
		public static final Map<String, ChequeStatusEnum> lookupByValue = new HashMap<String, ChequeStatusEnum>();
		public static final Map<BigDecimal, ChequeStatusEnum> lookupByCode = new HashMap<BigDecimal, ChequeStatusEnum>();
	}
	
	ChequeStatusEnum(int code, String value) {
		this.code = code;
		this.value = value;
		BootstrapSingleton.lookupByValue.put(value, this);
		BootstrapSingleton.lookupByCode.put(new BigDecimal(code), this);
	}
	
	public int getCode() {
		return code;
	}

	public String getValue() {
		return value;
	}
}
