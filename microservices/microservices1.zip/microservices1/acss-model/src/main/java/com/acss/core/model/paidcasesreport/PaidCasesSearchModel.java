/**
 * 
 */
package com.acss.core.model.paidcasesreport;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

/**
 * @author jpetronio
 *
 */
public class PaidCasesSearchModel {

	private String agreementCd; 
	private String customerName;
	private String userName;
	private Integer modeOfPayment;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date dateOfPaymentFrom;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date dateOfPaymentTo;
	private Integer chequeStatus;
	
	//constructors
	public PaidCasesSearchModel() {
		super();
	}
	/**
	 * Append all present parameters as query string in the GET request
	 * @param uri
	 * @return uri with parameters.
	 */
	
	public String appendParameters(String uri){
		uri=agreementCd!=null?uri+"agreementCd="+agreementCd+"&":uri;
		uri=customerName!=null?uri+"customerName="+customerName+"&":uri;
		uri=userName!=null?uri+"userName="+userName+"&":uri;
		uri=modeOfPayment!=null?uri+"modeOfPayment="+modeOfPayment+"&":uri;
		uri=dateOfPaymentFrom!=null?uri+"dateOfPaymentFrom="+setDateToYYYYMMDD(dateOfPaymentFrom)+"&":uri;
		uri=dateOfPaymentTo!=null?uri+"dateOfPaymentTo="+setDateToYYYYMMDD(dateOfPaymentTo)+"&":uri;
		uri=chequeStatus!=null?uri+"chequeStatus="+chequeStatus+"&":uri;
		return uri;
	}


	public PaidCasesSearchModel(String agreementCd, String customerName, String userName, Integer modeOfPayment,
			Date dateOfPaymentFrom, Date dateOfPaymentTo, Integer chequeStatus) {
		super();
		this.agreementCd = agreementCd;
		this.customerName = customerName;
		this.userName = userName;
		this.modeOfPayment = modeOfPayment;
		this.dateOfPaymentFrom = dateOfPaymentFrom;
		this.dateOfPaymentTo = dateOfPaymentTo;
		this.chequeStatus = chequeStatus;
	}

//setters
	public void setAgreementCd(String agreementCd) {
		this.agreementCd = agreementCd;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setModeOfPayment(Integer modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}

	public void setDateOfPaymentFrom(Date dateOfPaymentFrom) {
		this.dateOfPaymentFrom = dateOfPaymentFrom;
	}

	public void setDateOfPaymentTo(Date dateOfPaymentTo) {
		this.dateOfPaymentTo = dateOfPaymentTo;
	}

	public void setChequeStatus(Integer chequeStatus) {
		this.chequeStatus = chequeStatus;
	}

//Getters
	public String getAgreementCd() {
		return agreementCd;
	}

	public String getCustomerName() {
		return customerName;
	}

	public String getUserName() {
		return userName;
	}

	public Integer getModeOfPayment() {
		return modeOfPayment;
	}

	public Date getDateOfPaymentFrom() {
		return dateOfPaymentFrom;
	}

	public Date getDateOfPaymentTo() {
		return dateOfPaymentTo;
	}

	public Integer getChequeStatus() {
		return chequeStatus;
	}
	
	public Integer setDateToYYYYMMDD(Date date) {
		Integer returnDate = null;
		if (date!=null) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			returnDate = Integer.valueOf(sdf.format(date));
		} return returnDate;
	}
	
}
