package com.acss.core.agencymaintenance;

import com.acss.core.model.BaseEntity;

public class AgencyResultModel extends BaseEntity {																		

	private String agencyName;
	private Integer agencyCode;
	private String address;
	private String phoneNo;
	private String pic;
	
	/**
	 * @return the agencyName
	 */
	public String getAgencyName() {
		return agencyName;
	}
	/**
	 * @param agencyName the agencyName to set
	 */
	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}
	/**
	 * @return the agencyCode
	 */
	public Integer getAgencyCode() {
		return agencyCode;
	}
	/**
	 * @param agencyCode the agencyCode to set
	 */
	public void setAgencyCode(Integer agencyCode) {
		this.agencyCode = agencyCode;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return the phoneNo
	 */
	public String getPhoneNo() {
		return phoneNo;
	}
	/**
	 * @param phoneNo the phoneNo to set
	 */
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	/**
	 * @return the pic
	 */
	public String getPic() {
		return pic;
	}
	/**
	 * @param pic the pic to set
	 */
	public void setPic(String pic) {
		this.pic = pic;
	}	
}
