/**
 * 
 */
package com.acss.core.model.staffmaintenance;

/**
 * @author jarnonobal
 *
 */
public class StaffCriteriaBranch {
	
	private String branchName;
	public final static String MODEL_ATTRIB_KEY = "branchList";
	
	public StaffCriteriaBranch(){}

	public StaffCriteriaBranch(String branchName) {
		super();
		this.branchName = branchName;
	}

	/**
	 * @return the branchName
	 */
	public String getBranchName() {
		return branchName;
	}

	/**
	 * @param branchName the branchName to set
	 */
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

}
