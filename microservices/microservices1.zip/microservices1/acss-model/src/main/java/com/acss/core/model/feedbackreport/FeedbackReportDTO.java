package com.acss.core.model.feedbackreport;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

public class FeedbackReportDTO {	

	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date lastCallDateFrom;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date lastCallDateTo;
	private Integer feedback;
	private List<FeedbackResultModel> feedbackResult;
	
	
	/**
	 * Append all present parameters as query string in the GET request
	 * @param uri
	 * @return uri with parameters.
	 */
	public String appendParameters(String uri){		
		uri=getCallDateFrom()!=null?uri+"lastCallDateFrom="+getCallDateFrom()+"&":uri;
		uri=getCallDateTo()!=null?uri+"lastCallDateTo="+getCallDateTo()+"&":uri;
		uri=feedback!=null?uri+"feedback="+feedback+"&":uri;
		return uri;
	}

	public final static String MODEL_ATTRIB_KEY = "feedbackForm";

	/**
	 * @return the feedbackResult
	 */
	public List<FeedbackResultModel> getFeedbackResult() {
		return feedbackResult;
	}

	/**
	 * @param feedbackResult the feedbackResult to set
	 */
	public void setFeedbackResult(List<FeedbackResultModel> feedbackResult) {
		this.feedbackResult = feedbackResult;
	}

	/**
	 * @return the feedback
	 */
	public Integer getFeedback() {
		return feedback;
	}

	/**
	 * @param feedback the feedback to set
	 */
	public void setFeedback(Integer feedback) {
		this.feedback = feedback;
	}
	
	/**
	 * @return the lastCallDateFrom
	 */
	public Date getLastCallDateFrom() {
		return lastCallDateFrom;
	}

	/**
	 * @param lastCallDateFrom the lastCallDateFrom to set
	 */
	public void setLastCallDateFrom(Date lastCallDateFrom) {
		this.lastCallDateFrom = lastCallDateFrom;
	}

	/**
	 * @return the lastCallDateTo
	 */
	public Date getLastCallDateTo() {
		return lastCallDateTo;
	}

	/**
	 * @param lastCallDateTo the lastCallDateTo to set
	 */
	public void setLastCallDateTo(Date lastCallDateTo) {
		this.lastCallDateTo = lastCallDateTo;
	}

	public Integer getCallDateFrom() {
		return setDateToYYYYMMDD(lastCallDateFrom);
	}
	
	public Integer getCallDateTo() {
		return setDateToYYYYMMDD(lastCallDateTo);
	}
	
	public Integer setDateToYYYYMMDD(Date date) {
		Integer returnDate = null;
		if (date!=null) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			returnDate = Integer.valueOf(sdf.format(date));
		} return returnDate;
	}
}
