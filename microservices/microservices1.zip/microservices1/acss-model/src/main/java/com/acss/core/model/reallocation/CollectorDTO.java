package com.acss.core.model.reallocation;

public class CollectorDTO {
	
	private String collectorCd;
	private String accountCode;
	private String delayStatus;
	private String userName;
	
	public CollectorDTO() {}

	public String getCollectorCd() {
		return collectorCd;
	}
	
	public void setCollectorCd(String collectorCd) {
		this.collectorCd = collectorCd;
	}
	
	public String getAccountCode() {
		return accountCode;
	}
	
	public void setAccountCode(String accountCode) {
		this.accountCode = accountCode;
	}

	/**
	 * @return the delayStatus
	 */
	public String getDelayStatus() {
		return delayStatus;
	}

	/**
	 * @param delayStatus the delayStatus to set
	 */
	public void setDelayStatus(String delayStatus) {
		this.delayStatus = delayStatus;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

}
