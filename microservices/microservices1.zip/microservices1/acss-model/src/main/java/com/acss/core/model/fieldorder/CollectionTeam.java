package com.acss.core.model.fieldorder;

public class CollectionTeam {
	private String teamid;
	private String teamname;
	private String bucket;
	
	public CollectionTeam(){}
	
	public String getTeamid() {
		return teamid;
	}
	public void setTeamid(String teamid) {
		this.teamid = teamid;
	}
	public String getTeamname() {
		return teamname;
	}
	public void setTeamname(String teamname) {
		this.teamname = teamname;
	}

	public String getBucket() {
		return bucket;
	}

	public void setBucket(String bucket) {
		this.bucket = bucket;
	}
}
