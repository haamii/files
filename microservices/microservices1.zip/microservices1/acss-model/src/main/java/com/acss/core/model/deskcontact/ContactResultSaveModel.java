package com.acss.core.model.deskcontact;

import java.math.BigDecimal;

import com.acss.core.model.BaseEntity;

public class ContactResultSaveModel extends BaseEntity{
	
	private String sysCode;
	private Integer yearMonth;
	private String customerCd;
	private Integer num;
	private Integer type;
	private Integer contactTo;
	private Integer contactResult;
	private Integer followUpDate;
	private String comments;
	private Integer action;
	private Integer subAction;
	private String otherAddress;
	private Integer contactResultGroup;
	private Integer priorityGroup;
	private Integer promiseDate;
	private Integer followUpDateTo;
	private Integer dateOfPayment; 
	private String chequeNo;
	private Integer chequeDate; 
	private Integer chequeStatus;
	private String bankName; 
	private BigDecimal emi; 
	private BigDecimal bounceCharges; 
	private BigDecimal latePaymentCharges; 
	private BigDecimal pickUpCharges; 
	private BigDecimal foreclosure; 
	private BigDecimal totalAmount;
	
	
	public ContactResultSaveModel() {}
	
	
//	public ContactResultSaveModel(String sysCode, Integer yearMonth,
//			String customerCd, Integer num, Integer type, Integer contactTo,
//			Integer contactResult, Integer followUpDate, String comments,
//			Integer action, Integer subAction, String otherAddress, Integer contactResultGroup,
//			Integer priorityGroup, Integer promiseDate, Integer followUpDateTo) {
//		this.sysCode = sysCode;
//		this.yearMonth = yearMonth;
//		this.customerCd = customerCd;
//		this.num = num;
//		this.type = type;
//		this.contactTo = contactTo;
//		this.contactResult = contactResult;
//		this.followUpDate = followUpDate;
//		this.comments = comments;
//		this.action = action;
//		this.subAction = subAction;
//		this.otherAddress = otherAddress;
//		this.contactResultGroup = contactResultGroup;
//		this.priorityGroup = priorityGroup;
//		this.promiseDate = promiseDate;
//		this.followUpDateTo = followUpDateTo;
//	}

	/**
	 * Append all present parameters as query string in the GET request
	 * @param uri
	 * @return uri with parameters.
	 */
//	public String appendParameters(String uri){
//		uri=agreementCd!=null?uri+"agreementCd="+agreementCd+"&":uri;
//		uri=action!=null?uri+"action="+action+"&":uri;
//		uri=contactResult!=null?uri+"contactResult="+contactResult+"&":uri;
//		uri=subAction!=null?uri+"subAction="+subAction+"&":uri;
//		uri=promiseDate!=null?uri+"promiseDate="+promiseDate+"&":uri;
//		uri=contactTo!=null?uri+"contactTo="+contactTo+"&":uri;
//		uri=followUpDateFrom!=null?uri+"followUpDateFrom="+followUpDateFrom+"&":uri;
//		uri=followUpDateTo!=null?uri+"followUpDateTo="+followUpDateTo+"&":uri;
//		uri=screenId!=null?uri+"screenId="+screenId+"&":uri;
//		uri=comment!=null?uri+"comment="+comment+"&":uri;
//		uri=accountCode!=null?uri+"accountCode="+accountCode+"&":uri;
//		uri=contactResultGroup!=null?uri+"contactResultGroup="+contactResultGroup+"&":uri;
//		uri=priorityGroup!=null?uri+"priorityGroup="+priorityGroup+"&":uri;
//		uri=otherAddress!=null?uri+"otherAddress="+otherAddress+"&":uri;
//		return uri;
//	}


	public ContactResultSaveModel(String sysCode, Integer yearMonth, String customerCd, Integer num, Integer type,
			Integer contactTo, Integer contactResult, Integer followUpDate, String comments, Integer action,
			Integer subAction, String otherAddress, Integer contactResultGroup, Integer priorityGroup,
			Integer promiseDate, Integer followUpDateTo, Integer dateOfPayment, String chequeNo, Integer chequeDate,
			Integer chequeStatus, String bankName, BigDecimal emi, BigDecimal bounceCharges,
			BigDecimal latePaymentCharges, BigDecimal pickUpCharges, BigDecimal foreclosure, BigDecimal totalAmount) {
		super();
		this.sysCode = sysCode;
		this.yearMonth = yearMonth;
		this.customerCd = customerCd;
		this.num = num;
		this.type = type;
		this.contactTo = contactTo;
		this.contactResult = contactResult;
		this.followUpDate = followUpDate;
		this.comments = comments;
		this.action = action;
		this.subAction = subAction;
		this.otherAddress = otherAddress;
		this.contactResultGroup = contactResultGroup;
		this.priorityGroup = priorityGroup;
		this.promiseDate = promiseDate;
		this.followUpDateTo = followUpDateTo;
		this.dateOfPayment = dateOfPayment;
		this.chequeNo = chequeNo;
		this.chequeDate = chequeDate;
		this.chequeStatus = chequeStatus;
		this.bankName = bankName;
		this.emi = emi;
		this.bounceCharges = bounceCharges;
		this.latePaymentCharges = latePaymentCharges;
		this.pickUpCharges = pickUpCharges;
		this.foreclosure = foreclosure;
		this.totalAmount = totalAmount;
	}


	/**
	 * @return the sysCode
	 */
	public String getSysCode() {
		return sysCode;
	}
	/**
	 * @param sysCode the sysCode to set
	 */
	public void setSysCode(String sysCode) {
		this.sysCode = sysCode;
	}
	/**
	 * @return the yearMonth
	 */
	public Integer getYearMonth() {
		return yearMonth;
	}
	/**
	 * @param yearMonth the yearMonth to set
	 */
	public void setYearMonth(Integer yearMonth) {
		this.yearMonth = yearMonth;
	}
	/**
	 * @return the customerCd
	 */
	public String getCustomerCd() {
		return customerCd;
	}
	/**
	 * @param customerCd the customerCd to set
	 */
	public void setCustomerCd(String customerCd) {
		this.customerCd = customerCd;
	}
	/**
	 * @return the num
	 */
	public Integer getNum() {
		return num;
	}
	/**
	 * @param num the num to set
	 */
	public void setNum(Integer num) {
		this.num = num;
	}
	/**
	 * @return the type
	 */
	public Integer getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(Integer type) {
		this.type = type;
	}
	/**
	 * @return the contactTo
	 */
	public Integer getContactTo() {
		return contactTo;
	}
	/**
	 * @param contactTo the contactTo to set
	 */
	public void setContactTo(Integer contactTo) {
		this.contactTo = contactTo;
	}
	/**
	 * @return the contactResult
	 */
	public Integer getContactResult() {
		return contactResult;
	}
	/**
	 * @param contactResult the contactResult to set
	 */
	public void setContactResult(Integer contactResult) {
		this.contactResult = contactResult;
	}
	/**
	 * @return the followUpDate
	 */
	public Integer getFollowUpDate() {
		return followUpDate;
	}
	/**
	 * @param followUpDate the followUpDate to set
	 */
	public void setFollowUpDate(Integer followUpDate) {
		this.followUpDate = followUpDate;
	}
	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}
	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}
	/**
	 * @return the action
	 */
	public Integer getAction() {
		return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(Integer action) {
		this.action = action;
	}
	/**
	 * @return the subAction
	 */
	public Integer getSubAction() {
		return subAction;
	}
	/**
	 * @param subAction the subAction to set
	 */
	public void setSubAction(Integer subAction) {
		this.subAction = subAction;
	}
	/**
	 * @return the otherAddress
	 */
	public String getOtherAddress() {
		return otherAddress;
	}
	/**
	 * @param otherAddress the otherAddress to set
	 */
	public void setOtherAddress(String otherAddress) {
		this.otherAddress = otherAddress;
	}
	/**
	 * @return the contactResultGroup
	 */
	public Integer getContactResultGroup() {
		return contactResultGroup;
	}
	/**
	 * @param contactResultGroup the contactResultGroup to set
	 */
	public void setContactResultGroup(Integer contactResultGroup) {
		this.contactResultGroup = contactResultGroup;
	}
	/**
	 * @return the priorityGroup
	 */
	public Integer getPriorityGroup() {
		return priorityGroup;
	}
	/**
	 * @param priorityGroup the priorityGroup to set
	 */
	public void setPriorityGroup(Integer priorityGroup) {
		this.priorityGroup = priorityGroup;
	}
	/**
	 * @return the promiseDate
	 */
	public Integer getPromiseDate() {
		return promiseDate;
	}
	/**
	 * @param promiseDate the promiseDate to set
	 */
	public void setPromiseDate(Integer promiseDate) {
		this.promiseDate = promiseDate;
	}
	/**
	 * @return the followUpDateTo
	 */
	public Integer getFollowUpDateTo() {
		return followUpDateTo;
	}
	/**
	 * @param followUpDateTo the followUpDateTo to set
	 */
	public void setFollowUpDateTo(Integer followUpDateTo) {
		this.followUpDateTo = followUpDateTo;
	}
	
	public Integer getDateOfPayment() {
		return dateOfPayment;
	}


	public void setDateOfPayment(Integer dateOfPayment) {
		this.dateOfPayment = dateOfPayment;
	}


	public String getChequeNo() {
		return chequeNo;
	}


	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}


	public Integer getChequeDate() {
		return chequeDate;
	}


	public void setChequeDate(Integer chequeDate) {
		this.chequeDate = chequeDate;
	}


	public Integer getChequeStatus() {
		return chequeStatus;
	}


	public void setChequeStatus(Integer chequeStatus) {
		this.chequeStatus = chequeStatus;
	}


	public String getBankName() {
		return bankName;
	}


	public void setBankName(String bankName) {
		this.bankName = bankName;
	}


	public BigDecimal getEmi() {
		return emi;
	}


	public void setEmi(BigDecimal emi) {
		this.emi = emi;
	}


	public BigDecimal getBounceCharges() {
		return bounceCharges;
	}


	public void setBounceCharges(BigDecimal bounceCharges) {
		this.bounceCharges = bounceCharges;
	}


	public BigDecimal getLatePaymentCharges() {
		return latePaymentCharges;
	}


	public void setLatePaymentCharges(BigDecimal latePaymentCharges) {
		this.latePaymentCharges = latePaymentCharges;
	}


	public BigDecimal getPickUpCharges() {
		return pickUpCharges;
	}


	public void setPickUpCharges(BigDecimal pickUpCharges) {
		this.pickUpCharges = pickUpCharges;
	}


	public BigDecimal getForeclosure() {
		return foreclosure;
	}


	public void setForeclosure(BigDecimal foreclosure) {
		this.foreclosure = foreclosure;
	}


	public BigDecimal getTotalAmount() {
		return totalAmount;
	}


	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}
	

}
