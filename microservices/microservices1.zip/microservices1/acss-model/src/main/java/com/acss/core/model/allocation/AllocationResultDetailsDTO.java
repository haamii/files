package com.acss.core.model.allocation;

import java.util.List;

import com.acss.core.model.reallocation.CollectorDTO;

public class AllocationResultDetailsDTO {
	
	private List<BranchDTO> branches;
	private int billed;
	private int paid;
	private int allocated;
	private int remaining;
	private List<CollectorDTO> collectors;
	private List<AccountAllocationDTO> allocate;
	
	public final static String MODEL_ATTRIB_KEY = "allocationDetail";

	public List<BranchDTO> getBranches() {
		return branches;
	}

	public void setBranches(List<BranchDTO> branches) {
		this.branches = branches;
	}

	public int getBilled() {
		return billed;
	}

	public void setBilled(int billed) {
		this.billed = billed;
	}

	public int getPaid() {
		return paid;
	}

	public void setPaid(int paid) {
		this.paid = paid;
	}

	public int getAllocated() {
		return allocated;
	}

	public void setAllocated(int allocated) {
		this.allocated = allocated;
	}

	public int getRemaining() {
		return remaining;
	}

	public void setRemaining(int remaining) {
		this.remaining = remaining;
	}

	public List<CollectorDTO> getCollectors() {
		return collectors;
	}

	public void setCollectors(List<CollectorDTO> collectors) {
		this.collectors = collectors;
	}

	/**
	 * @return the allocate
	 */
	public List<AccountAllocationDTO> getAllocate() {
		return allocate;
	}

	/**
	 * @param allocate the allocate to set
	 */
	public void setAllocate(List<AccountAllocationDTO> allocate) {
		this.allocate = allocate;
	}
	

}
