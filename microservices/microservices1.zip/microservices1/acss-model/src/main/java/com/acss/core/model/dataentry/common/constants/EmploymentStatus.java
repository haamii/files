package com.acss.core.model.dataentry.common.constants;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public enum EmploymentStatus {
	
	CASUAL(1,"employmentstatus.casual","CASUAL"),
	COMMISSION(2,"employmentstatus.commission","COMMISSION"),
	CONTRACTUAL(3,"employmentstatus.contractual","CONTRACTUAL"),
	CO_TERMINOUS(4,"employmentstatus.coterminous","COTERMIOUS"),
	PROBATIONARY(5,"employmentstatus.probationary","PROBATIONARY"),
	REGULAR(6,"employmentstatus.regular","REGULAR"),
	REMITTANCE_PENSION(7,"employmentstatus.remittance","REMITTANCE"),
	SELF_EMPLOYED(8,"employmentstatus.selfemployed","EMPLYOYED"),
	UNEMPLOYED(9,"employmentstatus.unemployed","UNEMPLOYED"),
	UNIDENTIFIED(10,"employmentstatus.unidentified","UNIDENTIFIED");

	
	private int code;
	private String value;
	private String dbValue;
	
	public final static String MODEL_ATTRIB_KEY = "employmentStatusList";
	
	public final static class BootstrapSingleton {
		public static final Map<String, EmploymentStatus> lookupByValue = new HashMap<String, EmploymentStatus>();
		public static final Map<BigDecimal, EmploymentStatus> lookupByCode = new HashMap<BigDecimal, EmploymentStatus>();
	}
	
	EmploymentStatus(int code, String value,String dbValue) {
		this.code = code;
		this.value = value;
		this.dbValue = dbValue;
		BootstrapSingleton.lookupByValue.put(value, this);
		BootstrapSingleton.lookupByCode.put(new BigDecimal(code), this);
	}
	
	public int getCode() {
		return code;
	}

	public String getValue() {
		return value;
	}
	
	public String getDbValue(){
		return dbValue;
	}
}
