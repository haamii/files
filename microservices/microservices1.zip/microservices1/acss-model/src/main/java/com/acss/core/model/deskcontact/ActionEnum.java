package com.acss.core.model.deskcontact;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * @author sgalvez
 *
 */

public enum ActionEnum {
	CONTACT(0,"CONTACT"),
	INCOMING_CALL(1, "INCOMING CALL");
	
	private int code;
	private String value;
	
	private final static class BootstrapSingleton {
		public static final Map<String, ActionEnum> lookupByValue = new HashMap<String, ActionEnum>();
		public static final Map<BigDecimal, ActionEnum> lookupByCode = new HashMap<BigDecimal, ActionEnum>();
	}
	
	ActionEnum(int code, String value) {
		this.code = code;
		this.value = value;
		BootstrapSingleton.lookupByValue.put(value, this);
		BootstrapSingleton.lookupByCode.put(new BigDecimal(code), this);
	}
	
	public int getCode() {
		return code;
	}

	public String getValue() {
		return value;
	}

}
