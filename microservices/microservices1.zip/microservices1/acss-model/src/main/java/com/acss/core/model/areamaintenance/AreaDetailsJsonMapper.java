package com.acss.core.model.areamaintenance;

public class AreaDetailsJsonMapper {
	private String branchnm;
	private String area;
	private String postId;
	private String postCode;
	private String cityNm;
	private String areaNm;
	private String districtnm;
	
	public String getBranchnm() {
		return branchnm;
	}
	public void setBranchnm(String branchnm) {
		this.branchnm = branchnm;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getPostId() {
		return postId;
	}
	public void setPostId(String postId) {
		this.postId = postId;
	}
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	public String getCityNm() {
		return cityNm;
	}
	public void setCityNm(String cityNm) {
		this.cityNm = cityNm;
	}
	public String getAreaNm() {
		return areaNm;
	}
	public void setAreaNm(String areaNm) {
		this.areaNm = areaNm;
	}
	public String getDistrictnm() {
		return districtnm;
	}
	public void setDistrictnm(String districtnm) {
		this.districtnm = districtnm;
	}
}
