package com.acss.core.model.adminallocation;

public enum CategoryEnum {

	FREEZED(1,"FREEZED"),
	DESK(2,"DESK"),
	FIELD(3,"FIELD"),
	AGENCY(4,"AGENCY");
	
	private int categoryCode;
	private String categoryDesc;
	
	private CategoryEnum(int categoryCode, String categoryDesc) {
		this.categoryCode = categoryCode;
		this.categoryDesc = categoryDesc;
	}
	
	public int getCategoryCode() {
		return categoryCode;
	}
	
	public String getCategoryDesc() {
		return categoryDesc;
	}
	
	public static String getCategoryDescByCode(int category) {
		for (CategoryEnum e : CategoryEnum.values()) {
			if (e.getCategoryCode() == category) {
				return e.getCategoryDesc();
			}
		}
		return "-";
	}
	
	public static int getCategoryCodeByDesc(String category) {
		for (CategoryEnum e : CategoryEnum.values()) {
			if (e.getCategoryDesc().equalsIgnoreCase(category)) {
				return e.getCategoryCode();
			}
		}
		return 0;
	}
	
}
