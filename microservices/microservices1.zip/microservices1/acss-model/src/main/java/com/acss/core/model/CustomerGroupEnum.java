package com.acss.core.model;

public enum CustomerGroupEnum {

	NEW(1,"NEW"),
	DEL(2,"DEL"),
	RB(3,"RB"),
	EXD(4,"EXD"),
	LATE1(5,"LATE1"),
	LATE2(6,"LATE2"),
	P1(7,"P1"),
	P2(8,"P2"),
	P3(9,"P3"),
	OTHER(10,"OTHER");
	
	private String custGroupDesc;
	private int custGroupCode;
	
	private CustomerGroupEnum(int custGroupCode, String custGroupDesc) {
		this.custGroupCode = custGroupCode;
		this.custGroupDesc = custGroupDesc;
	}
	
	private CustomerGroupEnum(String custGroupDesc) {
		this.custGroupDesc = custGroupDesc;
	}
	
	public int getCustGroupCode() {
		return custGroupCode;
	}
	
	/**
	 * @return the custGroupDesc
	 */
	public String getCustGroupDesc() {
		return custGroupDesc;
	}
	
	public static int getCustomerGroup(String custGroup) {
		for (CustomerGroupEnum e : CustomerGroupEnum.values()) {
			if (String.valueOf(e).equalsIgnoreCase(custGroup)) {
				return e.getCustGroupCode();
			}
		}
		return 0;
	}
	
}
