package com.acss.core.model.reallocation;

public class ReallocationSearchDTO {
	
	private String customerCode;
	private String customerName;
	private String residenceContact;
	private String mobilePhoneNo;
	private String dateOfBirth;
	private String idCardNo;
	private String expressCardNo;
	private String agreementNo;
	private String applicationNo;
	private String accountHolderId;
	
	public ReallocationSearchDTO(){}
	
	public ReallocationSearchDTO(String customerCode, String customerName,
			String residenceContact, String mobilePhoneNo, String dateOfBirth,
			String idCardNo, String expressCardNo, String agreementNo,
			String applicationNo, String accountHolderId) {
		this.customerCode = customerCode;
		this.customerName = customerName;
		this.residenceContact = residenceContact;
		this.mobilePhoneNo = mobilePhoneNo;
		this.dateOfBirth = dateOfBirth;
		this.idCardNo = idCardNo;
		this.expressCardNo = expressCardNo;
		this.agreementNo = agreementNo;
		this.applicationNo = applicationNo;
		this.accountHolderId = accountHolderId;
	}
	
	/**
	 * Append all present parameters as query string in the GET request
	 * @param uri
	 * @return uri with parameters.
	 */
	public String appendParameters(String uri){
		if (null!=customerCode)
			uri=!customerCode.isEmpty()?uri+"customerCode="+customerCode+"&":uri;
		
		if (null!=customerName)
			uri=!customerName.isEmpty()?uri+"customerName="+customerName+"&":uri;
		
		if (null!=residenceContact)
			uri=!residenceContact.isEmpty()?uri+"residenceContact="+residenceContact+"&":uri;
		
		if (null!=mobilePhoneNo)
			uri=!mobilePhoneNo.isEmpty()?uri+"mobilePhoneNo="+mobilePhoneNo+"&":uri;
		
		if (null!=dateOfBirth)
			uri=!dateOfBirth.isEmpty()?uri+"dateOfBirth="+dateOfBirth+"&":uri;
		
		if (null!=idCardNo)
			uri=!idCardNo.isEmpty()?uri+"idCardNo="+idCardNo+"&":uri;
		
		if (null!=expressCardNo)
			uri=!expressCardNo.isEmpty()?uri+"expressCardNo="+expressCardNo+"&":uri;
		
		if (null!=agreementNo)
			uri=!agreementNo.isEmpty()?uri+"agreementNo="+agreementNo+"&":uri;
		
		if (null!=applicationNo)
			uri=!applicationNo.isEmpty()?uri=uri+"applicationNo="+applicationNo+"&":uri;
		
		if (null!=accountHolderId)
			uri=!accountHolderId.isEmpty()?uri+"accountHolderId="+accountHolderId+"&":uri;
		
		return uri;
	}
	
	/**
	 * @return the customerCode
	 */
	public String getCustomerCode() {
		return customerCode;
	}
	/**
	 * @param customerCode the customerCode to set
	 */
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}
	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	/**
	 * @return the residenceContact
	 */
	public String getResidenceContact() {
		return residenceContact;
	}
	/**
	 * @param residenceContact the residenceContact to set
	 */
	public void setResidenceContact(String residenceContact) {
		this.residenceContact = residenceContact;
	}
	/**
	 * @return the mobilePhoneNo
	 */
	public String getMobilePhoneNo() {
		return mobilePhoneNo;
	}
	/**
	 * @param mobilePhoneNo the mobilePhoneNo to set
	 */
	public void setMobilePhoneNo(String mobilePhoneNo) {
		this.mobilePhoneNo = mobilePhoneNo;
	}
	/**
	 * @return the dateOfBirth
	 */
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	/**
	 * @param dateOfBirth the dateOfBirth to set
	 */
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	/**
	 * @return the idCardNo
	 */
	public String getIdCardNo() {
		return idCardNo;
	}
	/**
	 * @param idCardNo the idCardNo to set
	 */
	public void setIdCardNo(String idCardNo) {
		this.idCardNo = idCardNo;
	}
	/**
	 * @return the expressCardNo
	 */
	public String getExpressCardNo() {
		return expressCardNo;
	}
	/**
	 * @param expressCardNo the expressCardNo to set
	 */
	public void setExpressCardNo(String expressCardNo) {
		this.expressCardNo = expressCardNo;
	}
	/**
	 * @return the agreementNo
	 */
	public String getAgreementNo() {
		return agreementNo;
	}
	/**
	 * @param agreementNo the agreementNo to set
	 */
	public void setAgreementNo(String agreementNo) {
		this.agreementNo = agreementNo;
	}
	/**
	 * @return the applicationNo
	 */
	public String getApplicationNo() {
		return applicationNo;
	}
	/**
	 * @param applicationNo the applicationNo to set
	 */
	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}
	/**
	 * @return the accountHolderId
	 */
	public String getAccountHolderId() {
		return accountHolderId;
	}
	/**
	 * @param accountHolderId the accountHolderId to set
	 */
	public void setAccountHolderId(String accountHolderId) {
		this.accountHolderId = accountHolderId;
	}
	
	

}
