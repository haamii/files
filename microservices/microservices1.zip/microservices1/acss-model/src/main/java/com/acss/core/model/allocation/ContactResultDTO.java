package com.acss.core.model.allocation;

public class ContactResultDTO {

	private String contactResultCode;
	private String contactResultDesc;
	
	public ContactResultDTO() {
	}

	public String getContactResultCode() {
		return contactResultCode;
	}

	public void setContactResultCode(String contactResultCode) {
		this.contactResultCode = contactResultCode;
	}

	public String getContactResultDesc() {
		return contactResultDesc;
	}

	public void setContactResultDesc(String contactResultDesc) {
		this.contactResultDesc = contactResultDesc;
	}
	
}
