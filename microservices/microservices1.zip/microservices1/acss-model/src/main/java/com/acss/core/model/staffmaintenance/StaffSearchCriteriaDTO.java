/**
 * 
 */
package com.acss.core.model.staffmaintenance;

/**
 * @author jarnonobal
 * Staff Maintenance Search Criteria DTO
 */
public class StaffSearchCriteriaDTO {

	private String accountcode;
	private String branch;
	private String positiontype;
	private String inputUserCd;
	private String accountname;
	private UserAccountModel userModel;
	private StaffMaintenanceCreate staffDetail;
	private StaffUpdate staffUpdate;

	public final static String MODEL_ATTRIB_KEY = "staffSearchForm";

	public StaffSearchCriteriaDTO() {
		super();
		staffDetail = new StaffMaintenanceCreate();
		userModel = new UserAccountModel();
		staffUpdate = new StaffUpdate();
	}

	public StaffSearchCriteriaDTO(String accountcode, String branch, String positiontype) {
		super();
		this.accountcode = accountcode;
		this.branch = branch;
		this.positiontype = positiontype;
	}
	
	public String appendParameters(String uri){
		
		if (null!=accountcode)
			uri=!accountcode.isEmpty()?uri+"accountcode="+accountcode+"&":uri;
		
		if (null!=branch)
			uri=!branch.isEmpty()?uri+"branch="+branch+"&":uri;
		
		if (null!=positiontype)
			uri=!positiontype.isEmpty()?uri+"positiontype="+positiontype+"&":uri;
		
		if (null!=accountname)
			uri=!accountname.isEmpty()?uri+"accountname="+accountname+"&":uri;
		
		return uri;	
	}

	/**
	 * @return the accountcode
	 */
	public String getAccountcode() {
		return accountcode;
	}

	/**
	 * @param accountcode the accountcode to set
	 */
	public void setAccountcode(String accountcode) {
		this.accountcode = accountcode;
	}

	/**
	 * @return the branch
	 */
	public String getBranch() {
		return branch;
	}

	/**
	 * @param branch the branch to set
	 */
	public void setBranch(String branch) {
		this.branch = branch;
	}

	/**
	 * @return the positiontype
	 */
	public String getPositiontype() {
		return positiontype;
	}

	/**
	 * @param positiontype the positiontype to set
	 */
	public void setPositiontype(String positiontype) {
		this.positiontype = positiontype;
	}

	/**
	 * @return the staffDetail
	 */
	public StaffMaintenanceCreate getStaffDetail() {
		return staffDetail;
	}

	/**
	 * @param staffDetail the staffDetail to set
	 */
	public void setStaffDetail(StaffMaintenanceCreate staffDetail) {
		this.staffDetail = staffDetail;
	}

	/**
	 * @return the userModel
	 */
	public UserAccountModel getUserModel() {
		return userModel;
	}

	/**
	 * @param userModel the userModel to set
	 */
	public void setUserModel(UserAccountModel userModel) {
		this.userModel = userModel;
	}

	/**
	 * @return the inputUserCd
	 */
	public String getInputUserCd() {
		return inputUserCd;
	}

	/**
	 * @param inputUserCd the inputUserCd to set
	 */
	public void setInputUserCd(String inputUserCd) {
		this.inputUserCd = inputUserCd;
	}

	/**
	 * @return the staffUpdate
	 */
	public StaffUpdate getStaffUpdate() {
		return staffUpdate;
	}

	/**
	 * @param staffUpdate the staffUpdate to set
	 */
	public void setStaffUpdate(StaffUpdate staffUpdate) {
		this.staffUpdate = staffUpdate;
	}

	public String getAccountname() {
		return accountname;
	}

	public void setAccountname(String accountname) {
		this.accountname = accountname;
	}
	
	
		
}
