package com.acss.core.model.fieldorder;

public class RemainingAccountsTable {
	private String tablename;
	private String tablevalue;
	
	public RemainingAccountsTable(){}
	
	public String getTablename() {
		return tablename;
	}
	public void setTablename(String tablename) {
		this.tablename = tablename;
	}
	public String getTablevalue() {
		return tablevalue;
	}
	public void setTablevalue(String tableValue) {
		this.tablevalue = tableValue;
	}
}
