package com.acss.core.model.adminallocation;

public class AdminAllocationConstants {
	
	public static final String STRTOTALPERCATEGORY = "TOTAL_PER_CATEGORY";
	public static final String STRTOTAL = "TOTAL";
	
	public static final String OPENING_NEW = "OPENING_NEW";
	public static final String NEW_FREEZED = "NEW_FREEZED";
	public static final String NEW_DESK = "NEW_DESK";
	public static final String NEW_FIELD = "NEW_FIELD";
	public static final String NEW_AGENCY = "NEW_AGENCY";
	
	public static final String OPENING_DEL = "OPENING_DEL";
	public static final String DEL_FREEZED = "DEL_FREEZED";
	public static final String DEL_DESK = "DEL_DESK";
	public static final String DEL_FIELD = "DEL_FIELD";
	public static final String DEL_AGENCY = "DEL_AGENCY";
	
	public static final String OPENING_RB = "OPENING_RB";
	public static final String RB_FREEZED = "RB_FREEZED";
	public static final String RB_DESK = "RB_DESK";
	public static final String RB_FIELD = "RB_FIELD";
	public static final String RB_AGENCY = "RB_AGENCY";
	
	public static final String OPENING_EXD = "OPENING_EXD";
	public static final String EXD_FREEZED = "EXD_FREEZED";
	public static final String EXD_DESK = "EXD_DESK";
	public static final String EXD_FIELD = "EXD_FIELD";
	public static final String EXD_AGENCY = "EXD_AGENCY";
	
	public static final String OPENING_LATE1 = "OPENING_LATE1";
	public static final String LATE1_FREEZED = "LATE1_FREEZED";
	public static final String LATE1_DESK = "LATE1_DESK";
	public static final String LATE1_FIELD = "LATE1_FIELD";
	public static final String LATE1_AGENCY = "LATE1_AGENCY";
	
	public static final String OPENING_LATE2 = "OPENING_LATE2";
	public static final String LATE2_FREEZED = "LATE2_FREEZED";
	public static final String LATE2_DESK = "LATE2_DESK";
	public static final String LATE2_FIELD = "LATE2_FIELD";
	public static final String LATE2_AGENCY = "LATE2_AGENCY";
	
	public static final String OPENING_P1 = "OPENING_P1";
	public static final String P1_FREEZED = "P1_FREEZED";
	public static final String P1_DESK = "P1_DESK";
	public static final String P1_FIELD = "P1_FIELD";
	public static final String P1_AGENCY = "P1_AGENCY";
	
	public static final String OPENING_P2 = "OPENING_P2";
	public static final String P2_FREEZED = "P2_FREEZED";
	public static final String P2_DESK = "P2_DESK";
	public static final String P2_FIELD = "P2_FIELD";
	public static final String P2_AGENCY = "P2_AGENCY";
	
	public static final String OPENING_P3 = "OPENING_P3";
	public static final String P3_FREEZED = "P3_FREEZED";
	public static final String P3_DESK = "P3_DESK";
	public static final String P3_FIELD = "P3_FIELD";
	public static final String P3_AGENCY = "P3_AGENCY";
	
	public static final String OPENING_OTHER = "OPENING_OTHER";
	public static final String OTHER_FREEZED = "OTHER_FREEZED";
	public static final String OTHER_DESK = "OTHER_DESK";
	public static final String OTHER_FIELD = "OTHER_FIELD";
	public static final String OTHER_AGENCY = "OTHER_AGENCY";
	
	public static final String TOTAL_OPENING = "TOTAL_OPENING";
	public static final String TOTAL_FREEZED = "TOTAL_FREEZED";
	public static final String TOTAL_DESK = "TOTAL_DESK";
	public static final String TOTAL_FIELD = "TOTAL_FIELD";
	public static final String TOTAL_AGENCY = "TOTAL_AGENCY";
	
}
