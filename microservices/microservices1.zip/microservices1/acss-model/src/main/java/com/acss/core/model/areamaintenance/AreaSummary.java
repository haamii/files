package com.acss.core.model.areamaintenance;

public class AreaSummary {
	
	private String area;
	private Integer postidassigned;
	
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public Integer getPostidassigned() {
		return postidassigned;
	}
	public void setPostidassigned(Integer postidassigned) {
		this.postidassigned = postidassigned;
	}
	
}
