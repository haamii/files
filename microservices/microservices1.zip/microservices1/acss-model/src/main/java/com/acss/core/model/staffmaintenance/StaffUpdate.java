/**
 * 
 */
package com.acss.core.model.staffmaintenance;

import com.acss.core.model.BaseEntity;

/**
 * @author jarnonobal
 *
 */
public class StaffUpdate extends BaseEntity{
	
	private String updUserCd;
	private String updUserName;
	private String updBranch;
	private String updPositionType;
	private String updPassword;
	private String updCollectorCd;
	private Byte updBucket;
	
	
	public StaffUpdate() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StaffUpdate(String updUserCd, String updUserName, String updBranch, String updPositionType,
			String updCollectorCd,String updPassword,Byte updBucket) {
		super();
		this.updUserCd = updUserCd;
		this.updUserName = updUserName;
		this.updBranch = updBranch;
		this.updPositionType = updPositionType;
		this.updCollectorCd = updCollectorCd;
		this.updPassword = updPassword;
		this.updBucket = updBucket;
	}
	
	public String appendParameters(String uri){
		
		if (null!=updUserCd)
			uri=!updUserCd.isEmpty()?uri+"updUserCd="+updUserCd+"&":uri;
		
		if (null!=updUserName)
			uri=!updUserName.isEmpty()?uri+"updUserName="+updUserName+"&":uri;
		
		if (null!=updBranch)
			uri=!updBranch.isEmpty()?uri+"updBranch="+updBranch+"&":uri;
		
		if (null!=updPositionType)
			uri=!updPositionType.isEmpty()?uri+"updPositionType="+updPositionType+"&":uri;
		
		if (null!=updCollectorCd)
			uri=!updCollectorCd.isEmpty()?uri+"updCollectorCd="+updCollectorCd+"&":uri;
		
		if (null!=updPassword)
			uri=!updPassword.isEmpty()?uri+"updPassword="+updPassword+"&":uri;
		
		if (null!=updBucket)
			uri=!updBucket.equals(null)?uri+"updBucket="+updBucket+"&":uri;
		
		if (null!=crePerson)
			uri=!crePerson.equals(null)?uri+"crePerson="+crePerson+"&":uri;
		
		if (null!=creProId)
			uri=!creProId.equals(null)?uri+"creProId="+creProId+"&":uri;
		
		return uri;
	}

	/**
	 * @return the updUserCd
	 */
	public String getUpdUserCd() {
		return updUserCd;
	}

	/**
	 * @param updUserCd the updUserCd to set
	 */
	public void setUpdUserCd(String updUserCd) {
		this.updUserCd = updUserCd;
	}

	/**
	 * @return the updUserName
	 */
	public String getUpdUserName() {
		return updUserName;
	}

	/**
	 * @param updUserName the updUserName to set
	 */
	public void setUpdUserName(String updUserName) {
		this.updUserName = updUserName;
	}

	/**
	 * @return the updBranch
	 */
	public String getUpdBranch() {
		return updBranch;
	}

	/**
	 * @param updBranch the updBranch to set
	 */
	public void setUpdBranch(String updBranch) {
		this.updBranch = updBranch;
	}

	/**
	 * @return the updPositionType
	 */
	public String getUpdPositionType() {
		return updPositionType;
	}

	/**
	 * @param updPositionType the updPositionType to set
	 */
	public void setUpdPositionType(String updPositionType) {
		this.updPositionType = updPositionType;
	}

	/**
	 * @return the updCollectorCd
	 */
	public String getUpdCollectorCd() {
		return updCollectorCd;
	}

	/**
	 * @param updCollectorCd the updCollectorCd to set
	 */
	public void setUpdCollectorCd(String updCollectorCd) {
		this.updCollectorCd = updCollectorCd;
	}

	public String getUpdPassword() {
		return updPassword;
	}

	public void setUpdPassword(String updPassword) {
		this.updPassword = updPassword;
	}

	public Byte getUpdBucket() {
		return updBucket;
	}

	public void setUpdBucket(Byte updBucket) {
		this.updBucket = updBucket;
	}
	
	

}
