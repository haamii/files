package com.acss.core.model.fieldorder;

import java.util.List;


public class Branch {
	
	private String branchName;
	private List<String> areas;
	
	public Branch() {}
	
	
	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}


	public List<String> getAreas() {
		return areas;
	}
	
	public void setAreas(List<String> areas) {
		this.areas = areas;
	}

}
