package com.acss.core.model.dataentry.common.constants;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public enum LivePerson {
	
	ALONE(1,"live.alone"),
	PARENT(2,"live.parent"),
	RELATIVES(3,"live.relatives"),
	SPOUSE(4,"live.spouse"),
	FRIEND(5,"live.friend");
	
	private int code;
	private String value;
	
	public final static String MODEL_ATTRIB_KEY = "livePersonList";
	
	public final static class BootstrapSingleton {
		public static final Map<String, LivePerson> lookupByValue = new HashMap<String, LivePerson>();
		public static final Map<BigDecimal, LivePerson> lookupByCode = new HashMap<BigDecimal, LivePerson>();
	}
	
	LivePerson(int code, String value) {
		this.code = code;
		this.value = value;
		BootstrapSingleton.lookupByValue.put(value, this);
		BootstrapSingleton.lookupByCode.put(new BigDecimal(code), this);
	}
	
	public int getCode() {
		return code;
	}

	public String getValue() {
		return value;
	}
	
	public byte getByte(){
		return (byte) code;
	}
}
