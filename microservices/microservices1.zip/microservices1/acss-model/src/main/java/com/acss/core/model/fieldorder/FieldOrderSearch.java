package com.acss.core.model.fieldorder;

public class FieldOrderSearch {
	private String branch;
	private String areagroup;
	private String bucket;
	private String teamid;
	private String teamname;
	private String userid;
	private String useridandname;
	private String jsonallocstorage;
	private String contactResult;
	
	public static final String MODEL_ATTRIB_KEY = "fieldOrderSearch";
	
	public FieldOrderSearch(){}
	
	public String appendParameters(String uri){		
		uri=branch!=null&&branch.length()>0?uri+"branch="+branch+"&":uri;
		uri=areagroup!=null&&areagroup.length()>0?uri+"areagroup="+areagroup+"&":uri;
		uri=bucket!=null&&bucket.length()>0?uri+"bucket="+bucket+"&":uri;
		uri=teamid!=null&&teamid.length()>0?uri+"teamid="+teamid+"&":uri;
		uri=teamname!=null&&teamname.length()>0?uri+"teamname="+teamname+"&":uri;
		uri=userid!=null&&userid.length()>0?uri+"userid="+userid+"&":uri;
		uri=jsonallocstorage!=null&&jsonallocstorage.length()>0?uri+"jsonallocstorage="+jsonallocstorage+"&":uri;
		return uri;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getBucket() {
		return bucket;
	}

	public void setBucket(String bucket) {
		this.bucket = bucket;
	}

	public String getAreagroup() {
		return areagroup;
	}

	public void setAreagroup(String areagroup) {
		this.areagroup = areagroup;
	}

	public String getTeamid() {
		return teamid;
	}

	public void setTeamid(String teamid) {
		this.teamid = teamid;
	}

	public String getTeamname() {
		return teamname;
	}

	public void setTeamname(String teamname) {
		this.teamname = teamname;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getJsonallocstorage() {
		return jsonallocstorage;
	}

	public void setJsonallocstorage(String jsonallocstorage) {
		this.jsonallocstorage = jsonallocstorage;
	}

	public String getUseridandname() {
		return useridandname;
	}

	public void setUseridandname(String useridandname) {
		this.useridandname = useridandname;
	}

	public String getContactResult() {
		return contactResult;
	}

	public void setContactResult(String contactResult) {
		this.contactResult = contactResult;
	}

}
