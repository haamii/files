package com.acss.core.model.reallocation;

public class ReallocationSearchModel {
	
	private String customerCd;
	private String name;
	private String idCardNo;
	private String expressCardNo;
	private String agreementCd;
	private String groupId;
	private float creditLimit;
	private float totalBalance;
	private int delayStatus;
	private String collectorId;
	
	public ReallocationSearchModel() {}
	
	public ReallocationSearchModel(String customerCd, String name,
			String idCardNo, String expressCardNo, String agreementCd,
			String groupId, float creditLimit, float totalBalance) {
		this.customerCd = customerCd;
		this.name = name;
		this.idCardNo = idCardNo;
		this.expressCardNo = expressCardNo;
		this.agreementCd = agreementCd;
		this.groupId = groupId;
		this.creditLimit = creditLimit;
		this.setTotalBalance(totalBalance);
	}
	
	/**
	 * @return the customerCd
	 */
	public String getCustomerCd() {
		return customerCd;
	}
	/**
	 * @param customerCd the customerCd to set
	 */
	public void setCustomerCd(String customerCd) {
		this.customerCd = customerCd;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the idCardNo
	 */
	public String getIdCardNo() {
		return idCardNo;
	}
	/**
	 * @param idCardNo the idCardNo to set
	 */
	public void setIdCardNo(String idCardNo) {
		this.idCardNo = idCardNo;
	}
	/**
	 * @return the expressCardNo
	 */
	public String getExpressCardNo() {
		return expressCardNo;
	}
	/**
	 * @param expressCardNo the expressCardNo to set
	 */
	public void setExpressCardNo(String expressCardNo) {
		this.expressCardNo = expressCardNo;
	}
	/**
	 * @return the agreementCd
	 */
	public String getAgreementCd() {
		return agreementCd;
	}
	/**
	 * @param agreementCd the agreementCd to set
	 */
	public void setAgreementCd(String agreementCd) {
		this.agreementCd = agreementCd;
	}
	/**
	 * @return the groupId
	 */
	public String getGroupId() {
		return groupId;
	}
	/**
	 * @param groupId the groupId to set
	 */
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	/**
	 * @return the creditLimit
	 */
	public float getCreditLimit() {
		return creditLimit;
	}
	/**
	 * @param creditLimit the creditLimit to set
	 */
	public void setCreditLimit(float creditLimit) {
		this.creditLimit = creditLimit;
	}

	/**
	 * @return the delayStatus
	 */
	public int getDelayStatus() {
		return delayStatus;
	}

	/**
	 * @param delayStatus the delayStatus to set
	 */
	public void setDelayStatus(int delayStatus) {
		this.delayStatus = delayStatus;
	}

	/**
	 * @return the collectorId
	 */
	public String getCollectorId() {
		return collectorId;
	}

	/**
	 * @param collectorId the collectorId to set
	 */
	public void setCollectorId(String collectorId) {
		this.collectorId = collectorId;
	}

	/**
	 * @return the totalBalance
	 */
	public float getTotalBalance() {
		return totalBalance;
	}

	/**
	 * @param totalBalance the totalBalance to set
	 */
	public void setTotalBalance(float totalBalance) {
		this.totalBalance = totalBalance;
	}
	
	
}
