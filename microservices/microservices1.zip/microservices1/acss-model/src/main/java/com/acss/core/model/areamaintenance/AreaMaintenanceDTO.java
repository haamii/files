package com.acss.core.model.areamaintenance;

import java.util.ArrayList;
import java.util.List;

import com.acss.core.model.areamaintenance.SearchAreaCriteria;

public class AreaMaintenanceDTO {
	private SearchAreaCriteria areaCriteria;
	private List<AreaAssignment> areaSummary;
	private List<AreaDetails> areas;
	private AreaDetails areaDetail;
	private List<String> areaSearchResult;
	private String jsonallocstorage;
	
	public AreaMaintenanceDTO(){
		areaCriteria = new SearchAreaCriteria();
		areaSummary = new ArrayList<AreaAssignment>();
		areas = new ArrayList<AreaDetails>();
		areaDetail = new AreaDetails();
		areaSearchResult = new ArrayList<String>();
	}

	/**
	 * @return the areaCriteria
	 */
	public SearchAreaCriteria getAreaCriteria() {
		return areaCriteria;
	}

	/**
	 * @param areaCriteria the areaCriteria to set
	 */
	public void setAreaCriteria(SearchAreaCriteria areaCriteria) {
		this.areaCriteria = areaCriteria;
	}

	/**
	 * @return the areaSummary
	 */
	public List<AreaAssignment> getAreaSummary() {
		return areaSummary;
	}

	/**
	 * @param areaSummary the areaSummary to set
	 */
	public void setAreaSummary(List<AreaAssignment> areaSummary) {
		this.areaSummary = areaSummary;
	}

	/**
	 * @return the areas
	 */
	public List<AreaDetails> getAreas() {
		return areas;
	}

	/**
	 * @param areas the areas to set
	 */
	public void setAreas(List<AreaDetails> areas) {
		this.areas = areas;
	}

	/**
	 * @return the areaDetail
	 */
	public AreaDetails getAreaDetail() {
		return areaDetail;
	}

	/**
	 * @param areaDetail the areaDetail to set
	 */
	public void setAreaDetail(AreaDetails areaDetail) {
		this.areaDetail = areaDetail;
	}

	/**
	 * @return the areaSearchResult
	 */
	public List<String> getAreaSearchResult() {
		return areaSearchResult;
	}

	/**
	 * @param areaSearchResult the areaSearchResult to set
	 */
	public void setAreaSearchResult(List<String> areaSearchResult) {
		this.areaSearchResult = areaSearchResult;
	}

	public String getJsonallocstorage() {
		return jsonallocstorage;
	}

	public void setJsonallocstorage(String jsonallocstorage) {
		this.jsonallocstorage = jsonallocstorage;
	}

}
