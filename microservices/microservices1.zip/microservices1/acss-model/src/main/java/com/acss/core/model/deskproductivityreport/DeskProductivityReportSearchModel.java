package com.acss.core.model.deskproductivityreport;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;
/**
 * @author sgalvez
 *
 */
public class DeskProductivityReportSearchModel {

	@DateTimeFormat(pattern = "dd/MM/yyyy")
	Date contactDateFrom;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	Date contactDateTo;
	String callerName;
	
	public final static String MODEL_ATTRIB_KEY = "deskProductivityReportSearch";
	
	public DeskProductivityReportSearchModel() {}
	public DeskProductivityReportSearchModel(Date contactDateFrom, Date contactDateTo, String callerName) {
		this.contactDateFrom = contactDateFrom;
		this.contactDateTo = contactDateTo;
		this.callerName = callerName;
	}
	
	/**
	 * Append all present parameters as query string in the GET request
	 * @param uri
	 * @return uri with parameters.
	 */
	public String appendParameters(String uri){		
		uri=getContactDateFrom()!=null?uri+"contactDateFrom="+setDateToYYYYMMDD(getContactDateFrom())+"&":uri;
		uri=getContactDateTo()!=null?uri+"contactDateTo="+setDateToYYYYMMDD(getContactDateTo())+"&":uri;
		uri=getCallerName()!=null?uri+"userName="+getCallerName()+"&":uri;
		return uri;
	}
	
	/**
	 * @return the contactDateFrom
	 */
	public Date getContactDateFrom() {
		return contactDateFrom;
	}
	/**
	 * @param contactDateFrom the contactDateFrom to set
	 */
	public void setContactDateFrom(Date contactDateFrom) {
		this.contactDateFrom = contactDateFrom;
	}
	/**
	 * @return the contactDateTo
	 */
	public Date getContactDateTo() {
		return contactDateTo;
	}
	/**
	 * @param contactDateTo the contactDateTo to set
	 */
	public void setContactDateTo(Date contactDateTo) {
		this.contactDateTo = contactDateTo;
	}
	/**
	 * @return the callerName
	 */
	public String getCallerName() {
		return callerName;
	}
	/**
	 * @param callerName the callerName to set
	 */
	public void setCallerName(String callerName) {
		this.callerName = callerName;
	}
	
	public Integer setDateToYYYYMMDD(Date date) {
		Integer returnDate = null;
		if (date!=null) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			returnDate = Integer.valueOf(sdf.format(date));
		} return returnDate;
	}
	
}
