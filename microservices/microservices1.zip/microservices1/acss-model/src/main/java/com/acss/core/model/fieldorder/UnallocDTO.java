package com.acss.core.model.fieldorder;

import java.util.List;

public class UnallocDTO {
	public final static String MODEL_ATTRIB_KEY = "unallocdto";
	private List<UnallocatedTable> unallocatedTable;
	
	public UnallocDTO(){}
	
	public List<UnallocatedTable> getUnallocatedTable() {
		return unallocatedTable;
	}
	public void setUnallocatedTable(List<UnallocatedTable> unallocatedTable) {
		this.unallocatedTable = unallocatedTable;
	}
}
