package com.acss.core.model.deskproductivityreport;
/**
 * @author sgalvez
 *
 */
public class DeskProductivityReportModel {

	int sno;
	String callerName; 
	Integer noOfCalls; 
	Integer noOfContact; 
	Integer ptp; 
	Integer paid; 
	Integer updated; 
	Integer toBeUpdated; 
	Integer cb; 
	Integer msg; 
	Integer rtp;
	Integer ptpAtField; 
	Integer nc; 
	Integer ring; 
	Integer so; 
	Integer bptp; 
	Integer other; 
	Integer fieldyn;
	
	public final static String MODEL_ATTRIB_KEY = "deskProductivityReportModel";
	
	public DeskProductivityReportModel() {}
	public DeskProductivityReportModel(int sno, String callerName, Integer noOfCalls, Integer noOfContact, Integer ptp,
			Integer paid, Integer updated, Integer toBeUpdated, Integer cb, Integer msg, Integer rtp,
			Integer ptpAtField, Integer nc, Integer ring, Integer so, Integer bptp, Integer other, Integer fieldyn) {
		super();
		this.sno = sno;
		this.callerName = callerName;
		this.noOfCalls = noOfCalls;
		this.noOfContact = noOfContact;
		this.ptp = ptp;
		this.paid = paid;
		this.updated = updated;
		this.toBeUpdated = toBeUpdated;
		this.cb = cb;
		this.msg = msg;
		this.rtp = rtp;
		this.ptpAtField = ptpAtField;
		this.nc = nc;
		this.ring = ring;
		this.so = so;
		this.bptp = bptp;
		this.other = other;
		this.fieldyn = fieldyn;
	}
	
	/**
	 * @return the sno
	 */
	public int getSno() {
		return sno;
	}
	/**
	 * @param sno the sno to set
	 */
	public void setSno(int sno) {
		this.sno = sno;
	}
	/**
	 * @return the callerName
	 */
	public String getCallerName() {
		return callerName;
	}
	/**
	 * @param callerName the callerName to set
	 */
	public void setCallerName(String callerName) {
		this.callerName = callerName;
	}
	/**
	 * @return the noOfCalls
	 */
	public Integer getNoOfCalls() {
		return noOfCalls;
	}
	/**
	 * @param noOfCalls the noOfCalls to set
	 */
	public void setNoOfCalls(Integer noOfCalls) {
		this.noOfCalls = noOfCalls;
	}
	/**
	 * @return the noOfContact
	 */
	public Integer getNoOfContact() {
		return noOfContact;
	}
	/**
	 * @param noOfContact the noOfContact to set
	 */
	public void setNoOfContact(Integer noOfContact) {
		this.noOfContact = noOfContact;
	}
	/**
	 * @return the ptp
	 */
	public Integer getPtp() {
		return ptp;
	}
	/**
	 * @param ptp the ptp to set
	 */
	public void setPtp(Integer ptp) {
		this.ptp = ptp;
	}
	/**
	 * @return the paid
	 */
	public Integer getPaid() {
		return paid;
	}
	/**
	 * @param paid the paid to set
	 */
	public void setPaid(Integer paid) {
		this.paid = paid;
	}
	/**
	 * @return the updated
	 */
	public Integer getUpdated() {
		return updated;
	}
	/**
	 * @param updated the updated to set
	 */
	public void setUpdated(Integer updated) {
		this.updated = updated;
	}
	/**
	 * @return the toBeUpdated
	 */
	public Integer getToBeUpdated() {
		return toBeUpdated;
	}
	/**
	 * @param toBeUpdated the toBeUpdated to set
	 */
	public void setToBeUpdated(Integer toBeUpdated) {
		this.toBeUpdated = toBeUpdated;
	}
	/**
	 * @return the cb
	 */
	public Integer getCb() {
		return cb;
	}
	/**
	 * @param cb the cb to set
	 */
	public void setCb(Integer cb) {
		this.cb = cb;
	}
	/**
	 * @return the msg
	 */
	public Integer getMsg() {
		return msg;
	}
	/**
	 * @param msg the msg to set
	 */
	public void setMsg(Integer msg) {
		this.msg = msg;
	}
	/**
	 * @return the rtp
	 */
	public Integer getRtp() {
		return rtp;
	}
	/**
	 * @param rtp the rtp to set
	 */
	public void setRtp(Integer rtp) {
		this.rtp = rtp;
	}
	/**
	 * @return the ptpAtField
	 */
	public Integer getPtpAtField() {
		return ptpAtField;
	}
	/**
	 * @param ptpAtField the ptpAtField to set
	 */
	public void setPtpAtField(Integer ptpAtField) {
		this.ptpAtField = ptpAtField;
	}
	/**
	 * @return the nc
	 */
	public Integer getNc() {
		return nc;
	}
	/**
	 * @param nc the nc to set
	 */
	public void setNc(Integer nc) {
		this.nc = nc;
	}
	/**
	 * @return the ring
	 */
	public Integer getRing() {
		return ring;
	}
	/**
	 * @param ring the ring to set
	 */
	public void setRing(Integer ring) {
		this.ring = ring;
	}
	/**
	 * @return the so
	 */
	public Integer getSo() {
		return so;
	}
	/**
	 * @param so the so to set
	 */
	public void setSo(Integer so) {
		this.so = so;
	}
	/**
	 * @return the bptp
	 */
	public Integer getBptp() {
		return bptp;
	}
	/**
	 * @param bptp the bptp to set
	 */
	public void setBptp(Integer bptp) {
		this.bptp = bptp;
	}
	/**
	 * @return the other
	 */
	public Integer getOther() {
		return other;
	}
	/**
	 * @param other the other to set
	 */
	public void setOther(Integer other) {
		this.other = other;
	}
	/**
	 * @return the fieldyn
	 */
	public Integer getFieldyn() {
		return fieldyn;
	}
	/**
	 * @param fieldyn the fieldyn to set
	 */
	public void setFieldyn(Integer fieldyn) {
		this.fieldyn = fieldyn;
	}
	
}
