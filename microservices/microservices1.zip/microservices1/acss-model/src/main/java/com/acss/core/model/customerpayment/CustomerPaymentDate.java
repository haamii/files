package com.acss.core.model.customerpayment;

public class CustomerPaymentDate {
	private String paymentdate;
	private String paymentmethod;
	private String paidamount;
	private String operatorname;
	private String collectorname;
	private String bankno;
	private String aeonbankacct;
	private String aeonbranchname;
	private String receiptno;
	private String adjustedamount;
	private String remarks;
	
	public CustomerPaymentDate(){}
	
	public String appendParameters(String uri){		
		uri=paymentdate!=null&&paymentdate.length()>0?uri+"paymentdate="+paymentdate+"&":uri;
		uri=paymentmethod!=null&&paymentmethod.length()>0?uri+"paymentmethod="+paymentmethod+"&":uri;
		uri=paidamount!=null&&paidamount.length()>0?uri+"paidamount="+paidamount+"&":uri;
		uri=operatorname!=null&&operatorname.length()>0?uri+"operatorname="+operatorname+"&":uri;
		uri=collectorname!=null&&collectorname.length()>0?uri+"collectorname="+collectorname+"&":uri;
		uri=bankno!=null&&bankno.length()>0?uri+"bankno="+bankno+"&":uri;
		uri=aeonbankacct!=null&&aeonbankacct.length()>0?uri+"aeonbankacct="+aeonbankacct+"&":uri;
		uri=aeonbranchname!=null&&aeonbranchname.length()>0?uri+"aeonbranchname="+aeonbranchname+"&":uri;
		uri=receiptno!=null&&receiptno.length()>0?uri+"receiptno="+receiptno+"&":uri;
		uri=adjustedamount!=null&&adjustedamount.length()>0?uri+"adjustedamount="+adjustedamount+"&":uri;
		uri=remarks!=null&&remarks.length()>0?uri+"remarks="+remarks+"&":uri;
		return uri;
	}
	
	public String getPaymentdate() {
		return paymentdate;
	}
	public void setPaymentdate(String paymentdate) {
		this.paymentdate = paymentdate;
	}
	public String getPaymentmethod() {
		return paymentmethod;
	}
	public void setPaymentmethod(String paymentmethod) {
		this.paymentmethod = paymentmethod;
	}
	public String getPaidamount() {
		return paidamount;
	}
	public void setPaidamount(String paidamount) {
		this.paidamount = paidamount;
	}
	public String getOperatorname() {
		return operatorname;
	}
	public void setOperatorname(String operatorname) {
		this.operatorname = operatorname;
	}
	public String getCollectorname() {
		return collectorname;
	}
	public void setCollectorname(String collectorname) {
		this.collectorname = collectorname;
	}
	public String getBankno() {
		return bankno;
	}
	public void setBankno(String bankno) {
		this.bankno = bankno;
	}
	public String getAeonbankacct() {
		return aeonbankacct;
	}
	public void setAeonbankacct(String aeonbankacct) {
		this.aeonbankacct = aeonbankacct;
	}
	public String getAeonbranchname() {
		return aeonbranchname;
	}
	public void setAeonbranchname(String aeonbranchname) {
		this.aeonbranchname = aeonbranchname;
	}
	public String getReceiptno() {
		return receiptno;
	}
	public void setReceiptno(String receiptno) {
		this.receiptno = receiptno;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getAdjustedamount() {
		return adjustedamount;
	}
	public void setAdjustedamount(String adjustedamount) {
		this.adjustedamount = adjustedamount;
	}
}
