package com.acss.core.model.customerpayment;

import java.util.List;

public class CustomerPaymentDTO {
	
	private CustomerPaymentSearch customerPaymentSearch;
	
	private List<CustomerPaymentSearch> customersearchList;
	
	private List<CustomerACHHistory> customerACHHistory;
	
	private List<CustomerECSHistory> customerECSHistory;
	
	private List<CustPDCHistory> customerPDCHistory;
	
	private List<CustomerInstallmentNote> customerInstallmentNote;
	
	private List<CustomerPaymentDate> customerPaymentDate;
	
	private List<CustomerAgreement> customerAgreement;
	
	private CustomerInstallmentSummary customerInstallmentSummary;
	
	public final static String MODEL_ATTRIB_KEY = "customerForm";

	public CustomerPaymentSearch getCustomerPaymentSearch() {
		return customerPaymentSearch;
	}

	public void setCustomerPaymentSearch(CustomerPaymentSearch customerPaymentSearch) {
		this.customerPaymentSearch = customerPaymentSearch;
	}

	public List<CustomerPaymentSearch> getCustomersearchList() {
		return customersearchList;
	}

	public void setCustomersearchList(List<CustomerPaymentSearch> customersearchList) {
		this.customersearchList = customersearchList;
	}

	public List<CustomerACHHistory> getCustomerACHHistory() {
		return customerACHHistory;
	}

	public void setCustomerACHHistory(List<CustomerACHHistory> customerACHHistory) {
		this.customerACHHistory = customerACHHistory;
	}

	public List<CustomerECSHistory> getCustomerECSHistory() {
		return customerECSHistory;
	}

	public void setCustomerECSHistory(List<CustomerECSHistory> customerECSHistory) {
		this.customerECSHistory = customerECSHistory;
	}

	public List<CustPDCHistory> getCustomerPDCHistory() {
		return customerPDCHistory;
	}

	public void setCustomerPDCHistory(List<CustPDCHistory> customerPDCHistory) {
		this.customerPDCHistory = customerPDCHistory;
	}

	public List<CustomerInstallmentNote> getCustomerInstallmentNote() {
		return customerInstallmentNote;
	}

	public void setCustomerInstallmentNote(List<CustomerInstallmentNote> customerInstallmentNote) {
		this.customerInstallmentNote = customerInstallmentNote;
	}

	public List<CustomerPaymentDate> getCustomerPaymentDate() {
		return customerPaymentDate;
	}

	public void setCustomerPaymentDate(List<CustomerPaymentDate> customerPaymentDate) {
		this.customerPaymentDate = customerPaymentDate;
	}

	public CustomerInstallmentSummary getCustomerInstallmentSummary() {
		return customerInstallmentSummary;
	}

	public void setCustomerInstallmentSummary(CustomerInstallmentSummary customerInstallmentSummary) {
		this.customerInstallmentSummary = customerInstallmentSummary;
	}

	public List<CustomerAgreement> getCustomerAgreement() {
		return customerAgreement;
	}

	public void setCustomerAgreement(List<CustomerAgreement> customerAgreement) {
		this.customerAgreement = customerAgreement;
	}

}
