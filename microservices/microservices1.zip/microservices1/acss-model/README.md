# acss-model
Common model objects for repository and service access.
