package com.acss.core.feedbackreport;

import java.util.List;

import com.acss.core.model.feedbackreport.FeedbackReportDTO;
import com.acss.core.model.feedbackreport.FeedbackResultModel;

public interface FeedbackReportService {
	List<FeedbackResultModel> populateFeedbackReport(FeedbackReportDTO feedbackReportDTO);
}
