package com.acss.core.customerpayment;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.acss.core.model.customerpayment.CustPDCHistory;
import com.acss.core.model.customerpayment.CustomerACHHistory;
import com.acss.core.model.customerpayment.CustomerECSHistory;
import com.acss.core.model.customerpayment.CustomerInstallmentNote;
import com.acss.core.model.customerpayment.CustomerPaymentDTO;
import com.acss.core.model.customerpayment.CustomerPaymentDate;
import com.acss.core.model.customerpayment.CustomerPaymentSearch;

@RestController
public class InternalCustomerPaymentController {
	
	@Autowired
	CustomerPaymentService customerPaymentService;
	
	@RequestMapping(value = "ajax/customerPayment/customerPaymentSearchResult", method = RequestMethod.GET)
	public List<CustomerPaymentSearch> searchCustomerPayment(
			@ModelAttribute CustomerPaymentDTO customerPaymentDTO){
		return customerPaymentService.search(customerPaymentDTO.getCustomerPaymentSearch());
	}
	
	@RequestMapping(value = "ajax/customerPayment/paymentDateTable", method = RequestMethod.GET)
	public List<CustomerPaymentDate> fillpaymentDateTable(Model model,
			@RequestParam(value = "agreementcode", required = false) String agreementcode){
		CustomerPaymentSearch searchData = new CustomerPaymentSearch();
		searchData.setAgreementno(agreementcode);	
		return customerPaymentService.searchPaymentDate(searchData);
	}
	
	@RequestMapping(value = "ajax/customerPayment/paymentInstallmentTable", method = RequestMethod.GET)
	public List<CustomerInstallmentNote> fillInstallmentTable(Model model,
			@RequestParam(value = "agreementcode", required = false) String agreementcode){
		CustomerPaymentSearch searchData = new CustomerPaymentSearch();
		searchData.setAgreementno(agreementcode);	
		CustomerPaymentDTO dto = customerPaymentService.searchInstallmentTable(searchData);
		return dto.getCustomerInstallmentNote();
	}
	@RequestMapping(value = "ajax/customerPayment/paymentEcsTable", method = RequestMethod.GET)
	public List<CustomerECSHistory> fillEcsTable(Model model,
			@RequestParam(value = "agreementcode", required = false) String agreementcode){
		CustomerPaymentSearch searchData = new CustomerPaymentSearch();
		searchData.setAgreementno(agreementcode);
		return customerPaymentService.searchEcsTable(searchData);
	}
	@RequestMapping(value = "ajax/customerPayment/paymentPdcTable", method = RequestMethod.GET)
	public List<CustPDCHistory> fillPdcTable(Model model,
			@RequestParam(value = "agreementcode", required = false) String agreementcode){
		CustomerPaymentSearch searchData = new CustomerPaymentSearch();
		searchData.setAgreementno(agreementcode);
		return customerPaymentService.searchPdcTable(searchData);
	}
	@RequestMapping(value = "ajax/customerPayment/paymentAchTable", method = RequestMethod.GET)
	public List<CustomerACHHistory> fillAchTable(Model model,
			@RequestParam(value = "agreementcode", required = false) String agreementcode){
		CustomerPaymentSearch searchData = new CustomerPaymentSearch();
		searchData.setAgreementno(agreementcode);	
		return customerPaymentService.searchAchTable(searchData);
	}
	
}
