package com.acss.core.allocation;

import java.security.Principal;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.acss.core.model.allocation.AccountAllocationDTO;
import com.acss.core.model.allocation.AllocationCriteriaSearchDTO;
import com.acss.core.model.allocation.AllocationResultDetailsDTO;
import com.acss.core.model.allocation.BranchDTO;
import com.acss.core.model.fieldorder.AllocatedTable;
import com.acss.core.model.fieldorder.FieldOrderDTO;
import com.acss.core.model.fieldorder.FieldOrderStatic;
import com.acss.core.model.reallocation.CollectorDTO;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

@Component
public class RsAllocation implements AllocationService{
	
	@Autowired
	private Environment env;
	
	private final static String RSALLOCATION_CRITERIA_URL_KEY = "rs.allocation.criteria.url";
	private final static String RSALLOCATION_ACCOUNT_URL_KEY = "rs.allocation.account.url";
	private static final String RSALLOCATION_ALLOCATION_URL_KEY = "rs.allocation.allocation.url";
	private static final String RSALLOCATION_ALLOCATIONHIDDEN_URL_KEY = "rs.allocation.allocationhidden.url";
	private static final String RSALLOCATION_ALLOCATEAGREEMENTS_URL_KEY = "rs.allocation.allocateagreements.url";
	
	private static final String RSALLOCATION_COLLECTOR_URL_KEY = "rs.allocation.collector.url";
	private static final String RSALLOCATION_CONFIRM_URL_KEY = "rs.allocation.confirm.url";
	private static final String SCR_ID= "SCR000003";
	
	private final static String SCREENID_CONFIRM_KEY = "view.allocation.id";

	@Override
	public void populateBranchAreaList(AllocationResultDetailsDTO allocationDTO) {
		
		String uri = env.getProperty(RSALLOCATION_CRITERIA_URL_KEY);
		
		RestTemplate rt = new RestTemplate();	
		
		ResponseEntity<BranchDTO[]> response = rt.getForEntity(uri, BranchDTO[].class);
		List<BranchDTO> criteria =  Arrays.asList(response.getBody());
		
		allocationDTO.setBranches(criteria);
	}

	@Override
	public void getNumberOfAccounts(AllocationResultDetailsDTO allocationDTO,
			AllocationCriteriaSearchDTO allocationSearchForm) {
		
		RestTemplate rt = new RestTemplate();
		
		String uri = env.getProperty(RSALLOCATION_ACCOUNT_URL_KEY);
		
		AllocationCriteriaSearchDTO searchCriteria = new AllocationCriteriaSearchDTO(allocationSearchForm.getArea(), allocationSearchForm.getDelayStatus(), allocationSearchForm.getBranch(),
				allocationSearchForm.getCategory(), allocationSearchForm.getCustomerGroup());
		uri = searchCriteria.appendParameters(uri);
		
		ResponseEntity<AllocationResultDetailsDTO> response = rt.getForEntity(uri, AllocationResultDetailsDTO.class);
		allocationDTO.setAllocated(response.getBody().getAllocated());
		allocationDTO.setBilled(response.getBody().getBilled());
		allocationDTO.setPaid(response.getBody().getPaid());
		allocationDTO.setRemaining(response.getBody().getRemaining());
		
	}

	
	
	
	@Override
	public void getAllocationResult(AllocationResultDetailsDTO allocationDTO,
			AllocationCriteriaSearchDTO allocationSearchForm, String selected,
			String currentCollector, String function) {
		
		RestTemplate rt = new RestTemplate();

		String uri = env.getProperty(RSALLOCATION_ALLOCATION_URL_KEY);
			
		//get the allocation result based on search criteria
		AllocationCriteriaSearchDTO searchCriteriaResult = new AllocationCriteriaSearchDTO(allocationSearchForm.getArea(), allocationSearchForm.getBranch(), allocationSearchForm.getDelayStatus(), allocationDTO.getRemaining(), allocationSearchForm.getCategory());

		uri = searchCriteriaResult.appendParameters(uri);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		allocationSearchForm.prepareForCreate(auth.getName(), SCR_ID);
		ResponseEntity<AccountAllocationDTO[]> responseForAllocate = rt.postForEntity(uri,allocationSearchForm,AccountAllocationDTO[].class);
		List<AccountAllocationDTO> allocate =  Arrays.asList(responseForAllocate.getBody());
		allocationDTO.setAllocate(allocate);
		
	}


	@Override
	public void populateCollectors(AllocationResultDetailsDTO allocationDTO,
			AllocationCriteriaSearchDTO allocationSearchForm) {
		
		RestTemplate rt = new RestTemplate();
		AllocationCriteriaSearchDTO searchCriteriaResult = new AllocationCriteriaSearchDTO(allocationSearchForm.getArea(), allocationSearchForm.getBranch(), allocationSearchForm.getDelayStatus(), allocationDTO.getRemaining(), allocationSearchForm.getCategory());

		String uri = env.getProperty(RSALLOCATION_COLLECTOR_URL_KEY);
		
		uri = searchCriteriaResult.appendParameters(uri);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		allocationSearchForm.prepareForCreate(auth.getName(), SCR_ID);
		//get all collectors under the selected branch
		ResponseEntity<CollectorDTO[]> responseForCollectors = rt.getForEntity(uri, CollectorDTO[].class);
		List<CollectorDTO> collectors =  Arrays.asList(responseForCollectors.getBody());
		allocationDTO.setCollectors(collectors);
		
	}
	
	@Override
	public void getAllocationResulthidden(AllocationResultDetailsDTO allocationDTO,
			AllocationCriteriaSearchDTO allocationSearchForm, String selected,
			String currentCollector, String function) {
		
		RestTemplate rt = new RestTemplate();
		AllocationCriteriaSearchDTO searchCriteriaResult = new AllocationCriteriaSearchDTO(allocationSearchForm.getArea(), allocationSearchForm.getBranch(), allocationSearchForm.getDelayStatus(), allocationDTO.getRemaining(), allocationSearchForm.getCategory());
		
		String uri = env.getProperty(RSALLOCATION_ALLOCATIONHIDDEN_URL_KEY);
	
		uri = searchCriteriaResult.appendParameters(uri);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		allocationSearchForm.prepareForCreate(auth.getName(), SCR_ID);
		ResponseEntity<AccountAllocationDTO[]> responseForAllocate = rt.postForEntity(uri,allocationSearchForm,AccountAllocationDTO[].class);
		List<AccountAllocationDTO> allocate =  Arrays.asList(responseForAllocate.getBody());
		allocationDTO.setAllocate(allocate);
		
	}

	

	@Override
	public void updateAllocation(String currentCollector,
			AllocationCriteriaSearchDTO allocationSearchForm, Principal principal) {
		
		RestTemplate rt = new RestTemplate();
		
		String uri = env.getProperty(RSALLOCATION_CONFIRM_URL_KEY);
		
		allocationSearchForm.setAllCollectors(currentCollector);
		allocationSearchForm.prepareForUpdate(principal.getName(), env.getProperty(SCREENID_CONFIRM_KEY));
		rt.postForEntity(uri, allocationSearchForm, AllocationCriteriaSearchDTO.class);
		
	}

	@Override
	public boolean allocateAgreements(AllocationCriteriaSearchDTO dto) {
		// TODO Auto-generated method stub
		
		RestTemplate rt = new RestTemplate();
		
		String uri = env.getProperty(RSALLOCATION_ALLOCATEAGREEMENTS_URL_KEY);
		Gson gson = new Gson();
		TypeToken<List<AccountAllocationDTO>> token = new TypeToken<List<AccountAllocationDTO>>(){};
		String data = dto.getJsonallocstorage();
		List<AccountAllocationDTO> allocatedlist = gson.fromJson(data, token.getType());
		dto.setAllocate(allocatedlist);
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		dto.prepareForCreate(auth.getName(), SCR_ID);
		rt.postForEntity(uri, dto, AllocationCriteriaSearchDTO.class);
		
		return true;
	}

}
