package com.acss.core.agencymaintenance;

public class AgencyMaintenanceDTO {
	
	private String agencyName;
	private String agencyNameAdd;	
	private String phoneNoAdd;
	private String picAdd;
	private String addressAdd;
	private AgencyResultModel agencyDetails;
	private AgencyResultModel updateDetails;
	
	public final static String MODEL_ATTRIB_KEY = "agencyMaintenanceForm";
	
	
	public AgencyMaintenanceDTO() {
		super();
		agencyDetails = new AgencyResultModel();
		updateDetails = new AgencyResultModel();
	}

	/**
	 * Append all present parameters as query string in the GET request
	 * @param uri
	 * @return uri with parameters.
	 */
	public String appendParameters(String uri){		
		uri=agencyName!=null&&agencyName.length()>0?uri+"agencyName="+agencyName+"&":uri;
		uri=agencyNameAdd!=null&&agencyNameAdd.length()>0?uri+"agencyName="+agencyNameAdd+"&":uri;
		uri=phoneNoAdd!=null&&phoneNoAdd.length()>0?uri+"phoneNo="+phoneNoAdd+"&":uri;
		uri=picAdd!=null&&picAdd.length()>0?uri+"pic="+picAdd+"&":uri;
		uri=addressAdd!=null&&addressAdd.length()>0?uri+"address="+addressAdd+"&":uri;

		return uri;
	}

	/**
	 * @return the agencyName
	 */
	public String getAgencyName() {
		return agencyName;
	}

	/**
	 * @param agencyName the agencyName to set
	 */
	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}
	
	/**
	 * @return the agencyNameAdd
	 */
	public String getAgencyNameAdd() {
		return agencyNameAdd;
	}

	/**
	 * @param agencyNameAdd the agencyNameAdd to set
	 */
	public void setAgencyNameAdd(String agencyNameAdd) {
		this.agencyNameAdd = agencyNameAdd;
	}

	/**
	 * @return the phoneNoAdd
	 */
	public String getPhoneNoAdd() {
		return phoneNoAdd;
	}

	/**
	 * @param phoneNoAdd the phoneNoAdd to set
	 */
	public void setPhoneNoAdd(String phoneNoAdd) {
		this.phoneNoAdd = phoneNoAdd;
	}

	/**
	 * @return the picAdd
	 */
	public String getPicAdd() {
		return picAdd;
	}

	/**
	 * @param picAdd the picAdd to set
	 */
	public void setPicAdd(String picAdd) {
		this.picAdd = picAdd;
	}

	/**
	 * @return the addressAdd
	 */
	public String getAddressAdd() {
		return addressAdd;
	}

	/**
	 * @param addressAdd the addressAdd to set
	 */
	public void setAddressAdd(String addressAdd) {
		this.addressAdd = addressAdd;
	}

	/**
	 * @return the agencyDetails
	 */
	public AgencyResultModel getAgencyDetails() {
		return agencyDetails;
	}

	/**
	 * @param agencyDetails the agencyDetails to set
	 */
	public void setAgencyDetails(AgencyResultModel agencyDetails) {
		this.agencyDetails = agencyDetails;
	}

	/**
	 * @return the updateDetails
	 */
	public AgencyResultModel getUpdateDetails() {
		return updateDetails;
	}

	/**
	 * @param updateDetails the updateDetails to set
	 */
	public void setUpdateDetails(AgencyResultModel updateDetails) {
		this.updateDetails = updateDetails;
	}

}
