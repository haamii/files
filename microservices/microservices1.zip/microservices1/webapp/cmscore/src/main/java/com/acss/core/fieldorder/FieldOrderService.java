package com.acss.core.fieldorder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.acss.core.model.allocation.BranchDTO;
import com.acss.core.model.allocation.ContactResultDTO;
import com.acss.core.model.deskcontact.ContactResultEnum;
import com.acss.core.model.fieldorder.FieldOrderDTO;
import com.acss.core.model.fieldorder.FieldOrderStatic;

@Service
public class FieldOrderService implements IFieldOrderService {
	
	@Autowired
	private Environment env;
	
	@Override
	public FieldOrderDTO getBranchList(FieldOrderDTO dto) {
		// TODO Auto-generated method stub
		String uri = env.getProperty(FieldOrderStatic.RSFIELDORDER_BRANCH_URL_KEY);
		RestTemplate rt = new RestTemplate();

		ResponseEntity<BranchDTO[]> response = rt.getForEntity(uri, BranchDTO[].class);
		List<BranchDTO> branchAreaList = Arrays.asList(response.getBody());
		FieldOrderDTO responseDTO = new FieldOrderDTO();
		responseDTO.setBranchdto(branchAreaList);
		return responseDTO;
	}

	@Override
	public FieldOrderDTO getTeamIDList(FieldOrderDTO dto) {
		// TODO Auto-generated method stub
		String uri = env.getProperty(FieldOrderStatic.RSFIELDORDER_TEAM_URL_KEY);
		RestTemplate rt = new RestTemplate();
		ResponseEntity<FieldOrderDTO> response = rt.getForEntity(uri, FieldOrderDTO.class);
		return response.getBody();
		
	}

	@Override
	public FieldOrderDTO getUserIDList(FieldOrderDTO dto) {
		// TODO Auto-generated method stub
		String uri = env.getProperty(FieldOrderStatic.RSFIELDORDER_USERID_URL_KEY);
		RestTemplate rt = new RestTemplate();
		uri = dto.getFieldOrderSearch().appendParameters(uri);
		ResponseEntity<FieldOrderDTO> response = rt.getForEntity(uri, FieldOrderDTO.class);
		return response.getBody();
		
	}

	@Override
	public FieldOrderDTO fillAllocTable(FieldOrderDTO dto) {
		// TODO Auto-generated method stub
		String uri = env.getProperty(FieldOrderStatic.RSFIELDORDER_FILLALLOCATEDTABLE_URL_KEY);
		RestTemplate rt = new RestTemplate();
		uri = dto.getFieldOrderSearch().appendParameters(uri);
		ResponseEntity<FieldOrderDTO> response = rt.getForEntity(uri, FieldOrderDTO.class);
		return response.getBody();
	}
	
	@Override
	public FieldOrderDTO fillUnAllocAccounts(FieldOrderDTO dto) {
		// TODO Auto-generated method stub
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		dto.prepareForCreate(auth.getName(),FieldOrderStatic.SCRID);
		String uri = env.getProperty(FieldOrderStatic.RSFIELDORDER_GETUNALLOCACCOUNTS);
		RestTemplate rt = new RestTemplate();
		ResponseEntity<FieldOrderDTO> response = rt.postForEntity(uri, dto, FieldOrderDTO.class);
		return response.getBody();
	}

	@Override
	public void updateAllocation(FieldOrderDTO dto) {
		// TODO Auto-generated method stub
		RestTemplate rt = new RestTemplate();
		String uri = env.getProperty(FieldOrderStatic.RSFIELDORDER_UPDATEALLOCACC);
		rt.postForEntity(uri,dto,FieldOrderDTO.class);

	}

	@Override
	public FieldOrderDTO fillUnAllocTable(FieldOrderDTO dto) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		dto.prepareForCreate(auth.getName(),env.getProperty(FieldOrderStatic.SCRID));
		String uri = env.getProperty(FieldOrderStatic.RSFIELDORDER_GETUNALLOCACCTABLE);
		RestTemplate rt = new RestTemplate();
		ResponseEntity<FieldOrderDTO> response = rt.postForEntity(uri,dto,FieldOrderDTO.class);
		return response.getBody();
	}

	@Override
	public void updateUnallocation(FieldOrderDTO dto) {
		// TODO Auto-generated method stub
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		dto.prepareForCreate(auth.getName(),env.getProperty(FieldOrderStatic.SCRID));
		RestTemplate rt = new RestTemplate();
		String uri = env.getProperty(FieldOrderStatic.RSFIELDORDER_UPDATEUNALLOCACC);
		rt.postForEntity(uri,dto,FieldOrderDTO.class);
	}

	@Override
	public void initTallocationTemp(FieldOrderDTO dto) {
		// TODO Auto-generated method stub
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		dto.prepareForCreate(auth.getName(),FieldOrderStatic.SCRID);
		RestTemplate rt = new RestTemplate();
		String uri = env.getProperty(FieldOrderStatic.RSFIELDORDER_INITTEMP);
		rt.postForEntity(uri,dto,FieldOrderDTO.class);
	}

	@Override
	public FieldOrderDTO fillUnAllocTablehidden(FieldOrderDTO dto) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		dto.prepareForCreate(auth.getName(),env.getProperty(FieldOrderStatic.SCRID));
		String uri = env.getProperty(FieldOrderStatic.RSFIELDORDER_GETFORHIDDEN);
		RestTemplate rt = new RestTemplate();
		ResponseEntity<FieldOrderDTO> response = rt.postForEntity(uri,dto,FieldOrderDTO.class);
		return response.getBody();
	}
	
	@Override
	public List<ContactResultDTO> generateContactResult() {
		List<ContactResultDTO> contactRes = new ArrayList<ContactResultDTO>();
		ContactResultDTO contactDTO = null;
		for (ContactResultEnum e : ContactResultEnum.values()) {
//			(short)8,(short)9,(short)10,(short)11,(short)12,(short)14,(short)17,(short)19,(short)20,(short)21)
			if (e.getCode() == 8 || e.getCode() == 9 || e.getCode() == 10 || e.getCode() == 11 || e.getCode() == 12
					|| e.getCode() == 14 || e.getCode() == 17 || e.getCode() == 18 || e.getCode() == 19 || e.getCode() == 20 || e.getCode() == 21) {
				contactDTO = new ContactResultDTO();
				contactDTO.setContactResultCode(String.valueOf(e.getCode()));
				contactDTO.setContactResultDesc(e.getValue());
				contactRes.add(contactDTO);
			}
		}
	
		return contactRes;
	}

}
