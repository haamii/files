package com.acss.core.teammaintenance;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class InternalTeamMaintenance {
	
	@Autowired
	private TeamMaintenanceService service;
	
	@RequestMapping(value="ajax/teammaintenance/getUserByBranch", method = RequestMethod.GET)
	public List<TeamLeader>getTeamLeader(
			@ModelAttribute TeamMaintenanceDTO teamMaintenanceDto){
		return service.populateTeamLeader(teamMaintenanceDto);		
	}
	
	@RequestMapping(value="ajax/teammaintenance/teamResult", method = RequestMethod.GET)
	public List<TeamResultModel>search(
			@ModelAttribute TeamMaintenanceDTO teamMaintenanceDto){
		return service.search(teamMaintenanceDto);		
	}	

}
