package com.acss.core.reallocation;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.acss.core.model.reallocation.ReallocationResultDetailsDTO;
import com.acss.core.model.reallocation.ReallocationSaveDTO;
import com.acss.core.model.reallocation.ReallocationSearchDTO;
import com.acss.core.support.web.MessageHelper;

@Controller
public class AccountReallocationController {
	
	@Autowired
	public ReallocationService reallocationService;
	
	@RequestMapping(value = "reallocation")
	public String onLoad(Model model){
		
		ReallocationResultDetailsDTO reallocationDTO = new ReallocationResultDetailsDTO();
		
		reallocationService.populateAccountHolder(reallocationDTO);
		model.addAttribute(ReallocationResultDetailsDTO.MODEL_ATTRIB_KEY, reallocationDTO);
		
		return "reallocation/reallocation";
	}
	
	@RequestMapping(value="ajax/reallocation/searchresult",method= RequestMethod.POST)
	public String reallocationSearch(
			Model model,
			@ModelAttribute ReallocationSearchDTO reallocationSearchForm){
		
		ReallocationResultDetailsDTO reallocationDTO = new ReallocationResultDetailsDTO();
		
		//get reallocation search result	
		reallocationService.populateSearchResult(reallocationDTO, reallocationSearchForm);		
		
		//get the list of collectors
		reallocationService.populateReallocateToCollector(reallocationDTO);
		
		model.addAttribute(ReallocationResultDetailsDTO.MODEL_ATTRIB_KEY, reallocationDTO);
		
		//valid parameters
		return "fragments/reallocation/_searchresultreallocation";		
		
	}
	
	@RequestMapping(value="save",method= RequestMethod.POST)
	public String reallocationSave(
			@ModelAttribute ReallocationSaveDTO reallocationSearchForm,
			RedirectAttributes ra, Principal principal){
		
		reallocationService.updateReallocation(reallocationSearchForm, principal);
			
		MessageHelper.addSuccessAttribute(ra, "save.success");
//		MessageHelper.addErrorAttribute(ra, "save.error");
		
		return "redirect:/reallocation";
		
	}
			
	
	
}
