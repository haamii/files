package com.acss.core.teammaintenance;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.acss.core.model.allocation.BranchDTO;

@Component
public class RsTeamMaintenance implements TeamMaintenanceService {
	
	@Autowired
	private Environment env;
	
	private final static String RSUTILS_BRANCHAREA_URL_KEY = "rs.utils.brancharea.url";
	
	private final static String RSTEAM_SEARCHTL_URL_KEY = "rs.team.searchteamleader.url";
	private final static String RSTEAM_COLLECTOR_URL_KEY = "rs.team.collector.url";
	private final static String RSTEAM_ADD_URL_KEY = "rs.team.add.url";
	private final static String RSTEAM_SEARCH_URL_KEY = "rs.team.search.url";
	private final static String RSTEAM_DETAILS_URL_KEY = "rs.team.details.url";
	private final static String RSTEAM_UPDATE_URL_KEY = "rs.team.update.url";
	
	private final static String SCREENID_SAVE_KEY = "view.teamRegistration.id";
	private final static String SCREENID_UPDATE_KEY = "view.teamModification.id";

	@Override
	public void populateBranchAreaList(TeamMaintenanceDTO teamMaintenanceDto) {
		// TODO Auto-generated method stub
		String uri = env.getProperty(RSUTILS_BRANCHAREA_URL_KEY);

		RestTemplate rt = new RestTemplate();

		ResponseEntity<BranchDTO[]> response = rt.getForEntity(uri, BranchDTO[].class);
		List<BranchDTO> branchAreaList = Arrays.asList(response.getBody());

		teamMaintenanceDto.setBranchAreaList(branchAreaList);

	}
	
	@Override
	public void populateCollectorList(TeamMaintenanceDTO teamMaintenanceDto) {
		// TODO Auto-generated method stub
		String uri = env.getProperty(RSTEAM_COLLECTOR_URL_KEY);

		RestTemplate rt = new RestTemplate();

		ResponseEntity<CollectorModel[]> response = rt.getForEntity(uri, CollectorModel[].class);
		List<CollectorModel> collectorList = Arrays.asList(response.getBody());

		teamMaintenanceDto.setCollectorList(collectorList);

	}

	@Override
	public List<TeamLeader> populateTeamLeader(TeamMaintenanceDTO teamMaintenanceDto) {
		// TODO Auto-generated method stub
		List<TeamLeader> userList = new ArrayList<>();
		TeamUpdateDetails teamDetails = new TeamUpdateDetails();

		String uri = env.getProperty(RSTEAM_SEARCHTL_URL_KEY);

		RestTemplate rt = new RestTemplate();
		
		teamDetails = teamMaintenanceDto.getUpdateTeamDetails();
		uri = teamMaintenanceDto.appendParameters(uri);
		uri = teamDetails.getTeamID()!=null ? uri=uri+"teamID="+teamDetails.getTeamID() : uri ;
		
		ResponseEntity<TeamLeader[]> response = rt.getForEntity(uri, TeamLeader[].class);
		
		userList = Arrays.asList(response.getBody());	

		return userList;
	}

	@Override
	public void addTeam(TeamDetails teamDetails, Principal principal) {
		// TODO Auto-generated method stub
		String uri = env.getProperty(RSTEAM_ADD_URL_KEY);
		RestTemplate rt = new RestTemplate();		
		teamDetails.prepareForCreate(principal.getName(), env.getProperty(SCREENID_SAVE_KEY));
		rt.postForEntity(uri,teamDetails,TeamDetails.class);
	}
	
	
	@Override
	public List<TeamResultModel> search(TeamMaintenanceDTO teamMaintenanceDto) {
		List<TeamResultModel> teamList = new ArrayList<>();

		String uri = env.getProperty(RSTEAM_SEARCH_URL_KEY);

		RestTemplate rt = new RestTemplate();
		
		uri = teamMaintenanceDto.appendParameters(uri);

		ResponseEntity<TeamResultModel[]> response = rt.getForEntity(uri, TeamResultModel[].class);

		teamList = Arrays.asList(response.getBody());

		return teamList;

	}

	@Override
	public TeamUpdateDetails populateTeamDetails(Integer teamId) {
		TeamUpdateDetails details = new TeamUpdateDetails();

		String uri = env.getProperty(RSTEAM_DETAILS_URL_KEY) + teamId;

		RestTemplate rt = new RestTemplate();

		ResponseEntity<TeamUpdateDetails> response = rt.getForEntity(uri, TeamUpdateDetails.class);

		details = response.getBody();

		return details;
	}

	@Override
	public void updateTeam(TeamMaintenanceDTO teamMaintenanceDTO, Principal principal) {
		// TODO Auto-generated method stub
		String uri = env.getProperty(RSTEAM_UPDATE_URL_KEY);
		
		RestTemplate rt = new RestTemplate();
		
		teamMaintenanceDTO.getUpdateTeamDetails().prepareForUpdate(principal.getName(), env.getProperty(SCREENID_UPDATE_KEY));
		
		rt.postForEntity(uri,teamMaintenanceDTO.getUpdateTeamDetails(),TeamUpdateDetails.class);
		
	}

}
