package com.acss.core.useraccount;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.acss.core.account.UserConfigurable;
import com.acss.core.model.useraccount.UserAccountUpdateDTO;
import com.acss.core.staffmaintenance.PositionType;
import com.acss.core.staffmaintenance.StaffResultDetailsDTO;
import com.acss.core.support.web.MessageHelper;
/**
 * Core controller of User Account module
 * @author sgalvez
 *
 */
@Controller
public class UserAccountController {
	
	@Autowired
	private UserAccountService userService;
	
	/**
	 * On Load
	 */
	@RequestMapping(value = "userAccount")
	public String onLoadUserAccount(Model model) {
		
		StaffResultDetailsDTO staffResultDetailsDTO = new StaffResultDetailsDTO();
		UserAccountUpdateDTO userAccount = new UserAccountUpdateDTO();
		
		UserConfigurable us = (UserConfigurable)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		userService.populateBranchList(staffResultDetailsDTO);
		userService.populateUserAccount(userAccount, us.getUsername());
		model.addAttribute(PositionType.MODEL_ATTRIB_KEY, PositionType.values());
		model.addAttribute(UserAccountUpdateDTO.MODEL_ATTRIB_KEY, userAccount);
		model.addAttribute(StaffResultDetailsDTO.USER_ACCOUNT_MODEL_ATTRIB_KEY, staffResultDetailsDTO);
		return "useraccount/useraccount";
    }
	
	/**
	 * Form Submission
	 */
	@RequestMapping(value = "updatePassword", method= RequestMethod.POST)
	public String updatePassword(Model model, RedirectAttributes ra, @ModelAttribute UserAccountUpdateDTO userAccountForm){
		userService.updatePassword(userAccountForm);
		MessageHelper.addSuccessAttribute(ra, "update.password.success");
		return "redirect:/userAccount";
	}
	
}
