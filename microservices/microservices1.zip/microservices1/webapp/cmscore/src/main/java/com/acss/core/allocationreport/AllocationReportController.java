package com.acss.core.allocationreport;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.poi.util.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.acss.core.allocation.BucketEnum;

@Controller
public class AllocationReportController {
	
	@Autowired
	private AllocationReportService service;
	@Autowired
	private Environment env;
	
	private static final String ROOT = "generatedReportPath";

	@RequestMapping(value = "allocationreport")
	public String onLoad(Model model) { 
		AllocationReportDTO allocationReportDTO = new AllocationReportDTO();
		// branch and areaGroup List
		service.populateBranchAreaList(allocationReportDTO);
		model.addAttribute(BucketEnum.MODEL_ATTRIB_KEY, BucketEnum.values());
		model.addAttribute(AllocationReportDTO.MODEL_ATTRIB_KEY,allocationReportDTO);	
		
		// Create directory if not existing
		File theDir = new File(env.getProperty(ROOT)); //save path
		if (!theDir.exists()) theDir.mkdir();
		
		return "allocationreport/allocationreport";
	}
	
	@RequestMapping(value="ajax/allocationreport/getFiles", method= RequestMethod.POST)
	public String populateFiles(Model model){
		
		List<GeneratedFilesModel> files = new ArrayList<GeneratedFilesModel>();
		
		File folder = new File(env.getProperty(ROOT));
		File[] listOfFiles = folder.listFiles();

		for (File file : listOfFiles) {
		    if (file.isFile()) {
		        GeneratedFilesModel fileDetails = new GeneratedFilesModel();
		        fileDetails.setFileName(file.getName().replaceAll("_PENDING", ""));
		        fileDetails.setPath(env.getProperty(ROOT)+file.getName());
		        if (file.getName().contains("PENDING"))
		        	fileDetails.setStatus("PENDING");
		        else fileDetails.setStatus("DONE");
		        
		        files.add(fileDetails);
		    }
		}
		
		Collections.sort(files, 
                (o1, o2) -> o1.getFileName().compareTo(o2.getFileName()));
		Collections.reverse(files);
		
		model.addAttribute(GeneratedFilesModel.MODEL_ATTRIB_KEY, files);
			
		return "fragments/allocationreport/_searchresultfiles";	
	}
	
	@RequestMapping(value="ajax/allocationreport/downloadFile", method= RequestMethod.GET)
	public ResponseEntity<byte[]> downloadFile(@RequestParam(value = "fileName", required = true) String fileName) 
			throws MalformedURLException, IOException {

        String file = env.getProperty(ROOT) + fileName;
        
        byte[] byteResult = null;
        
        try {
            if (file != null && file.isEmpty() == false) {

                InputStream infile = new FileInputStream(new File(file));
                
                byteResult = IOUtils.toByteArray(infile);

            }
        } catch (IOException e) {
            if (e instanceof FileNotFoundException) {
              
            }
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("application/msexcel"));
        headers.setContentDispositionFormData(fileName, fileName);
        headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
        
        return new ResponseEntity<byte[]>(byteResult, headers, HttpStatus.OK);
	}

}
