package com.acss.core.useraccount;

import com.acss.core.model.useraccount.UserAccountUpdateDTO;
import com.acss.core.staffmaintenance.StaffResultDetailsDTO;
/**
 *  Interface for RSUserAccount module
 * @author sgalvez
 *
 */
public interface UserAccountService {
	
	public void updatePassword(UserAccountUpdateDTO userAccountForm);
	public void populateBranchList(StaffResultDetailsDTO staffResultDetailsDTO);
	public void populateUserAccount(UserAccountUpdateDTO userAccountForm, String userCd);
}