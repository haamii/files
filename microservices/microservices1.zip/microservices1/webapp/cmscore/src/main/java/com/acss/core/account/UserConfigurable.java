package com.acss.core.account;

import java.math.BigDecimal;
import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

public class UserConfigurable extends User{
	
	private String accountname;
	
	private BigDecimal bucket;

	public UserConfigurable(String username, String password,String name, BigDecimal bucket,
			Collection<? extends GrantedAuthority> authorities) {
		super(username, password, authorities);
		this.setName(name);
		this.setBucket(bucket);
		// TODO Auto-generated constructor stub
	}

	public String getAccountname() {
		return accountname;
	}

	public void setName(String name) {
		this.accountname = name;
	}
	

	public BigDecimal getBucket() {
		return bucket;
	}

	public void setBucket(BigDecimal bucket) {
		this.bucket = bucket;
	}



	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
