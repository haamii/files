package com.acss.core.allocationreport;

import java.util.List;

import com.acss.core.model.allocation.BranchDTO;

public class AllocationReportDTO {

	private List<BranchDTO> branchAreaList;
	private String branch;
	private String areaGroup;
	private Integer bucket;
	private String userName;
	
	public final static String MODEL_ATTRIB_KEY = "allocationReportForm";
	
	/**
	 * Append all present parameters as query string in the GET request
	 * @param uri
	 * @return uri with parameters.
	 */
	public String appendParameters(String uri){		
		uri=branch!=null&&branch.length()>0?uri+"branch="+branch+"&":uri;
		uri=areaGroup!=null&&areaGroup.length()>0?uri+"areaGroup="+areaGroup+"&":uri;
		uri=bucket!=null?uri+"bucket="+bucket+"&":uri;
		uri=userName!=null&&userName.length()>0?uri+"userName="+userName+"&":uri;
		return uri;
	}
	
	/**
	 * @return the branchAreaList
	 */
	public List<BranchDTO> getBranchAreaList() {
		return branchAreaList;
	}
	/**
	 * @param branchAreaList the branchAreaList to set
	 */
	public void setBranchAreaList(List<BranchDTO> branchAreaList) {
		this.branchAreaList = branchAreaList;
	}
	/**
	 * @return the branch
	 */
	public String getBranch() {
		return branch;
	}
	/**
	 * @param branch the branch to set
	 */
	public void setBranch(String branch) {
		this.branch = branch;
	}
	/**
	 * @return the areaGroup
	 */
	public String getAreaGroup() {
		return areaGroup;
	}
	/**
	 * @param areaGroup the areaGroup to set
	 */
	public void setAreaGroup(String areaGroup) {
		this.areaGroup = areaGroup;
	}
	/**
	 * @return the bucket
	 */
	public Integer getBucket() {
		return bucket;
	}
	/**
	 * @param bucket the bucket to set
	 */
	public void setBucket(Integer bucket) {
		this.bucket = bucket;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
}
