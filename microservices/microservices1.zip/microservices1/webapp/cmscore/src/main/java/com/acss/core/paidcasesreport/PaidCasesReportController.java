/**
 * 
 */
package com.acss.core.paidcasesreport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.acss.core.model.deskcontact.ChequeStatusEnum;
import com.acss.core.model.deskcontact.ModeOfPaymentEnum;
import com.acss.core.model.paidcasesreport.PaidCasesReportDTO;;

/**
 * @author jpetronio
 *
 */

@Controller
public class PaidCasesReportController {
	
	@Autowired
	public PaidCasesReportService service;
	
	private static final String DESKCONTACT_ENUM_CHEQUESTATUSE_KEY = "listChequeStatus";
	private static final String DESKCONTACT_ENUM_MODEOFPAYMENT_KEY = "listModeOfPayment";
	
	@RequestMapping(value="paidCasesReport")
	public String onLoad(Model model){
		model.addAttribute(DESKCONTACT_ENUM_CHEQUESTATUSE_KEY,ChequeStatusEnum.values());
		model.addAttribute(DESKCONTACT_ENUM_MODEOFPAYMENT_KEY,ModeOfPaymentEnum.values());
	    model.addAttribute(PaidCasesReportDTO.MODEL_ATTRIB_KEY, new PaidCasesReportDTO());
	    	return "report/paidcasesreport";
	    
	}
}
