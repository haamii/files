package com.acss.core.deskcontact;

import java.util.List;

import com.acss.core.model.deskcontact.FeedbackUploadDTO;
/*
 * @author sgalvez
 */
public interface FeedbackUploadService {

	public String validateFilename(String filename);
	public List<FeedbackUploadDTO> doReadFile(String filename, String path);
	
}
