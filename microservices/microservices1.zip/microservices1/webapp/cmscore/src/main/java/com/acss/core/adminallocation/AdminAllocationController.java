package com.acss.core.adminallocation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.acss.core.account.UserConfigurable;
import com.acss.core.model.adminallocation.AdminAllocationDTO;
import com.acss.core.model.adminallocation.AdminAllocationModel;

@Controller
public class AdminAllocationController {

	@Autowired
	private AdminAllocationService adminAllocationService;
	
	public static String MODEL_ATTRIB_KEY = "adminAllocationDetails";
	public static String MODEL_ATTRIB_URL = "/adminAllocationDetails";
	public static String MODEL_ATTRIB_KEY_COPY = "adminAllocationDetailsCopy";
	public static String MODEL_ATTRIB_URL_COPY = "/adminAllocationDetailsCopy";
	
	private final static String SYSADROLE = "SYSTEM_ADMINISTRATOR";
	private final static String RETURN_ERRORPAGE = "error/logoutsession";
	
	String branch = "ALL";
	
	@RequestMapping(value = "adminAllocation")
	public String onLoad(Model model) {
//		model.addAttribute(MODEL_ATTRIB_KEY, MODEL_ATTRIB_URL);
		AdminAllocationDTO dto = new AdminAllocationDTO();
		
		String returnPage = "adminallocation/adminAllocation";
		
		UserConfigurable us = getUser();
		Collection<GrantedAuthority> authorities = us.getAuthorities();
		boolean hasRole = false;
		for(GrantedAuthority auth : authorities){
			hasRole = auth.getAuthority().equals(SYSADROLE);	
			if(hasRole){
				returnPage = RETURN_ERRORPAGE;
				model.addAttribute("errorMessage", "Account "+ us.getAccountname()+" is a SYSTEM ADMINISTRATOR and has no BUCKET");
			}
		}
		
		// get list of branch
		adminAllocationService.populateBranchAreaList(dto);
		retrieveAllocationDetails(model, dto, branch);
		dto.setBranch(branch);
		
		model.addAttribute("adminAllocationForm", dto);
		model.addAttribute("isAdminAllocCompleted", adminAllocationService.isAdminAlloCompleted(branch));
		
		return returnPage;
	}
	
	@RequestMapping(value = "ajax/adminallocation/selectBranch", method = RequestMethod.GET)
	public String getAdminAllocationByBranch(Model model, 
			@RequestParam (value="branch", required = false) String branch) {
		this.branch = branch;
		AdminAllocationDTO dto = new AdminAllocationDTO();
		
		model.addAttribute("adminAllocationForm", dto);
//		model.addAttribute("isAdminAllocCompleted", null);
//		retrieveAllocationDetails(model, dto, branch);
		
		return "adminallocation/adminAllocation";
	}
	
	@RequestMapping(value = "ajax/allocation/confirmAdminAlloc", method = RequestMethod.POST)
	public String confirmAdminAllocation(Model model, @ModelAttribute AdminAllocationDTO adminAllocationForm) {
		adminAllocationService.confirmAdminAllocation(adminAllocationForm);
		model.addAttribute("adminAllocationForm", new AdminAllocationDTO());
		model.addAttribute("isAdminAllocCompleted", adminAllocationService.isAdminAlloCompleted(branch));
		return "adminallocation/adminAllocation";
	}
	
	private void retrieveAllocationDetails(Model model, AdminAllocationDTO dto, String branch) {
		List<AdminAllocationModel> adminAllocDetails = new ArrayList<AdminAllocationModel>();
		adminAllocDetails = adminAllocationService.retrieveAdminAllocDetails(branch);
		
		int lastIndex = adminAllocDetails.size() - 1;
		// set the total to dto
		dto.setStrTotal(adminAllocDetails.get(lastIndex).getCustomerGroup());
		dto.setOpeningTotal(String.valueOf(adminAllocDetails.get(lastIndex).getOpeningAccount()));
		dto.setFreezedTotal(String.valueOf(adminAllocDetails.get(lastIndex).getFreezed()));
		dto.setDeskTotal(String.valueOf(adminAllocDetails.get(lastIndex).getDesk()));
		dto.setFieldTotal(String.valueOf(adminAllocDetails.get(lastIndex).getField()));
		dto.setAgencyTotal(String.valueOf(adminAllocDetails.get(lastIndex).getAgency()));
		
		// remove the total from the list
		adminAllocDetails.remove(adminAllocDetails.size() - 1);
		
//		dto.setAdminAllocDetails(adminAllocDetails);
		model.addAttribute("adminAllocDetails", adminAllocDetails);
		
	}
	
	/**
	 * method for getting usercredentials
	 * @return userconfig
	 */
	private static UserConfigurable getUser(){
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		return (UserConfigurable) auth.getPrincipal();
	}
	
}
