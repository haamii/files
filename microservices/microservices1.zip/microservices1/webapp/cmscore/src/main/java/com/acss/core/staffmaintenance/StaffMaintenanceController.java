package com.acss.core.staffmaintenance;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.acss.core.allocation.BucketEnum;
import com.acss.core.model.staffmaintenance.StaffMaintenanceCreate;
import com.acss.core.model.staffmaintenance.StaffMaintenanceSearchModel;
import com.acss.core.model.staffmaintenance.StaffSearchCriteriaDTO;
import com.acss.core.model.staffmaintenance.StaffUpdate;
import com.acss.core.support.web.MessageHelper;

@SuppressWarnings("unused")
@Controller
public class StaffMaintenanceController {

	@Autowired
	private StaffMaintenanceService staffMaintenanceService;
	
    @Autowired
    private SessionRegistry sessionRegistry;
    
    static final String STATUSOK = "ok"; 
    static final String STATUSUNPAIDSUCCESS = "unpaidSuccess"; 
    static final String STATUSWITHTEAMSUCCESS = "withteamSuccess"; 
    static final String STATUSUNPAIDFAILED = "unpaidFailed"; 
    static final String STATUSWITHTEAMFAILED = "withteamFailed"; 
    static final String UPDATEPASSWORD = "updatepassword"; 

	@RequestMapping(value = "staffMaintenance")
	public String onLoad(Model model){
		
		StaffResultDetailsDTO staffDetail = new StaffResultDetailsDTO();
		staffMaintenanceService.getBranchList(staffDetail);
		staffMaintenanceService.getUserAccountList(staffDetail);
		
		listLoggedInUsers();
		model.addAttribute(PositionType.MODEL_ATTRIB_KEY,PositionType.values());		
		model.addAttribute(BucketEnum.MODEL_ATTRIB_KEY,BucketEnum.values());	
		model.addAttribute(StaffSearchCriteriaDTO.MODEL_ATTRIB_KEY, new StaffSearchCriteriaDTO());
		model.addAttribute(StaffResultDetailsDTO.MODEL_ATTRIB_KEY, staffDetail);		
		
		return "staffMaintenance/staffMaintenance";
	}
	
	@RequestMapping(value="ajax/staffmaintenance/staffResult" , method= RequestMethod.POST)
	public String staffSearch(
			Model model,
			@ModelAttribute StaffSearchCriteriaDTO staffSearchForm,
			@RequestParam(value = "accountcode", required = false) String accountcode,
			@RequestParam(value = "branch", required = false) String branch,
			@RequestParam(value = "positiontype", required = false) String positiontype,
			@RequestParam(value = "accountname", required = false) String accountname){
		
		StaffResultDetailsDTO staffMaintenanceDetail = new StaffResultDetailsDTO();
		
		staffMaintenanceService.doSearch(staffMaintenanceDetail,staffSearchForm);
						
		model.addAttribute(StaffSearchCriteriaDTO.MODEL_ATTRIB_KEY,staffSearchForm);		
		model.addAttribute(StaffResultDetailsDTO.MODEL_ATTRIB_KEY, staffMaintenanceDetail);		
		
		return "fragments/staffmaintenance/_staffResult";
		
	}
	
	@RequestMapping(value="staffMaintenance", method= RequestMethod.POST,params = "create_btn")
	public String createStaff(
			Model model,
			@ModelAttribute StaffSearchCriteriaDTO staffSearchForm,
			RedirectAttributes ra){
		
		StaffMaintenanceCreate createStaff  = new StaffMaintenanceCreate();
		createStaff.setInputBranch(staffSearchForm.getStaffDetail().getInputBranch());
		createStaff.setInputPositionType(staffSearchForm.getStaffDetail().getInputPositionType());
		createStaff.setInputUserCd(staffSearchForm.getStaffDetail().getInputUserCd());
		createStaff.setInputPassword(staffSearchForm.getStaffDetail().getInputPassword());
		createStaff.setInputUserName(staffSearchForm.getStaffDetail().getInputUserName());
		createStaff.setInputBucket(staffSearchForm.getStaffDetail().getInputBucket());
		model.addAttribute(StaffSearchCriteriaDTO.MODEL_ATTRIB_KEY,createStaff);
		staffMaintenanceService.createStaff(createStaff);
		
		
						
		MessageHelper.addSuccessAttribute(ra, "add.param.staffsuccess",staffSearchForm.getStaffDetail().getInputUserName());
		
		return "redirect:/staffMaintenance";
		
	}
	
	@RequestMapping(value="staffMaintenance", method= RequestMethod.POST,params = "upd_btn")
	public String update(
			@ModelAttribute StaffSearchCriteriaDTO staffSearchForm,
			Model model,
			RedirectAttributes ra){
		
		StaffUpdate update  = new StaffUpdate();
		
		update.setUpdUserCd(staffSearchForm.getStaffUpdate().getUpdUserCd());
		update.setUpdBranch(staffSearchForm.getStaffUpdate().getUpdBranch());
		update.setUpdPositionType(staffSearchForm.getStaffUpdate().getUpdPositionType());
		update.setUpdUserName(staffSearchForm.getStaffUpdate().getUpdUserName());
		update.setUpdPassword(staffSearchForm.getStaffUpdate().getUpdPassword());
		update.setUpdBucket(staffSearchForm.getStaffUpdate().getUpdBucket());
		model.addAttribute(StaffSearchCriteriaDTO.MODEL_ATTRIB_KEY,update);
		
		boolean isuserlogged = checkIfUserisLoggedin(listLoggedInUsers(),staffSearchForm.getStaffUpdate().getUpdUserCd());
		
		if(isuserlogged){
			//do nothing
			MessageHelper.addErrorAttribute(ra, "operation.failed.userloggedinupdate");
		}else{
			String succ = staffMaintenanceService.update(update);	
			if(succ.equals(STATUSOK)){
				MessageHelper.addSuccessAttribute(ra, "staff.update.success",staffSearchForm.getStaffUpdate().getUpdUserName());
			}else if(succ.equals(STATUSUNPAIDSUCCESS)){
				MessageHelper.addSuccessAttribute(ra, "update.password.success",staffSearchForm.getStaffUpdate().getUpdUserName());	
			}else if(succ.equals(STATUSUNPAIDFAILED)){
				MessageHelper.addErrorAttribute(ra, "update.failed.unpaid",staffSearchForm.getStaffUpdate().getUpdUserName());
			}else if(succ.equals(STATUSWITHTEAMSUCCESS)){
				MessageHelper.addSuccessAttribute(ra, "update.password.success",staffSearchForm.getStaffUpdate().getUpdUserName());
			}else if(succ.equals(STATUSWITHTEAMFAILED)){
				MessageHelper.addErrorAttribute(ra, "update.failed.withteam",staffSearchForm.getStaffUpdate().getUpdUserName());
			}
		}
		
		return "redirect:/staffMaintenance";
		
	}

	@RequestMapping(value="staffMaintenance", method= RequestMethod.POST,params = "delete_btn")
	public String delete(
			@ModelAttribute StaffSearchCriteriaDTO staffSearchForm,
			Model model,
			RedirectAttributes ra){
		
		StaffUpdate update  = new StaffUpdate();
		
		update.setUpdUserCd(staffSearchForm.getStaffUpdate().getUpdUserCd());
		model.addAttribute(StaffSearchCriteriaDTO.MODEL_ATTRIB_KEY,update);
		
		boolean isuserlogged = checkIfUserisLoggedin(listLoggedInUsers(),staffSearchForm.getStaffUpdate().getUpdUserCd());
				
		if(isuserlogged){
			//do nothing
			MessageHelper.addErrorAttribute(ra, "operation.failed.userloggedindelete");
		}else{
			String succ = staffMaintenanceService.delete(update);	
			
			if(succ.equals(STATUSOK)){
				MessageHelper.addSuccessAttribute(ra, "delete.success",staffSearchForm.getStaffUpdate().getUpdUserName());
			}else if(succ.equals(STATUSUNPAIDFAILED)){
				MessageHelper.addErrorAttribute(ra, "delete.failed.unpaid",staffSearchForm.getStaffUpdate().getUpdUserName());
			}else if(succ.equals(STATUSWITHTEAMFAILED)){
				MessageHelper.addErrorAttribute(ra, "delete.failed.withteam",staffSearchForm.getStaffUpdate().getUpdUserName());
			}
		}	
		
		return "redirect:/staffMaintenance";
		
	}
	

    private List<String> listLoggedInUsers() {
    	List<Object> principals = sessionRegistry.getAllPrincipals();

    	List<String> usersNamesList = new ArrayList<String>();

    	for (Object principal: principals) {
    	    if (principal instanceof User) {
    	        usersNamesList.add(((User) principal).getUsername());
    	    }
    	}
    	
    	return usersNamesList;
    }


    private boolean checkIfUserisLoggedin(List<String> list,String UserName){
    	
    	boolean isloggedin = false;
    	
    	for(String name : list){
    		if(name.equals(UserName)){
    			isloggedin= true;
    		}
    	}
    	
    	return isloggedin;
    	
    }
}
