package com.acss.core.teammaintenance;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.acss.core.allocation.BucketEnum;
import com.acss.core.support.web.MessageHelper;

@Controller
public class TeamMaintenanceController {
	
	@Autowired
	private TeamMaintenanceService service;	
	
	@RequestMapping(value = "teamMaintenance")
	public String onLoad(Model model) {
		TeamMaintenanceDTO teamMaintenanceDto = new TeamMaintenanceDTO();
		// branch and areaGroup List
		service.populateBranchAreaList(teamMaintenanceDto);
		// populate collector with branch
		service.populateCollectorList(teamMaintenanceDto);
		model.addAttribute(CollectorTypeEnum.MODEL_ATTRIB_KEY, CollectorTypeEnum.values());
		model.addAttribute(BucketEnum.MODEL_ATTRIB_KEY, BucketEnum.values());
		model.addAttribute(TeamMaintenanceDTO.MODEL_ATTRIB_KEY, teamMaintenanceDto);
		return "teammaintenance/teammaintenance";
	}
	
	@RequestMapping(value = "addTeam", method = RequestMethod.POST)
	String addTeam(Model model, @ModelAttribute TeamMaintenanceDTO teamMaintenanceDto, RedirectAttributes ra,
			Principal principal) {
		TeamDetails details = new TeamDetails();
		details.setStatus(0);
		service.addTeam(teamMaintenanceDto.getAddTeamDetails(), principal);
		MessageHelper.addSuccessAttribute(ra, "add.team.success");

		return "redirect:/teamMaintenance";

	}
	
	@RequestMapping(value = "ajax/teammaintenance/getTeamDetails", method = RequestMethod.GET)
	String getTeamDetails(Model model, @RequestParam(value = "teamCd", required = true) Integer teamId) {
		TeamMaintenanceDTO teamMaintenanceDto = new TeamMaintenanceDTO();
		// populate team details
		TeamUpdateDetails teamUpdateDetails = service.populateTeamDetails(teamId);
		teamMaintenanceDto.setUpdateTeamDetails(teamUpdateDetails);
		// branch and areaGroup List
		service.populateBranchAreaList(teamMaintenanceDto);
		// populate collector with branch
		service.populateCollectorList(teamMaintenanceDto);
		model.addAttribute(CollectorTypeEnum.MODEL_ATTRIB_KEY, CollectorTypeEnum.values());
		model.addAttribute(BucketEnum.MODEL_ATTRIB_KEY, BucketEnum.values());
		model.addAttribute(TeamMaintenanceDTO.MODEL_ATTRIB_KEY, teamMaintenanceDto);
		return "fragments/teammaintenance/_teamModification";

	}
	
	@RequestMapping(value = "updateTeam", method = RequestMethod.POST)
	String updateTeam(Model model, 
			@ModelAttribute TeamMaintenanceDTO teamMaintenanceDto, RedirectAttributes ra,
			Principal principal) {
	
			service.updateTeam(teamMaintenanceDto, principal);

		MessageHelper.addSuccessAttribute(ra, "team.update.success",teamMaintenanceDto.getUpdateTeamDetails().getTeamName());
		return "redirect:/teamMaintenance";

	}

}
