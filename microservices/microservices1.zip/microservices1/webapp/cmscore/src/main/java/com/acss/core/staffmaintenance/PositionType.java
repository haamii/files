/**
 * 
 */
package com.acss.core.staffmaintenance;

import java.util.HashMap;
import java.util.Map;

/**
 * @author jarnonobal
 *
 */
public enum PositionType {
	
	SUPERVISOR("SUPERVISOR","SUPERVISOR"),
	DESKCALLER("DESK_CALLER","DESK CALLER"),
	SYSTEMADMINISTRATOR("SYSTEM_ADMINISTRATOR","SYSTEM ADMINISTRATOR"),
	TEAMLEADER("TEAM_LEADER","TEAM LEADER"),
	FIELDCOLLECTOR("FIELD_COLLECTOR","FIELD COLLECTOR");
	
	private String code;
	private String value;
	
	public final static String MODEL_ATTRIB_KEY = "positiontype";
	
	public final static class BootstrapSingleton {
		public static final Map<String, PositionType> lookupByValue = new HashMap<String, PositionType>();
		public static final Map<String, PositionType> lookupByCode = new HashMap<String, PositionType>();
	}

	PositionType(String code, String value) {
		this.code = code;
		this.value = value;
		BootstrapSingleton.lookupByValue.put(value, this);
		BootstrapSingleton.lookupByCode.put(code, this);
	}
	
	public String getCode() {
		return code;
	}

	public String getValue() {
		return value;
	}
	
	
    public static String getEnumByString(String code){
        for(PositionType e : PositionType.values()){
            if(code.equals(e.getCode())) return e.value;
        }
        return null;
    }
	
}
