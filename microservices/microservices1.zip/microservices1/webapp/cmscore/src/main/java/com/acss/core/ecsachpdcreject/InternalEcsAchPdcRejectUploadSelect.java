package com.acss.core.ecsachpdcreject;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class InternalEcsAchPdcRejectUploadSelect {
	@Autowired
	private EcsAchPdcRejectService service;

	@RequestMapping(value = "uploadSummary", method = RequestMethod.GET)
	public List<PaymentRejectDTO> getUploadSummary(@RequestParam(value="fileName", required=false) String fileName) {
		List<PaymentRejectDTO> uploadSummaryDetails = service.populateUploadSummary(fileName);
		return uploadSummaryDetails;
	}
	

}