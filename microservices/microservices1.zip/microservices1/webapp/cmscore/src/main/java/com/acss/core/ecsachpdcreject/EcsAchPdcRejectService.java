/**
 * 
 */
package com.acss.core.ecsachpdcreject;

import java.util.List;

/**
 * @author jpetronio
 *
 */
public interface EcsAchPdcRejectService {
	public String validateFilename(String filename);
	public List<PaymentRejectDTO> doReadFile(String filename);
	public List<PaymentRejectDTO> populateUploadSummary(String fileName);
}
