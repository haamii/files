/**
 * 
 */
package com.acss.core.allocation;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.acss.core.model.allocation.AllocationReportModel;

/**
 * @author jpetronio
 *
 */
@Component
public class RsAllocationConfirmReport implements AllocationConfirmReportService {
	@Autowired
	private Environment env;

	private static final String RSALLOCATIONREPORT_CONFIRM_URL_KEY = "rs.allocationReport.confirm.url";

	@Override
	public List<AllocationReportModel> populateAllocationReport(String accountId) {
		String uri = env.getProperty(RSALLOCATIONREPORT_CONFIRM_URL_KEY) + "accountId=" + accountId;

		RestTemplate rt = new RestTemplate();

		ResponseEntity<AllocationReportModel[]> response = rt.getForEntity(uri, AllocationReportModel[].class);
		List<AllocationReportModel> allocationReport = Arrays.asList(response.getBody());

		return allocationReport;
	}

}
