package com.acss.core.teammaintenance;

import java.util.List;

import com.acss.core.model.allocation.BranchDTO;

public class TeamMaintenanceDTO {
	
	private String branch;
	private String areaGroup;
	private String collectorType;
	private Integer bucket;
	private Integer status;
	private TeamDetails addTeamDetails;
	private TeamUpdateDetails updateTeamDetails;
	private List<BranchDTO> branchAreaList;
	private List<CollectorModel> collectorList;
	
	public final static String MODEL_ATTRIB_KEY = "teamMaintenanceForm";
	
	public TeamMaintenanceDTO(){
		addTeamDetails = new TeamDetails();
		updateTeamDetails =  new TeamUpdateDetails();
	}
	
	/**
	 * Append all present parameters as query string in the GET request
	 * @param uri
	 * @return uri with parameters.
	 */
	public String appendParameters(String uri){	
		uri=addTeamDetails.getBranchnm()!=null&&addTeamDetails.getBranchnm().length()>0?uri+"branchnm="+addTeamDetails.getBranchnm()+"&":uri;
		uri=updateTeamDetails.getBranchnm()!=null&&updateTeamDetails.getBranchnm().length()>0?uri+"branchnm="+updateTeamDetails.getBranchnm()+"&":uri;
		uri=branch!=null&&branch.length()>0?uri+"branch="+branch+"&":uri;
		uri=areaGroup!=null&&areaGroup.length()>0?uri+"areaGroup="+areaGroup+"&":uri;
		uri=bucket!=null?uri+"bucket="+bucket+"&":uri;
		uri=status!=null?uri+"status="+status+"&":uri;
		uri=collectorType!=null?uri+"collectorType="+collectorType+"&":uri;
		return uri;
	}
	
	/**
	 * @return the branch
	 */
	public String getBranch() {
		return branch;
	}
	/**
	 * @param branch the branch to set
	 */
	public void setBranch(String branch) {
		this.branch = branch;
	}
	/**
	 * @return the areaGroup
	 */
	public String getAreaGroup() {
		return areaGroup;
	}
	/**
	 * @param areaGroup the areaGroup to set
	 */
	public void setAreaGroup(String areaGroup) {
		this.areaGroup = areaGroup;
	}

	/**
	 * @return the bucket
	 */
	public Integer getBucket() {
		return bucket;
	}


	/**
	 * @param bucket the bucket to set
	 */
	public void setBucket(Integer bucket) {
		this.bucket = bucket;
	}


	/**
	 * @return the status
	 */
	public Integer getStatus() {
		return status;
	}


	/**
	 * @param status the status to set
	 */
	public void setStatus(Integer status) {
		this.status = status;
	}

	
	/**
	 * @return the teamDetails
	 */
	public TeamDetails getAddTeamDetails() {
		return addTeamDetails;
	}
	/**
	 * @param teamDetails the teamDetails to set
	 */
	public void setAddTeamDetails(TeamDetails addTeamDetails) {
		this.addTeamDetails = addTeamDetails;
	}
	/**
	 * @return the updateTeamDetails
	 */
	public TeamUpdateDetails getUpdateTeamDetails() {
		return updateTeamDetails;
	}
	/**
	 * @param updateTeamDetails the updateTeamDetails to set
	 */
	public void setUpdateTeamDetails(TeamUpdateDetails updateTeamDetails) {
		this.updateTeamDetails = updateTeamDetails;
	}


	/**
	 * @return the branchAreaList
	 */
	public List<BranchDTO> getBranchAreaList() {
		return branchAreaList;	
	}


	/**
	 * @param branchAreaList the branchAreaList to set
	 */
	public void setBranchAreaList(List<BranchDTO> branchAreaList) {
		this.branchAreaList = branchAreaList;
	}

	/**
	 * @return the collectorList
	 */
	public List<CollectorModel> getCollectorList() {
		return collectorList;
	}

	/**
	 * @param collectorList the collectorList to set
	 */
	public void setCollectorList(List<CollectorModel> collectorList) {
		this.collectorList = collectorList;
	}

	/**
	 * @return the collectorType
	 */
	public String getCollectorType() {
		return collectorType;
	}

	/**
	 * @param collectorType the collectorType to set
	 */
	public void setCollectorType(String collectorType) {
		this.collectorType = collectorType;
	}
	
	
}
