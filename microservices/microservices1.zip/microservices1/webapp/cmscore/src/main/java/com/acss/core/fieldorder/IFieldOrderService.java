package com.acss.core.fieldorder;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.acss.core.model.allocation.ContactResultDTO;
import com.acss.core.model.fieldorder.FieldOrderDTO;

@Service
public interface IFieldOrderService {
	FieldOrderDTO getBranchList(FieldOrderDTO dto);
	FieldOrderDTO getTeamIDList(FieldOrderDTO dto);
	FieldOrderDTO getUserIDList(FieldOrderDTO dto);
	FieldOrderDTO fillAllocTable(FieldOrderDTO dto);
	void updateAllocation(FieldOrderDTO dto);
	void updateUnallocation(FieldOrderDTO dto);
	void initTallocationTemp(FieldOrderDTO dto);
	FieldOrderDTO fillUnAllocAccounts(FieldOrderDTO dto);
	FieldOrderDTO fillUnAllocTable(FieldOrderDTO dto);
	FieldOrderDTO fillUnAllocTablehidden(FieldOrderDTO dto);
	List<ContactResultDTO> generateContactResult();
}
