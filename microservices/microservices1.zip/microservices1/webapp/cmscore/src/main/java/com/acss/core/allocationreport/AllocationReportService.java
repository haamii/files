package com.acss.core.allocationreport;

import java.util.List;

import com.acss.core.model.allocation.AllocationReportModel;

public interface AllocationReportService {

	void populateBranchAreaList(AllocationReportDTO allocationReportDTO);
	List<AllocationReportModel> populateAllocationReport(AllocationReportDTO allocationReportDTO);
}
