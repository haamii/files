package com.acss.core.customerpayment;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.acss.core.model.customerpayment.CustPDCHistory;
import com.acss.core.model.customerpayment.CustomerACHHistory;
import com.acss.core.model.customerpayment.CustomerAgreement;
import com.acss.core.model.customerpayment.CustomerECSHistory;
import com.acss.core.model.customerpayment.CustomerInstallmentNote;
import com.acss.core.model.customerpayment.CustomerInstallmentSummary;
import com.acss.core.model.customerpayment.CustomerPaymentDTO;
import com.acss.core.model.customerpayment.CustomerPaymentDate;
import com.acss.core.model.customerpayment.CustomerPaymentSearch;

@Service
public class CustomerPaymentService implements ICustmerPaymentService{
	
	@Autowired
	private Environment env;
	
	private static final String RS_CUSTOMERPAYMENTSEARCH = "rs.customerpayment.searchresult.url";
	private static final String RS_CUSTOMERPAYMENTSEARCHAGREEMENTS = "rs.customerpayment.searchagreement.url";
	private static final String RS_CUSTOMERPAYMENTDATE="rs.customerpayment.searchpaydate.url";
	private static final String RS_CUSTOMERINSTALLMENT="rs.customerpayment.searchinstallment.url";
	private static final String RS_CUSTOMERECS="rs.customerpayment.searchecs.url";
	private static final String RS_CUSTOMERPDC="rs.customerpayment.searchpdc.url";
	private static final String RS_CUSTOMERACH="rs.customerpayment.searchach.url";
	private static final String RS_CUSTOMERINSTALLMENTSUMMARY="rs.customerpayment.installmentsummary.url";
	
	@Override
	public List<CustomerPaymentSearch> search(CustomerPaymentSearch searchData) {
		// TODO Auto-generated method stub
		
		String uri = env.getProperty(RS_CUSTOMERPAYMENTSEARCH);		
		RestTemplate rt = new RestTemplate();	
		uri = searchData.appendParameters(uri);
		
		ResponseEntity<CustomerPaymentSearch[]> response = rt.getForEntity(uri, CustomerPaymentSearch[].class);
		
		List<CustomerPaymentSearch> criteria = Arrays.asList(response.getBody());	
	
		return criteria;
	}
	
	@Override
	public List<CustomerAgreement> searchAgreements(CustomerPaymentSearch searchData) {
		// TODO Auto-generated method stub
		
		String uri = env.getProperty(RS_CUSTOMERPAYMENTSEARCHAGREEMENTS);		
		RestTemplate rt = new RestTemplate();	
		uri = searchData.appendParameters(uri);
		
		ResponseEntity<CustomerAgreement[]> response = rt.getForEntity(uri, CustomerAgreement[].class);
		
		List<CustomerAgreement> criteria = Arrays.asList(response.getBody());	
	
		return criteria;
	}
	
	@Override
	public CustomerInstallmentSummary searchInstallmentDetails(CustomerPaymentSearch searchData) {
		// TODO Auto-generated method stub
		
		String uri = env.getProperty(RS_CUSTOMERINSTALLMENTSUMMARY);		
		RestTemplate rt = new RestTemplate();	
		uri = searchData.appendParameters(uri);		
		ResponseEntity<CustomerInstallmentSummary> response = rt.getForEntity(uri, CustomerInstallmentSummary.class);
		return response.getBody();	
	}

	@Override
	public List<CustomerPaymentDate> searchPaymentDate(
			CustomerPaymentSearch searchData) {
		// TODO Auto-generated method stub
		String uri = env.getProperty(RS_CUSTOMERPAYMENTDATE);
		RestTemplate rt = new RestTemplate();	
		uri = searchData.appendParameters(uri);
		ResponseEntity<CustomerPaymentDate[]> response = rt.getForEntity(uri, CustomerPaymentDate[].class);
		List<CustomerPaymentDate> criteria = Arrays.asList(response.getBody());	
		return criteria;
	}

	@Override
	public CustomerPaymentDTO searchInstallmentTable(
			CustomerPaymentSearch searchData) {
		// TODO Auto-generated method stub
		String uri = env.getProperty(RS_CUSTOMERINSTALLMENT);
		RestTemplate rt = new RestTemplate();	
		uri = searchData.appendParameters(uri);
		ResponseEntity<CustomerInstallmentNote[]> response = rt.getForEntity(uri, CustomerInstallmentNote[].class);
		List<CustomerInstallmentNote> criteria = Arrays.asList(response.getBody());	
		
		CustomerPaymentDTO dto = new CustomerPaymentDTO();
		dto.setCustomerInstallmentNote(criteria);
		return dto;
	}

	@Override
	public List<CustomerECSHistory> searchEcsTable(CustomerPaymentSearch searchData) {
		// TODO Auto-generated method stub
		RestTemplate rt = new RestTemplate();	
		String uri = env.getProperty(RS_CUSTOMERECS);
		uri = searchData.appendParameters(uri);
		ResponseEntity<CustomerECSHistory[]> response = rt.getForEntity(uri, CustomerECSHistory[].class);
		List<CustomerECSHistory> criteria = Arrays.asList(response.getBody());	
		return criteria;
	}

	@Override
	public List<CustPDCHistory> searchPdcTable(CustomerPaymentSearch searchData) {
		// TODO Auto-generated method stub
		String uri = env.getProperty(RS_CUSTOMERPDC);
		RestTemplate rt = new RestTemplate();	
		uri = searchData.appendParameters(uri);
		ResponseEntity<CustPDCHistory[]> response = rt.getForEntity(uri, CustPDCHistory[].class);
		List<CustPDCHistory> criteria = Arrays.asList(response.getBody());	
		return criteria;
	}

	@Override
	public List<CustomerACHHistory> searchAchTable(CustomerPaymentSearch searchData) {
		// TODO Auto-generated method stub
		String uri = env.getProperty(RS_CUSTOMERACH);
		RestTemplate rt = new RestTemplate();	
		uri = searchData.appendParameters(uri);
		ResponseEntity<CustomerACHHistory[]> response = rt.getForEntity(uri, CustomerACHHistory[].class);
		List<CustomerACHHistory> criteria = Arrays.asList(response.getBody());	
		return criteria;
	}
	
}
