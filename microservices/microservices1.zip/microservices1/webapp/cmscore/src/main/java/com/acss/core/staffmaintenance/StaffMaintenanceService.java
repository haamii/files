package com.acss.core.staffmaintenance;

import com.acss.core.model.staffmaintenance.StaffMaintenanceCreate;
import com.acss.core.model.staffmaintenance.StaffSearchCriteriaDTO;
import com.acss.core.model.staffmaintenance.StaffUpdate;

public interface StaffMaintenanceService {
	public void getBranchList(StaffResultDetailsDTO staffResultDetailsDTO);
	public void doSearch(StaffResultDetailsDTO staffMaintenanceDetail,StaffSearchCriteriaDTO staffSearchForm);
	public void getUserAccountList(StaffResultDetailsDTO staffResultDetailsDTO);
	public void createStaff(StaffMaintenanceCreate createStaff);
	public String update(StaffUpdate update);
	String delete(StaffUpdate update);
}
