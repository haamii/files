package com.acss.core.agencymaintenance;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class InternalAgencyRestController {
	
	@Autowired
	private AgencyMaintenanceService service;
	
	@RequestMapping(value="ajax/agencymaintenance/agencyResult", method = RequestMethod.GET)
	public List<AgencyResultModel> agencyStaff(
			@ModelAttribute AgencyMaintenanceDTO agencyMaintenanceDTO){		
		return service.getAgencies(agencyMaintenanceDTO);
	}

}
