package com.acss.core.feedbackreport;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.acss.core.model.feedbackreport.FeedbackReportDTO;
import com.acss.core.model.feedbackreport.FeedbackResultModel;

@RestController
public class InternalFeedbackRestController {
	
	@Autowired
	private FeedbackReportService feedbackReportService;
	
	@RequestMapping(value="ajax/feebackreport/getFeedbackReport" , method = RequestMethod.GET)
	public List<FeedbackResultModel> getFeedbackReport(
			@ModelAttribute FeedbackReportDTO feedbackReportDTO){
		return feedbackReportService.populateFeedbackReport(feedbackReportDTO);
	}
}
