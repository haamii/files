/**
 * 
 */
package com.acss.core.feedbackreport;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.acss.core.model.feedbackreport.FeedbackReportDTO;

/**
 * @author jarnonobal
 *
 */
@Controller
public class FeedbackReportController {
	
	@RequestMapping(value = "feedbackreport")
	public String onLoad(Model model){
		model.addAttribute(FeedbackEnum.MODEL_ATTRIB_KEY, FeedbackEnum.values());
		model.addAttribute(FeedbackReportDTO.MODEL_ATTRIB_KEY, new FeedbackReportDTO());
		return "feedbackreport/feedbackreport";		
	}

}
