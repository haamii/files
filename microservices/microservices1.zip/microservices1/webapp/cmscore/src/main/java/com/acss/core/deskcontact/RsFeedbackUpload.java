package com.acss.core.deskcontact;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.acss.core.account.UserConfigurable;
import com.acss.core.model.deskcontact.FeedbackUploadDTO;
/*
 * @author sgalvez
 */

@Component
public class RsFeedbackUpload implements FeedbackUploadService {

	@Autowired
	private Environment env;
	
	private final static String RSFEEDBACK_GETFILENAME_URL_KEY = "rs.feedback.getFileName.url";
	private final static String RSFEEDBACK_READFILE_URL_KEY = "rs.feedback.readFile.url";
	
	private final static String SCREENID_SAVE_KEY = "view.deskContact.id";
	private UserConfigurable us = null;
	
	@Override
	public String validateFilename(String filename) {
		
		String uri = env.getProperty(RSFEEDBACK_GETFILENAME_URL_KEY);
		uri = uri + "filename="+filename;
		
		RestTemplate rt = new RestTemplate();
		ResponseEntity<String> response = rt.getForEntity(uri, String.class);
		return response.getBody();
	}
	
	@Override
	public List<FeedbackUploadDTO> doReadFile(String filename, String path) { 
		
		us = (UserConfigurable)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String uri = env.getProperty(RSFEEDBACK_READFILE_URL_KEY);
		uri = uri + "fileName="+filename;
		uri = uri + "&path="+path;
		uri = uri + "&userCd="+us.getUsername();
		uri = uri + "&proId="+env.getProperty(SCREENID_SAVE_KEY);
		
		RestTemplate rt = new RestTemplate();
		
		ResponseEntity<FeedbackUploadDTO[]> response = rt.getForEntity(uri, FeedbackUploadDTO[].class);
		List<FeedbackUploadDTO> feedbackUploadForm = Arrays.asList(response.getBody());
		return feedbackUploadForm;
	}
	
}
