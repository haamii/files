package com.acss.core;

public interface Application {}
