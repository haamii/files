package com.acss.core.deskproductivityreport;

import java.util.List;

import com.acss.core.model.deskproductivityreport.DeskProductivityReportModel;
import com.acss.core.model.deskproductivityreport.DeskProductivityReportSearchModel;
/**
 * @author sgalvez
 */
public interface DeskProductivityReportService {
	List<DeskProductivityReportModel> populateReport(DeskProductivityReportSearchModel form);
}
