package com.acss.core.deskcontact;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.acss.core.model.deskcontact.FeedbackUploadDTO;
import com.acss.core.support.web.MessageHelper;
/*
 * @author sgalvez
 */
@Controller
public class FeedbackUploadController {

	@Autowired
	private FeedbackUploadService feedbackUploadService;
	@Autowired
	private Environment env;
	
	private static final String ROOT = "uploadPathFeedback";
	
	@RequestMapping(value = "ajax/feedbackUpload/validateFilename", method = RequestMethod.POST)
	public String doValidateFilename(Model model,
			@RequestParam(value="file", required=false) MultipartFile file){
		
		List<FeedbackUploadDTO> feedbackUploadForm = new ArrayList<FeedbackUploadDTO>();
		String newFileName = FilenameUtils.removeExtension(file.getOriginalFilename()).replaceAll(" ", "_");
		String extension = FilenameUtils.getExtension(file.getOriginalFilename());
		String isExisting = "";
		
		isExisting = feedbackUploadService.validateFilename(newFileName);
		
		try {
			
			if (isExisting.equals("NE")) {
				
				// Create directory if not existing
				File theDir = new File(env.getProperty(ROOT));
				if (!theDir.exists()) theDir.mkdir();
				
				// Copy and Rename File 
				Files.copy(file.getInputStream(), Paths.get(env.getProperty(ROOT), file.getOriginalFilename()));
				File originalFile = new File(env.getProperty(ROOT)+ file.getOriginalFilename());
				originalFile.renameTo(new File(env.getProperty(ROOT)+ newFileName+"."+extension));
				
				//Read the Contents
				feedbackUploadForm = feedbackUploadService.doReadFile(newFileName+"."+extension, env.getProperty(ROOT));
				
				// Set Attributes
				if (!feedbackUploadForm.isEmpty()) {
					model.addAttribute(FeedbackUploadDTO.MODEL_ATTRIB_KEY,feedbackUploadForm);
					MessageHelper.addSuccessAttribute(model, "upload.file.done");
				} else {
					originalFile.delete();
					MessageHelper.addWarningAttribute(model, "upload.file.empty", file.getOriginalFilename());
				}
				
			} else {
				MessageHelper.addErrorAttribute(model, "upload.file.error", file.getOriginalFilename());
			}
		
		} catch (IOException e) {
			MessageHelper.addErrorAttribute(model, "upload.file.error", file.getOriginalFilename());
		}
		
		return "fragments/deskcontact/_feedbackupload";
	}
	
}