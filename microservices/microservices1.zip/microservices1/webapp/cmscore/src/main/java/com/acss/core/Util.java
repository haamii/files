package com.acss.core;

import java.math.BigDecimal;

public class Util {
	
	public static String castToString(Object obj) {
		if (obj != null) {
			if(obj instanceof String) {
				return (String) obj;
			} else if (obj instanceof BigDecimal) {
				return ((BigDecimal) obj).toString();
			} else if (obj instanceof Integer) {
				return ((Integer) obj).toString();
			} else {
				return "";
			}
		}
		
		return "";
	}
}
