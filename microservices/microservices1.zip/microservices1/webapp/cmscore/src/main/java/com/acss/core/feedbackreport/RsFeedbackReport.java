package com.acss.core.feedbackreport;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.acss.core.model.feedbackreport.FeedbackReportDTO;
import com.acss.core.model.feedbackreport.FeedbackResultModel;

@Component
public class RsFeedbackReport implements FeedbackReportService {
	
	@Autowired
	private Environment env;
	
	private final static String RSREPORT_FEEDBACKREPORT_SEARCH_URL_KEY = "rs.feedbackReport.search.url";

	@Override
	public List<FeedbackResultModel> populateFeedbackReport(FeedbackReportDTO feedbackReportDTO) {
		// TODO Auto-generated method stub
		
		
		String uri = env.getProperty(RSREPORT_FEEDBACKREPORT_SEARCH_URL_KEY);
		RestTemplate rt = new RestTemplate();		
		uri = feedbackReportDTO.appendParameters(uri);
		
		ResponseEntity<FeedbackResultModel[]> response = rt.getForEntity(uri, FeedbackResultModel[].class);
		List<FeedbackResultModel> feedbackList = Arrays.asList(response.getBody());
		
		List<FeedbackResultModel> listFeedback = new ArrayList<FeedbackResultModel>();	
		
		for(FeedbackResultModel e: feedbackList){
			FeedbackResultModel container = new FeedbackResultModel();
			container.setAgreementCd(e.getAgreementCd());
			container.setComments(e.getComments());
			container.setContactresult(FeedbackEnum.getEnumByString(e.getContactresult()));
			container.setCredate(e.getCredate());
			listFeedback.add(container);
		}
		
		return listFeedback;
	}

}
