package com.acss.core.allocation;

import java.security.Principal;

import com.acss.core.model.allocation.AllocationCriteriaSearchDTO;
import com.acss.core.model.allocation.AllocationResultDetailsDTO;

public interface AllocationService {
	
	public void populateBranchAreaList(AllocationResultDetailsDTO allocationDTO);
	public void getNumberOfAccounts(AllocationResultDetailsDTO allocationDTO, AllocationCriteriaSearchDTO allocationSearchForm);
	public void getAllocationResult(AllocationResultDetailsDTO allocationDTO, AllocationCriteriaSearchDTO allocationSearchForm, String selected, String currentCollector, String function);
	public void getAllocationResulthidden(AllocationResultDetailsDTO allocationDTO, AllocationCriteriaSearchDTO allocationSearchForm, String selected, String currentCollector, String function);
	public void populateCollectors(AllocationResultDetailsDTO allocationDTO, AllocationCriteriaSearchDTO allocationSearchForm);
	public void updateAllocation(String currentCollector, AllocationCriteriaSearchDTO allocationSearchForm, Principal principal);
	public boolean allocateAgreements(AllocationCriteriaSearchDTO dto);

}
