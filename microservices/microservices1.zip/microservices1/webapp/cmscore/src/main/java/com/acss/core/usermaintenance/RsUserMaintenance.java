package com.acss.core.usermaintenance;



import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import com.acss.core.model.ACSSDateUtil;
import com.acss.kaizen.jooq.poc.account.Account;
import com.acss.kaizen.jooq.poc.base.UpdateableRepository;

/**
 * 
 * @author hmangao
 *
 */
@Component
public class RsUserMaintenance implements UserMaintenanceService {

	@Autowired
	private UpdateableRepository<Account,String> accountRepo;
	
	//private AccountRepository accountRepo
	
	@Override
	public void addUser(Account account) {

		account.setCreDate(ACSSDateUtil.getDateAsYYYYMMDDFromDateTime());
		account.setCreTime(ACSSDateUtil.getTimeAsHHMMSSFromDateTime());
		account.setDelflag(new BigDecimal(0)); //default
		accountRepo.add(account);
	}

	
	/**
	 * Implements loading by user name for Spring Security Context.
	 */
	@Override
	public List<Account> findHPSUsers() throws UsernameNotFoundException {

		return accountRepo.findAll();
		
	}

}
