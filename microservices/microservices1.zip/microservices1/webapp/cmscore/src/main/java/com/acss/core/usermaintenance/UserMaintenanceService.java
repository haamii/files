package com.acss.core.usermaintenance;

import java.util.List;

import com.acss.kaizen.jooq.poc.account.Account;

public interface UserMaintenanceService {
	
	public void addUser(Account account);
	
	public List<Account> findHPSUsers();
	
	
}
