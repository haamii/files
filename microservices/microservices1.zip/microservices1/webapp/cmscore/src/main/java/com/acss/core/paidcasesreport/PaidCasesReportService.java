/**
 * 
 */
package com.acss.core.paidcasesreport;

import com.acss.core.model.paidcasesreport.PaidCasesReportDTO;

/**
 * @author jpetronio
 *
 */
public interface PaidCasesReportService {
	public PaidCasesReportDTO populatePaidCasesReport(PaidCasesReportDTO form);
}
