package com.acss.core.areamaintenance;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.acss.core.model.application.ZipCode;
import com.acss.core.model.areamaintenance.AreaDetails;
import com.acss.core.model.areamaintenance.AreaMaintenanceSearchDTO;
import com.acss.core.model.areamaintenance.AreaSummary;

@RestController
public class InternalAreaRestController {
	
	@Autowired
	private Environment env;
	
	private final static String RSAREA_ADD_URL_KEY = "rs.area.add.url";
	private final static String RSAREA_SUMMARY_URL_KEY = "rs.area.summary.url";
	private final static String RSUTILS_ZIPCODE_URL_KEY = "rs.utils.zipcode.url";
	
	@RequestMapping(value="areas", method = RequestMethod.GET)
	public List<AreaDetails> getAreas(
			@RequestParam(value = "branchName", required = false) String branchName,
			@RequestParam(value = "area", required = false) String areaName){
		
		RestTemplate rt = new RestTemplate();
		
		
		String uri = env.getProperty(RSAREA_ADD_URL_KEY);
		AreaMaintenanceSearchDTO searchCriteria = new AreaMaintenanceSearchDTO(branchName, areaName, "");
		
		uri = searchCriteria.appendParameters(uri);
		
		ResponseEntity<AreaDetails[]> response = rt.getForEntity(uri, AreaDetails[].class);
		List<AreaDetails> areas =  Arrays.asList(response.getBody());
	
		return areas;
	}
	
	@RequestMapping(value="areasummary", method = RequestMethod.GET)
	public List<AreaSummary> getBranchSummary(
			@RequestParam(value = "branchName", required = false) String branchName
			){

		RestTemplate rt = new RestTemplate();
		
		String uri = env.getProperty(RSAREA_SUMMARY_URL_KEY);
		AreaMaintenanceSearchDTO searchCriteria = new AreaMaintenanceSearchDTO(branchName, "", "");
		uri = searchCriteria.appendParameters(uri);

		ResponseEntity<AreaSummary[]> response = rt.getForEntity(uri, AreaSummary[].class);
		List<AreaSummary> areaSummary =  Arrays.asList(response.getBody());
		
		return areaSummary;
	}
	
	
	@RequestMapping(value="zipcode", method = RequestMethod.GET)
	public List<ZipCode> zipCode(@RequestParam(value = "branchName", required = false) String branchName,
			@RequestParam(value = "postCode", required = false) String postCode){
			
		RestTemplate template = new RestTemplate();

		String uri = env.getProperty(RSUTILS_ZIPCODE_URL_KEY);
		
		AreaMaintenanceSearchDTO searchCriteria = new AreaMaintenanceSearchDTO(branchName, "", postCode);
		uri = searchCriteria.appendParameters(uri);
		

		
		ZipCode[] zipCodes = template.getForObject(uri, ZipCode[].class);
		return Arrays.asList(zipCodes);	
	}

}
