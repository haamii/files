package com.acss.core.areamaintenance;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.acss.core.model.application.ZipCode;
import com.acss.core.model.areamaintenance.AreaDetails;
import com.acss.core.model.areamaintenance.AreaMaintenanceDTO;
import com.acss.core.model.areamaintenance.BranchModel;

/**
 * Restful implementation of area maintenance module
 * @author hmangao
 *
 */
@Component
public class RsAreaMaintenance implements AreaMaintenanceService {
	
	@Autowired
	private Environment env;
	
	private final static String RSAREA_CRITERIA_URL_KEY = "rs.area.criteria.url";
	private final static String RSAREA_ADD_URL_KEY = "rs.area.add.url";
	private final static String RSAREA_DELETE_URL_KEY = "rs.area.delete.url";
	
	private final static String SCREENID_ADD_KEY = "view.popAMaintenance.id";

	@Override
	public void populateBranchList(AreaMaintenanceDTO areaMaintenance) {
		RestTemplate rt = new RestTemplate();
		String uri = env.getProperty(RSAREA_CRITERIA_URL_KEY);
		
		ResponseEntity<BranchModel[]> response = rt.getForEntity(uri, BranchModel[].class);
		List<BranchModel> branches =  Arrays.asList(response.getBody());
		
		List<String> branchList = new ArrayList<String>();
		branchList = areaMaintenance.getAreaCriteria().getBranchList();
		
		for(BranchModel branch: branches){
			branchList.add(branch.getBranchnm());
		}
	}
	
	@Override
	public void populateBranchListForArea(AreaMaintenanceDTO areaMaintenance) {
		RestTemplate rt = new RestTemplate();
		String uri = env.getProperty(RSAREA_CRITERIA_URL_KEY);
		
		ResponseEntity<BranchModel[]> response = rt.getForEntity(uri, BranchModel[].class);
		List<BranchModel> branches =  Arrays.asList(response.getBody());
		
		//original list of branches
		List<String> branchList = new ArrayList<String>();
		branchList = areaMaintenance.getAreaCriteria().getBranchList();
		
		//list of branches with "Not Assigned"
		List<String> branchListForArea = new ArrayList<String>();
		branchListForArea = areaMaintenance.getAreaCriteria().getBranchListForArea();
		
		for(BranchModel branch: branches){
			branchList.add(branch.getBranchnm());
			branchListForArea.add(branch.getBranchnm());
		}
		branchListForArea.add("NOT ASSIGNED");
		
	}
	
	@Override
	public void addArea(AreaDetails area, Principal principal) {
		//Service which accepts POST using AreaDetails as requestBody.
		RestTemplate rt = new RestTemplate();
		String uri = env.getProperty(RSAREA_ADD_URL_KEY);
		area.prepareForCreate(principal.getName(), env.getProperty(SCREENID_ADD_KEY));
		rt.postForEntity(uri,area,AreaDetails.class);
	}
	
	@Override
	public void deleteArea(String selectedPostId) {
		RestTemplate rt = new RestTemplate();
		String uri = env.getProperty(RSAREA_DELETE_URL_KEY) + selectedPostId;
		rt.postForEntity(uri,null,null);
	}

}
