/**
 * 
 */
package com.acss.core.staffmaintenance;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.acss.core.model.allocation.BranchDTO;
import com.acss.core.model.staffmaintenance.StaffMaintenanceCreate;
import com.acss.core.model.staffmaintenance.StaffMaintenanceSearchModel;
import com.acss.core.model.staffmaintenance.StaffSearchCriteriaDTO;
import com.acss.core.model.staffmaintenance.StaffUpdate;
import com.acss.core.model.staffmaintenance.UserAccountModel;

/**
 * @author jarnonobal
 *
 */
@Component
public class RsStaffMaintenance implements StaffMaintenanceService {

	@Autowired
	private Environment env;

	private final static String RSSTAFF_BRANCH_URL_KEY = "rs.staff.branch.url";
	private final static String RSSTAFF_SEARCH_URL_KEY = "rs.staff.search.url";
	private final static String RSSTAFF_USER_URL_KEY = "rs.staff.user.url";
	private final static String RSSTAFF_CREATE_URL_KEY ="rs.staff.create.url";
	private final static String RSSTAFF_UPDATE_URL_KEY ="rs.staff.update.url";
	
	private final static String REGISTRATIONPROID ="view.popStaffRegistration.id";
	private final static String MODIFYPROID ="view.popModifyDeleteStaff.id";
	
	private final static String RSSTAFF_DELETE_KEY="rs.staff.delete.url";
	
	@Override
	public void getBranchList(StaffResultDetailsDTO staffResultDetailsDTO) {
		
		
		String uri = env.getProperty(RSSTAFF_BRANCH_URL_KEY);

		RestTemplate rt = new RestTemplate();

		ResponseEntity<BranchDTO[]> response = rt.getForEntity(uri, BranchDTO[].class);
		List<BranchDTO> criteria = Arrays.asList(response.getBody());

		staffResultDetailsDTO.setBranches(criteria);
	}
	

	@Override
	public void doSearch(StaffResultDetailsDTO staffMaintenanceDetail,StaffSearchCriteriaDTO staffSearchForm) {
		
		String uri = env.getProperty(RSSTAFF_SEARCH_URL_KEY);
		
		RestTemplate rt = new RestTemplate();
		
		uri = staffSearchForm.appendParameters(uri);
		
		ResponseEntity<StaffMaintenanceSearchModel[]> response = rt.getForEntity(uri, StaffMaintenanceSearchModel[].class);
		List<StaffMaintenanceSearchModel> criteria = Arrays.asList(response.getBody());	
		
		List<StaffMaintenanceSearchModel> searchResult  = new ArrayList<StaffMaintenanceSearchModel>();
		
		for(StaffMaintenanceSearchModel e: criteria){
			StaffMaintenanceSearchModel container = new StaffMaintenanceSearchModel();
			container.setPositiontype(PositionType.getEnumByString(e.getPositiontype()));
			container.setAccountcode(e.getAccountcode());
			container.setAccountname(e.getAccountname());
			container.setBranchnm(e.getBranchnm());
			container.setBucket(e.getBucket());
			container.setPositiontypecode(e.getPositiontype());
			searchResult.add(container);
		}
		
		staffMaintenanceDetail.setSearchResult(searchResult);
	}
	

	@Override
	public void getUserAccountList(StaffResultDetailsDTO staffResultDetailsDTO) {
		
		String uri = env.getProperty(RSSTAFF_USER_URL_KEY);

		RestTemplate rt = new RestTemplate();

		ResponseEntity<StaffMaintenanceSearchModel[]> response = rt.getForEntity(uri, StaffMaintenanceSearchModel[].class);
		List<StaffMaintenanceSearchModel> userAccountList = Arrays.asList(response.getBody());
		List<UserAccountModel> user = new ArrayList<UserAccountModel>();
		
		for(StaffMaintenanceSearchModel sModel: userAccountList){
			UserAccountModel us = new UserAccountModel();
			us.setUserCd(sModel.getAccountcode());
			us.setUserName(sModel.getAccountname());
			
			user.add(us);
		}
		
		staffResultDetailsDTO.setUserList(user);

	}


	@Override
	public void createStaff(StaffMaintenanceCreate createStaff) {
		RestTemplate rt = new RestTemplate();
		String uri = env.getProperty(RSSTAFF_CREATE_URL_KEY);	
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		StaffMaintenanceCreate create = new StaffMaintenanceCreate (
				createStaff.getInputUserCd(),
				createStaff.getInputUserName(),
				createStaff.getInputBranch(),
				createStaff.getInputPositionType(),
				createStaff.getInputPassword(),
				createStaff.getInputBucket());
		create.setCreProId(env.getProperty(REGISTRATIONPROID));
		create.setCrePerson(auth.getName());
		uri = create.appendParameters(uri);		
		
		rt.postForEntity(uri,create,StaffMaintenanceCreate.class);		
	}



	public String update(StaffUpdate update) {
		RestTemplate rt = new RestTemplate();
		String uri = env.getProperty(RSSTAFF_UPDATE_URL_KEY);	 
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		
		StaffUpdate staff = new StaffUpdate(
				update.getUpdUserCd(), 
				update.getUpdUserName(), 
				update.getUpdBranch(), 
				update.getUpdPositionType(), 
				update.getUpdCollectorCd(),
				update.getUpdPassword(),
				update.getUpdBucket());
		
		staff.setCrePerson(auth.getName());
		staff.setCreProId(env.getProperty(MODIFYPROID));
		
		uri = staff.appendParameters(uri);	
		
/*		if(checkCollector(staff)){
			return false;
		}	*/				
		ResponseEntity<String> response=rt.getForEntity(uri, String.class);	
		
		return response.getBody();
	}
	
	@Override
	public String delete(StaffUpdate update) {
		RestTemplate rt = new RestTemplate();
		String uri = env.getProperty(RSSTAFF_DELETE_KEY);	 
		
		StaffUpdate staff = new StaffUpdate(
				update.getUpdUserCd(), 
				update.getUpdUserName(), 
				update.getUpdBranch(), 
				update.getUpdPositionType(), 
				update.getUpdCollectorCd(),
				update.getUpdPassword(),
				update.getUpdBucket());
		
		uri = staff.appendParameters(uri);	
		
/*		if(checkCollector(staff)){
			return false;
		}	*/				
		
		ResponseEntity<String> response=rt.getForEntity(uri, String.class);	
		
		return response.getBody();
	}
	

}
