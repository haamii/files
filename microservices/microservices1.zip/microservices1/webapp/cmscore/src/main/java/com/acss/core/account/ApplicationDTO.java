package com.acss.core.account;


public class ApplicationDTO {
	private String appNo;
	private String customerName;
	private String appDateTime;
	private String status;
	private String seqNo;
	private String remarks;
	
	
	public String getAppNo() {
		return appNo;
	}
	public void setAppNo(String appNo) {
		this.appNo = appNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getAppDateTime() {
		return appDateTime;
	}
	public void setAppDateTime(String appDateTime) {
		this.appDateTime = appDateTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
}
