package com.acss.core.adminallocation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.acss.core.model.adminallocation.AdminAllocationDTO;
import com.acss.core.model.adminallocation.AdminAllocationModel;
import com.acss.core.model.allocation.AllocationResultDetailsDTO;
import com.acss.core.model.allocation.BranchDTO;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

@Component
public class RsAdminAllocation implements AdminAllocationService{

	private final static String RSADMINALLOCATION_RETRIEVE_URL_KEY = "rs.adminallocation.getAdminAllocDetails";
	private final static String RSADMINALLOCATION_ISCOMPLETED_URL_KEY = "rs.adminallocation.isAdminAllocCompleted";
	private final static String RSADMINALLOCATION_CONFIRM_URL_KEY = "rs.adminallocation.confirmAdminAllocation";
	private final static String RSALLOCATION_CRITERIA_URL_KEY = "rs.allocation.criteria.url";
	
	@Autowired
	private Environment env;
	
	public List<AdminAllocationModel> retrieveAdminAllocDetails(String branch) {
		List<AdminAllocationModel> adminAllocDetails = new ArrayList<AdminAllocationModel>();
		String uri = env.getProperty(RSADMINALLOCATION_RETRIEVE_URL_KEY);
		
		if (branch != null && !branch.equalsIgnoreCase("null") 
				&& !branch.equalsIgnoreCase("All") && !branch.equalsIgnoreCase("")) {
			uri = uri + "branch=" + branch;
		}
		
		RestTemplate rt = new RestTemplate();
		ResponseEntity<AdminAllocationModel[]> response = rt.getForEntity(uri, AdminAllocationModel[].class);
		adminAllocDetails = new ArrayList(Arrays.asList(response.getBody()));
		
		return adminAllocDetails;
	}
	
	@Override
	public boolean isAdminAlloCompleted(String branch) {
		String uri = env.getProperty(RSADMINALLOCATION_ISCOMPLETED_URL_KEY);
		RestTemplate rt = new RestTemplate();
		
		uri = uri + "branch=" + branch.toUpperCase();
		
		ResponseEntity<Boolean> isCompleted = rt.getForEntity(uri, Boolean.class);
		boolean isAdminAllocCompleted = isCompleted.getBody();
		
		return isAdminAllocCompleted;
	}

	@Override
	public boolean confirmAdminAllocation(AdminAllocationDTO adminAllocationDTO) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		adminAllocationDTO.setUserName(auth.getName());
		
		RestTemplate rt = new RestTemplate();
		String uri = env.getProperty(RSADMINALLOCATION_CONFIRM_URL_KEY);
		rt.postForEntity(uri, adminAllocationDTO, AdminAllocationDTO.class);
		
		return false;
	}
	
	@Override
	public void populateBranchAreaList(AdminAllocationDTO allocationDTO) {
		
		String uri = env.getProperty(RSALLOCATION_CRITERIA_URL_KEY);
		RestTemplate rt = new RestTemplate();	
		
		ResponseEntity<BranchDTO[]> response = rt.getForEntity(uri, BranchDTO[].class);
		List<BranchDTO> criteria = new ArrayList<BranchDTO>();
		BranchDTO branchDTO = new BranchDTO();
		branchDTO.setBranchName("ALL");
		branchDTO.setAreas(null);
		criteria.add(branchDTO);
		
		criteria.addAll(Arrays.asList(response.getBody()));
		
		allocationDTO.setBranches(criteria);
	}
	
}
