package com.acss.core.deskcontact;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.acss.core.account.UserConfigurable;
import com.acss.core.model.deskcontact.AccountCollectionModel;
import com.acss.core.model.deskcontact.ContactResultModel;

@RestController
public class InternalDeskContactRestController {
	
	@Autowired
	private DeskContactService deskContactService;
	
	@RequestMapping(value="contact", method = RequestMethod.GET)
	public List<ContactResultModel> populateContactResult() {
		
		UserConfigurable us = (UserConfigurable) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<ContactResultModel> contactResult = deskContactService.populateContactResult(us);
		return contactResult;
		
	}
	
	@RequestMapping(value="accountListDeskContact", method = RequestMethod.GET)
	public List<AccountCollectionModel> populateAccountResult() {
		
		UserConfigurable us = (UserConfigurable) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<AccountCollectionModel> accountResult = deskContactService.populateAccountResult(us);
		return accountResult;
		
	}
}
