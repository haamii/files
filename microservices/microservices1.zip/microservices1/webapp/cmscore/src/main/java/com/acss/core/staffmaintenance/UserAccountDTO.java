package com.acss.core.staffmaintenance;

import java.util.ArrayList;
import java.util.List;

public class UserAccountDTO {
	
	private List<String> userAccountList;
	private String userName;
	
	public UserAccountDTO(){
		userAccountList = new ArrayList<String>();
	}

	/**
	 * @return the accountList
	 */
	public List<String> getUserAccountList() {
		return userAccountList;
	}

	/**
	 * @param accountList the accountList to set
	 */
	public void setUserAccountList(List<String> userAccountList) {
		this.userAccountList = userAccountList;
	}

	/**
	 * @return the accountName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param accountName the accountName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

}
