package com.acss.core.allocationreport;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.acss.core.model.allocation.AllocationReportModel;
import com.acss.core.model.allocation.BranchDTO;
import com.acss.core.model.deskcontact.ContactResultEnum;

@Component
public class RsAllocationReport implements AllocationReportService {
	
	@Autowired
	private Environment env;
	
	private final static String RSUTILS_BRANCHAREA_URL_KEY = "rs.utils.brancharea.url";
	private final static String RSALLOCREPORT_SEARCH_URL_KEY = "rs.allocationReport.search.url";

	@Override
	public void populateBranchAreaList(AllocationReportDTO allocationReportDTO) {
		String uri = env.getProperty(RSUTILS_BRANCHAREA_URL_KEY);

		RestTemplate rt = new RestTemplate();

		ResponseEntity<BranchDTO[]> response = rt.getForEntity(uri, BranchDTO[].class);
		List<BranchDTO> branchAreaList = Arrays.asList(response.getBody());

		allocationReportDTO.setBranchAreaList(branchAreaList);
		
	}

	@Override
	public List<AllocationReportModel> populateAllocationReport(AllocationReportDTO allocationReportDTO) {
		List<AllocationReportModel> allocationReport = new ArrayList<>();
		String uri = env.getProperty(RSALLOCREPORT_SEARCH_URL_KEY);
		RestTemplate rt = new RestTemplate();		
		uri = allocationReportDTO.appendParameters(uri);		
		ResponseEntity<AllocationReportModel[]> response = rt.getForEntity(uri, AllocationReportModel[].class);
		allocationReport = Arrays.asList(response.getBody());
		
		for (AllocationReportModel allocationReportModel : allocationReport) {
			allocationReportModel.setContactResult(ContactResultEnum.getEnumNameByCode(allocationReportModel.getContactResult()));
		}
		
		return allocationReport;
	}

}
