package com.acss.core.customerpayment;

import java.util.HashMap;
import java.util.Map;

public enum PaymentStatus {
	
	UNPAID("UNPAID","UNPAID"),
	FULLYPAID("FULLYPAID","FULLY PAID"),
	PARTIALLYPAID("PARTIALLYPAID","PARTIALLY PAID");

	private String value;
	private String code;
	
	public final static String MODEL_ATTRIB_KEY = "paymentstatus";
	
	public final static class BootstrapSingleton {
		public static final Map<String, PaymentStatus> lookupByValue = new HashMap<String, PaymentStatus>();
		public static final Map<String, PaymentStatus> lookupByCode = new HashMap<String, PaymentStatus>();
	}

	PaymentStatus(String code, String value) {
		this.code = code;
		this.value = value;
		BootstrapSingleton.lookupByValue.put(value, this);
		BootstrapSingleton.lookupByCode.put(code, this);
	}
	
	public String getCode() {
		return code;
	}

	public String getValue() {
		return value;
	}
	
    public static String getEnumByString(String code){
        for(PaymentStatus e : PaymentStatus.values()){
            if(code.equals(e.getCode())) return e.value;
        }
        return null;
    }
	
}
