package com.acss.core.useraccount;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.acss.core.model.allocation.BranchDTO;
import com.acss.core.model.useraccount.UserAccountUpdateDTO;
import com.acss.core.staffmaintenance.StaffResultDetailsDTO;
/**
 * Restful implementation of user account module
 * @author sgalvez
 *
 */
@Component
public class RsUserAccount implements UserAccountService {
	
	@Autowired
	private Environment env;
	
	private final static String RSUSER_ACCOUNT_BRANCH_URL_KEY = "rs.staff.branch.url";
	private final static String RSUSER_ACCOUNT_PASSWORD_URL_KEY = "rs.staff.password.url";
	private final static String RSUSER_ACCOUNT_DETAILS_URL_KEY = "rs.staff.details.url";
		
	@Override
	public void populateBranchList(StaffResultDetailsDTO staffResultDetailsDTO){
		
		RestTemplate rt = new RestTemplate();
		String uri = env.getProperty(RSUSER_ACCOUNT_BRANCH_URL_KEY);
		ResponseEntity<BranchDTO[]> response = rt.getForEntity(uri, BranchDTO[].class);
		List<BranchDTO> branchList =  Arrays.asList(response.getBody());
		staffResultDetailsDTO.setBranches(branchList);
	}
	
	@Override
	public void populateUserAccount(UserAccountUpdateDTO userAccountForm, String userCd){
		
		RestTemplate rt = new RestTemplate();
		String uri = env.getProperty(RSUSER_ACCOUNT_DETAILS_URL_KEY) + "userCd=" + userCd;
		ResponseEntity<UserAccountUpdateDTO> response = rt.getForEntity(uri, UserAccountUpdateDTO.class);
		userAccountForm.setBranchnm(response.getBody().getBranchnm());
		userAccountForm.setName(response.getBody().getName());
		userAccountForm.setRole(response.getBody().getRole());
		
	}
	
	@Override
	public void updatePassword(UserAccountUpdateDTO userAccountForm) {
		
		RestTemplate rt = new RestTemplate();
		String uri = env.getProperty(RSUSER_ACCOUNT_PASSWORD_URL_KEY);				
		rt.postForEntity(uri, userAccountForm, UserAccountUpdateDTO.class);
	}
	

}
