package com.acss.core.fieldorder;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.acss.core.model.fieldorder.AllocatedTable;
import com.acss.core.model.fieldorder.FieldOrderDTO;
import com.acss.core.model.fieldorder.FieldOrderSearch;
import com.acss.core.model.fieldorder.FieldOrderStatic;
import com.acss.core.model.fieldorder.RemainingAccountsTable;
import com.acss.core.model.fieldorder.UnallocatedTable;


@RestController
public class InternalFieldOrderController {
	
	@Autowired
	IFieldOrderService service;
	
	@RequestMapping(value = FieldOrderStatic.FIELDORDER_FILLALLOCTABLE, method = RequestMethod.GET)
	public List<AllocatedTable> fillpaymentDateTable(
			@RequestParam(value = FieldOrderStatic.SEARCHPARAM_TEAMID, required = false) String teamid,
			@RequestParam(value = FieldOrderStatic.SEARCHPARAM_USERID, required = false) String userid,
			@RequestParam(value = FieldOrderStatic.SEARCHPARAM_BUCKET, required = false) String bucket
			){
		FieldOrderDTO fieldOrderDTO = new FieldOrderDTO();
		FieldOrderSearch search = new FieldOrderSearch();
		search.setTeamid(teamid);
		search.setBucket(bucket);
		search.setUserid(userid);
		fieldOrderDTO.setFieldOrderSearch(search);
		FieldOrderDTO result = service.fillAllocTable(fieldOrderDTO);	
		return result.getAllocatedTable();
	}
	
	@RequestMapping(value = FieldOrderStatic.FIELDORDER_REMAININGACCOUNTS, method = RequestMethod.GET)
	public List<RemainingAccountsTable> fillRemainingAccounts(
			@ModelAttribute FieldOrderDTO details){
		FieldOrderDTO result = service.fillUnAllocAccounts(details);
		RemainingAccountsTable table = new RemainingAccountsTable();
		table.setTablename(FieldOrderStatic.NAME_REMAININGACCOUNTS);
		table.setTablevalue(String.valueOf(result.getRemainingAccountModelMap().size()));
		List<RemainingAccountsTable> list = new ArrayList<RemainingAccountsTable>();
		list.add(table);
		return list;
	}
	
	@RequestMapping(value = FieldOrderStatic.FIELDORDER_FILLUNALLOCTABLE, method = RequestMethod.GET)
	public List<UnallocatedTable> fillunAllocTable(
			@ModelAttribute FieldOrderDTO details){
		FieldOrderDTO dto = service.fillUnAllocTable(details);
		return dto.getUnallocatedTable();
	}
	
	@RequestMapping(value = FieldOrderStatic.FIELDORDER_FILLUNALLOCTABLEHIDDEN, method = RequestMethod.GET)
	public List<UnallocatedTable> fillunAllocTablehidden(
			@ModelAttribute FieldOrderDTO details){
//		FieldOrderDTO dto = service.fillUnAllocTablehidden(details);
		FieldOrderDTO dto = new FieldOrderDTO();
		return dto.getUnallocatedTable();
	}
	
	

}
