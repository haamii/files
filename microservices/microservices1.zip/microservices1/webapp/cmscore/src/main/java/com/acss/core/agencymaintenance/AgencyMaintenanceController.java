package com.acss.core.agencymaintenance;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.acss.core.support.web.MessageHelper;

@Controller
public class AgencyMaintenanceController {
	
	@Autowired
	private AgencyMaintenanceService service;
	
	@RequestMapping(value="agencyMaintenance")
	public String onLoad(Model model){
		
		model.addAttribute(AgencyMaintenanceDTO.MODEL_ATTRIB_KEY, new AgencyMaintenanceDTO());
		
		return "agencymaintenance/agencymaintenance";
	}
	
	@RequestMapping(value = "agencyAdd", method= RequestMethod.POST)
	String agencyRegister(Model model,
	   @ModelAttribute AgencyMaintenanceDTO agencyMaintenanceDTO,
	   RedirectAttributes ra,
	   Principal principal) {
		
		service.addAgency(agencyMaintenanceDTO.getAgencyDetails(),principal);
		
		MessageHelper.addSuccessAttribute(ra, "add.success");
		
		return "redirect:/agencyMaintenance";
	 }
	
	@RequestMapping(value = "updateAgency", method= RequestMethod.POST)
	String agencyUpdate(Model model,			
			@ModelAttribute AgencyMaintenanceDTO agencyMaintenanceDTO,
			RedirectAttributes ra,
			Principal principal) {

			service.agencyUpdate(agencyMaintenanceDTO.getUpdateDetails(),principal);
			MessageHelper.addSuccessAttribute(ra, "staff.update.success",agencyMaintenanceDTO.getUpdateDetails().getAgencyName());

		return "redirect:/agencyMaintenance";
	 }
	
	@RequestMapping(value = "deleteAgency", method= RequestMethod.POST)
	String agencyDelete(Model model,
			@ModelAttribute AgencyMaintenanceDTO agencyMaintenanceDTO,
			RedirectAttributes ra,
			Principal principal) {		
		
		boolean isAgencyDeleted = service.isAgencyDeleted(agencyMaintenanceDTO.getUpdateDetails(), principal);
		
		if(isAgencyDeleted){
			MessageHelper.addErrorAttribute(ra, "agency.failed",agencyMaintenanceDTO.getUpdateDetails().getAgencyName());
		}else{			
			MessageHelper.addSuccessAttribute(ra, "delete.success",agencyMaintenanceDTO.getUpdateDetails().getAgencyName());
		}
		
		return "redirect:/agencyMaintenance";
	 }

}
