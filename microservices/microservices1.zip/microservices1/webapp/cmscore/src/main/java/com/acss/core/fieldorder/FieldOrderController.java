package com.acss.core.fieldorder;

import java.util.ArrayList;
import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.acss.core.allocation.BucketEnum;
import com.acss.core.model.fieldorder.AllocatedTable;
import com.acss.core.model.fieldorder.FieldOrderDTO;
import com.acss.core.model.fieldorder.FieldOrderSearch;
import com.acss.core.model.fieldorder.FieldOrderStatic;
import com.acss.core.model.fieldorder.UnallocDTO;
import com.acss.core.model.fieldorder.UnallocatedTable;
import com.acss.core.model.fieldorder.UserDetails;
import com.acss.core.model.fieldorder.UserDetailsDTO;
import com.acss.core.model.fieldorder.UserNameMCollAccount;
import com.acss.core.model.fieldorder.UserNameMCollAgency;
import com.acss.core.support.web.MessageHelper;

@Controller
public class FieldOrderController {
	
	@Autowired
	IFieldOrderService service;
	
	@Autowired
	FieldOrderUtil util;
	
	@RequestMapping(value = FieldOrderStatic.HEADERLINK)
	public String onLoad(Model model){
		FieldOrderDTO dto = new FieldOrderDTO();
		FieldOrderDTO branchlistdto = service.getBranchList(dto);
		FieldOrderDTO teamlistdto = service.getTeamIDList(dto);
		dto.setBranchdto(branchlistdto.getBranchdto());
		dto.setCollectionTeam(teamlistdto.getCollectionTeam());
		dto.setContactResult(service.generateContactResult());
		
		model.addAttribute(FieldOrderDTO.MODEL_ATTRIB_KEY,dto);
		model.addAttribute(BucketEnum.MODEL_ATTRIB_KEY,BucketEnum.values());	
		return FieldOrderStatic.FIELDORDER_MAINPAGE;
	}
	
	@RequestMapping(value = FieldOrderStatic.FIELDORDER_FILLUSERS, method = RequestMethod.GET)
	public String fillUsers(Model model,
			@RequestParam(value = FieldOrderStatic.SEARCHPARAM_TEAMID, required = false) String teamid,
			@RequestParam(value = FieldOrderStatic.SEARCHPARAM_BUCKET, required = false) String bucket){
		FieldOrderDTO dto = new FieldOrderDTO();
		FieldOrderSearch searchData = new FieldOrderSearch();
		searchData.setBucket(bucket);
		searchData.setTeamid(teamid);
		dto.setFieldOrderSearch(searchData);

		FieldOrderDTO users = service.getUserIDList(dto);
		List<UserDetails> listUsers = new ArrayList<UserDetails>();
		
		if(users.getUserNameMCollAccount() != null){
			for(UserNameMCollAccount mcollaccountdetails:users.getUserNameMCollAccount()){
				UserDetails details = new UserDetails();
				details.setUserid(mcollaccountdetails.getUsercd());
				details.setUsername(mcollaccountdetails.getUsername());
				listUsers.add(details);
			}	
		}else if(users.getUserNameMCollAgency() != null){
			for(UserNameMCollAgency mcollagencydetails:users.getUserNameMCollAgency()){
				UserDetails details = new UserDetails();
				details.setUserid(mcollagencydetails.getUsercd());
				details.setUsername(mcollagencydetails.getUsername());
				listUsers.add(details);
			}
		}
		UserDetailsDTO newdto = new UserDetailsDTO();
		newdto.setUserdetails(listUsers);
		
		model.addAttribute(UserDetailsDTO.MODEL_ATTRIB_KEY, newdto);
		model.addAttribute(FieldOrderSearch.MODEL_ATTRIB_KEY, new FieldOrderSearch());
		return FieldOrderStatic.FIELDORDER_ALLOCATEDUSERS;
	}
	
	@RequestMapping(value = FieldOrderStatic.FIELDORDER_FILLUSERSUNDER, method = RequestMethod.GET)
	public String fillUsersunder(Model model,
			@RequestParam(value = FieldOrderStatic.SEARCHPARAM_TEAMID, required = false) String teamid,
			@RequestParam(value = FieldOrderStatic.SEARCHPARAM_BUCKET, required = false) String bucket){
		FieldOrderDTO dto = new FieldOrderDTO();
		FieldOrderSearch searchData = new FieldOrderSearch();
		searchData.setBucket(bucket);
		searchData.setTeamid(teamid);
		dto.setFieldOrderSearch(searchData);

		FieldOrderDTO users = service.getUserIDList(dto);
		List<UserDetails> listUsers = new ArrayList<UserDetails>();
		
		//bind the result to common model UserDetails
		if(users.getUserNameMCollAccount() != null){
			listUsers = util.bindMCollectionAccountToUserDetails(users.getUserNameMCollAccount());
		}else if(users.getUserNameMCollAgency() != null){
			listUsers = util.bindMCollectionAgencyToUserDetails(users.getUserNameMCollAgency());
		}
		
		UserDetailsDTO newdto = new UserDetailsDTO();
		newdto.setUserdetails(listUsers);
		
		model.addAttribute(UserDetailsDTO.MODEL_ATTRIB_KEY, newdto);
		model.addAttribute(FieldOrderSearch.MODEL_ATTRIB_KEY, new FieldOrderSearch());
		return FieldOrderStatic.FIELDORDER_ALLOCATEDUSERSUNDER;
	}
	
	@RequestMapping(value = FieldOrderStatic.HEADERLINK, method = RequestMethod.POST,params = FieldOrderStatic.HEADERLINK_UPDATEALLOC)
	public String updateallocatedacc(
			Model model,
			@ModelAttribute FieldOrderDTO fieldOrderDTO,
			RedirectAttributes ra){

		List<AllocatedTable> allocatedlist = util.parseJsonToModelAllocatedTable(fieldOrderDTO);
	
		fieldOrderDTO.setAllocatedTable(allocatedlist);
		service.updateAllocation(fieldOrderDTO);
		
		MessageHelper.addSuccessAttribute(ra, FieldOrderStatic.SUCCESSMESSAGE_ID,fieldOrderDTO.getFieldOrderSearch().getUseridandname());
		return FieldOrderStatic.FIELDORDER_REDIRECT;
	}
	
	@RequestMapping(value = FieldOrderStatic.HEADERLINK, method = RequestMethod.POST,params = FieldOrderStatic.HEADERLINK_UPDATEUNALLOC)
	public String updateunallocatedacc(
			Model model,
			@ModelAttribute FieldOrderDTO fieldOrderDTO,
			RedirectAttributes ra){

		List<UnallocatedTable> unallocatedlist = util.parseJsonToModelUnAllocatedTable(fieldOrderDTO);
	
		fieldOrderDTO.setUnallocatedTable(unallocatedlist);
		service.updateUnallocation(fieldOrderDTO);
		
		MessageHelper.addSuccessAttribute(ra, FieldOrderStatic.ALLOCATEDSUCCESSMESSAGE_ID);
		return FieldOrderStatic.FIELDORDER_REDIRECT;
	}
	
	@RequestMapping(value = FieldOrderStatic.FIELDORDER_FILLGROUPBOXUNALLOC, method = RequestMethod.GET)
	public String fillgroupbox(Model model,
			@ModelAttribute FieldOrderDTO details){
		FieldOrderDTO dto = service.fillUnAllocTablehidden(details);
		
		UnallocDTO unallocdto = new UnallocDTO();
		
		unallocdto.setUnallocatedTable(dto.getUnallocatedTable());	
		model.addAttribute(UnallocDTO.MODEL_ATTRIB_KEY, unallocdto);
		return FieldOrderStatic.FIELDORDER_FRAGMENTSGROUPBOX;
	}
	
	@RequestMapping(value = FieldOrderStatic.FIELDORDER_INITTEMP, method = RequestMethod.GET)
	public String initAllocationTemp(Model model,
			@ModelAttribute FieldOrderDTO details){
		service.initTallocationTemp(details);
		return FieldOrderStatic.FIELDORDER_REDIRECT;
	}

}
