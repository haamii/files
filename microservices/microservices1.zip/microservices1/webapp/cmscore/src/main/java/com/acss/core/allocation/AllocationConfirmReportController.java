/**
 * 
 */
package com.acss.core.allocation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.acss.core.account.UserConfigurable;
import com.acss.core.model.allocation.AllocationReportModel;

import ch.qos.logback.core.net.SyslogOutputStream;

/**
 * @author jpetronio
 *
 */

@Controller
public class AllocationConfirmReportController {
	
	//private static final String reportUri = "/allocationReport?";

	@Autowired
	private InternalAllocationConfirmReportRestController InternalAllocation;
	
	@RequestMapping(value = "allocationConfirmReport", method = RequestMethod.GET)
	public String onLoad(Model model) {
		//model.addAttribute("allocResult",reportUri);
		
		UserConfigurable us = (UserConfigurable) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username = us.getUsername();
		
		Runnable myRunnable = new Runnable(){
			@Override
			public void run() {
				processAllocationReport(model, username); 
			}
		};
		Thread thread = new Thread(myRunnable);
		thread.start();
		
//		 model.addAttribute("result",result);
		 model.addAttribute("result",null);
		 return "allocation/allocationReport";
	}
	
	public void processAllocationReport(Model model, String username) {
		InternalAllocation.getAllocationReport(model, username);
	}
	
}
