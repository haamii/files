package com.acss.core.feedbackreport;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public enum FeedbackEnum {
	
	RTPI(20,"REFUSE TO PAY INTENTIONAL"),
	RTPT(21,"REFUSE TO PAY TEMPORARY"),
	NRC(10,"NOT REACHABLE"),
	NIS(9,"NOT IN SERVICE"),
	OOA(11,"OUT OF AREA"),
	OST(12,"OUT OF STATION"),
	RNR(19,"RINGING"),
	SWO(24,"SWITCH OFF"),
	NCP(8,"NOT CONTACTABLE ON PHONE"),
	PTPB(15,"PROMISE TO PAY AT BANK"),
	PTPF(17,"PROMISE TO PAY AT FIELD");
	
	public final static String MODEL_ATTRIB_KEY = "feedbackList";
	
	private int code;
	private String value;
	
	private final static class BootstrapSingleton {
		public static final Map<String, FeedbackEnum> lookupByValue = new HashMap<String, FeedbackEnum>();
		public static final Map<BigDecimal, FeedbackEnum> lookupByCode = new HashMap<BigDecimal, FeedbackEnum>();
	}
	
	FeedbackEnum(int code, String value) {
		this.code = code;
		this.value = value;		
		BootstrapSingleton.lookupByValue.put(value, this);
		BootstrapSingleton.lookupByCode.put(new BigDecimal(code), this);
	}	


	/**
	 * @return the code
	 */
	public int getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(int code) {
		this.code = code;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
	
	public static String getEnumByString(String code){
        for(FeedbackEnum e : FeedbackEnum.values()){
            if(code.equals(String.valueOf(e.getCode()))){
            	return e.value;		
            }
          
        }
        return null;
    }

}
