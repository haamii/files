/**
 * 
 */
package com.acss.core.paidcasesreport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.acss.core.model.paidcasesreport.PaidCasesReportDTO;
import com.acss.core.model.paidcasesreport.PaidCasesSearchModel;

/**
 * @author jpetronio
 *
 */
@Component
public class RsPaidCasesReport implements PaidCasesReportService {
	@Autowired
	private Environment env;
	
	public final static String RSPAIDCASESREPORT_SEARCH_URL_KEY = "rs.paidCasesReport.search.url";
	
	@Override
	public PaidCasesReportDTO populatePaidCasesReport(PaidCasesReportDTO form) {
		RestTemplate rt = new RestTemplate();
		String uri = env.getProperty(RSPAIDCASESREPORT_SEARCH_URL_KEY);
		uri = form.getPaidCasesSearch().appendParameters(uri);
		ResponseEntity<PaidCasesReportDTO> response = rt.getForEntity(uri, PaidCasesReportDTO.class);
		form.setPaidCasesResult(response.getBody().getPaidCasesResult());
		return form;
	}

}
