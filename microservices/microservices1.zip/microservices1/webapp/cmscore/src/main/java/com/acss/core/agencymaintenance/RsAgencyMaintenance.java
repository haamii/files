package com.acss.core.agencymaintenance;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class RsAgencyMaintenance implements AgencyMaintenanceService{
	
	@Autowired
	private Environment env;
	
	private final static String RSAGENCY_SEARCH_URL_KEY = "rs.agency.search.url";
	private final static String RSAGENCY_ADD_URL_KEY = "rs.agency.add.url";
	private final static String RSAGENCY_UPDATE_URL_KEY = "rs.agency.update.url";
	private final static String RSAGENCY_DELETE_URL_KEY = "rs.agency.delete.url";
	
	private final static String SCREENID_SAVE_KEY = "view.agencyModification.id";
	private final static String SCREENID_MODIFY_KEY = "view.agencyModification.id";

	/**
	 * Gets the list of agencies from a restful end point
	 * @param agencyMaintenanceDTO
	 * @return List<AgencyResultModel>
	 */
	@Override
	public List<AgencyResultModel> getAgencies(AgencyMaintenanceDTO agencyMaintenanceDTO){
		List<AgencyResultModel> agencies = new ArrayList<>();
		
		String uri = env.getProperty(RSAGENCY_SEARCH_URL_KEY);
		
		RestTemplate rt = new RestTemplate();
		uri = agencyMaintenanceDTO.appendParameters(uri);
		
		ResponseEntity<AgencyResultModel[]> response = rt.getForEntity(uri, AgencyResultModel[].class);
		agencies = Arrays.asList(response.getBody());	
		
		return agencies;
	}
	
	@Override
	public void addAgency(AgencyResultModel agencyResultModel, Principal principal) {
		
		String uri = env.getProperty(RSAGENCY_ADD_URL_KEY);		
		RestTemplate rt = new RestTemplate();
		agencyResultModel.prepareForCreate(principal.getName(),env.getProperty(SCREENID_SAVE_KEY));		
		rt.postForEntity(uri,agencyResultModel,AgencyResultModel.class);
	}

	@Override
	public void agencyUpdate(AgencyResultModel agencyResultModel, Principal principal) {
		// TODO Auto-generated method stub
		String uri = env.getProperty(RSAGENCY_UPDATE_URL_KEY);		
		RestTemplate rt = new RestTemplate();
		agencyResultModel.prepareForUpdate(principal.getName(),env.getProperty(SCREENID_MODIFY_KEY));		
		rt.postForEntity(uri,agencyResultModel,AgencyResultModel.class);
		
	}
	@Override
	public boolean isAgencyDeleted(AgencyResultModel agencyResultModel, Principal principal) {
		// TODO Auto-generated method stub
		String uri = env.getProperty(RSAGENCY_DELETE_URL_KEY);		
		RestTemplate rt = new RestTemplate();
		agencyResultModel.prepareForUpdate(principal.getName(),env.getProperty(SCREENID_MODIFY_KEY));		
		ResponseEntity<AgencyResultModel> response = rt.postForEntity(uri,agencyResultModel,AgencyResultModel.class);
		
		if(HttpStatus.FOUND == response.getStatusCode()){
			return true;
		}else{
			return false;
		}
		
	}
}
