package com.acss.core.usermaintenance;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.acss.kaizen.jooq.poc.account.Account;

@RestController
public class InternalUserRestController {
	
	@Autowired
	private UserMaintenanceService userService;
	
	@RequestMapping(value="user", method = RequestMethod.GET)
	public List<Account> user(){
		List<Account> users = userService.findHPSUsers();
		return users;	
	}

}
