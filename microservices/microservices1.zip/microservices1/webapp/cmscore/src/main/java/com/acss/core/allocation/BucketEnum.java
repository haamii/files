/**
 * 
 */
package com.acss.core.allocation;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import com.acss.core.staffmaintenance.PositionType;

/**
 * @author cvicente
 *
 */
public enum BucketEnum {
	 D0(0,"D0"),
	 D1(1, "D1"),
	 D2(2, "D2"),
	 D3(3, "D3"),
	 D4(4, "D4"),
	 D5(5, "D5"),
	 D6_AND_UP(6,"D6 AND UP");
	
	private int code;
	private String value;
	
	public final static String MODEL_ATTRIB_KEY = "bucketList";
	
	private final static class BootstrapSingleton {
		public static final Map<String, BucketEnum> lookupByValue = new HashMap<String, BucketEnum>();
		public static final Map<BigDecimal, BucketEnum> lookupByCode = new HashMap<BigDecimal, BucketEnum>();
	}
	
	BucketEnum(int code, String value) {
		this.code = code;
		this.value = value;
		BootstrapSingleton.lookupByValue.put(value, this);
		BootstrapSingleton.lookupByCode.put(new BigDecimal(code), this);
	}
	
	public int getCode() {
		return code;
	}

	public String getValue() {
		return value;
	}
	
	 public static String getEnumByString(String code){
        for(BucketEnum e : BucketEnum.values()){
            if(code.equals(e.getCode())) return e.value;
        }
        return null;
    }
	

}
