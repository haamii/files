/**
 * 
 */
package com.acss.core.ecsachpdcreject;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.acss.core.account.UserConfigurable;
import com.acss.core.model.allocation.AllocationReportModel;

/**
 * @author jpetronio
 *
 */
@Component
public class RsEcsAchPdcReject implements EcsAchPdcRejectService {
	@Autowired
	private Environment env;
	
	
	private static final String ROOT = "uploadPath";
	private static final String RSREJECT_GETFILENAME_URL_KEY = "rs.reject.getFilename.url";
	private static final String RSREJECT_READFILE_URL_KEY= "rs.reject.readFile.url";
	private static final String RSREJECT_GETUPLOADSUMMARY_URL_KEY = "rs.reject.getUploadSummary.url";
	private static final String VIEW_ECSACHPDCREJECT_ID =  "view.ecsAchPdcReject.id";

	@Override
	public String validateFilename(String filename) {
		String uri = env.getProperty(RSREJECT_GETFILENAME_URL_KEY) + "fileName=" + filename;
		RestTemplate rt = new RestTemplate();		
		ResponseEntity<String> response=rt.getForEntity(uri, String.class);	
		return response.getBody();
	}
		
	@Override
	public List<PaymentRejectDTO> doReadFile(String filename) {
		
		UserConfigurable us = (UserConfigurable) SecurityContextHolder.getContext().getAuthentication().getPrincipal();         
		RestTemplate rt = new RestTemplate();
		String uri = env.getProperty(RSREJECT_READFILE_URL_KEY) + "fileName=" + filename + "&path=" + env.getProperty(ROOT) + "&userCode=" + us.getUsername()  + "&ID=" + env.getProperty(VIEW_ECSACHPDCREJECT_ID);
		ResponseEntity <PaymentRejectDTO[]> response=rt.getForEntity(uri, PaymentRejectDTO[].class);	
		List<PaymentRejectDTO> uploadSummary = Arrays.asList(response.getBody());
		return uploadSummary;
		//rt.postForEntity(uri,null,String.class);
	}
	
	@Override
	public List<PaymentRejectDTO> populateUploadSummary(String fileName) {
		String uri = env.getProperty(RSREJECT_GETUPLOADSUMMARY_URL_KEY ) + "fileName=" + fileName;
		RestTemplate rt = new RestTemplate();
		ResponseEntity<PaymentRejectDTO[]> response = rt.getForEntity(uri, PaymentRejectDTO[].class);
		List<PaymentRejectDTO> uploadSummaryDetails = Arrays.asList(response.getBody());
		return uploadSummaryDetails;
	}

}
