package com.acss.core.reallocation;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.acss.core.model.reallocation.CollectorDTO;
import com.acss.core.model.reallocation.ReallocationResultDetailsDTO;
import com.acss.core.model.reallocation.ReallocationSaveDTO;
import com.acss.core.model.reallocation.ReallocationSearchDTO;
import com.acss.core.model.reallocation.ReallocationSearchModel;

@Component
public class RsReallocation implements ReallocationService{
	
	@Autowired
	private Environment env;
	
	private final static String RSREALLOCATION_CRITERIA_URL_KEY = "rs.reallocation.criteria.url";
	private final static String RSREALLOCATION_SEARCH_URL_KEY = "rs.reallocation.search.url";
	private final static String RSREALLOCATION_COLLECTOR_URL_KEY = "rs.reallocation.collector.url";
	private final static String RSREALLOCATION_SAVE_URL_KEY = "rs.reallocation.save.url";
	
	private final static String SCREENID_SAVE_KEY = "view.reallocation.id";

	@Override
	public void populateAccountHolder(ReallocationResultDetailsDTO reallocationDTO) {
		
		String uri = env.getProperty(RSREALLOCATION_CRITERIA_URL_KEY);
		
		RestTemplate rt = new RestTemplate();	
		
		ResponseEntity<CollectorDTO[]> response = rt.getForEntity(uri, CollectorDTO[].class);
		List<CollectorDTO> criteria =  Arrays.asList(response.getBody());
		
		reallocationDTO.setAccountHolderIds(criteria);
		
	}

	@Override
	public void populateSearchResult(
			ReallocationResultDetailsDTO reallocationDTO,
			ReallocationSearchDTO reallocationSearchForm) {
		
		ReallocationSearchDTO searchCriteria = new ReallocationSearchDTO(reallocationSearchForm.getCustomerCode(), 
				reallocationSearchForm.getCustomerName(), reallocationSearchForm.getResidenceContact(),
				reallocationSearchForm.getMobilePhoneNo(), reallocationSearchForm.getDateOfBirth(),
				reallocationSearchForm.getIdCardNo(), reallocationSearchForm.getExpressCardNo(),
				reallocationSearchForm.getAgreementNo(), reallocationSearchForm.getApplicationNo(),
				reallocationSearchForm.getAccountHolderId());
		
		String uri = env.getProperty(RSREALLOCATION_SEARCH_URL_KEY);
		
		uri = searchCriteria.appendParameters(uri);
		
		RestTemplate rt = new RestTemplate();	
		
		ResponseEntity<ReallocationSearchModel[]> response = rt.getForEntity(uri, ReallocationSearchModel[].class);
		List<ReallocationSearchModel> searchResult =  Arrays.asList(response.getBody());
		
		reallocationDTO.setSearchResult(searchResult);
		
	}

	@Override
	public void populateReallocateToCollector(ReallocationResultDetailsDTO reallocationDTO) {
	
		String uri = env.getProperty(RSREALLOCATION_COLLECTOR_URL_KEY);
		
		RestTemplate rt = new RestTemplate();	
		
		ResponseEntity<CollectorDTO[]> response = rt.getForEntity(uri, CollectorDTO[].class);
		List<CollectorDTO> collectors =  Arrays.asList(response.getBody());
		
		reallocationDTO.setReallocateToCollector(collectors);
		
		
	}

	@Override
	public void updateReallocation(ReallocationSaveDTO reallocationSaveForm, Principal principal) {
		RestTemplate rt = new RestTemplate();
		
		String uri = env.getProperty(RSREALLOCATION_SAVE_URL_KEY);
		
		ArrayList<String> agreementlist = new ArrayList<String>();
		
		for (int i=0; i < reallocationSaveForm.getAgreementCdList().length; i++){
			agreementlist.add(reallocationSaveForm.getAgreementCdList()[i].substring(0,19));
		}
		
		String reallocateTo = reallocationSaveForm.getReallocateToCollector();
		
		reallocationSaveForm.setReallocateToCollector(reallocateTo.substring(0, reallocateTo.indexOf("|")));
		reallocationSaveForm.setAgreementCdList(agreementlist.toArray(new String[agreementlist.size()]));
		
		reallocationSaveForm.prepareForUpdate(principal.getName(), env.getProperty(SCREENID_SAVE_KEY));
		rt.postForEntity(uri, reallocationSaveForm, ReallocationSaveDTO.class);
		
	}

}
