package com.acss.core.deskcontact;

import java.util.List;

import com.acss.core.account.UserConfigurable;
import com.acss.core.model.deskcontact.AccountCollectionModel;
import com.acss.core.model.deskcontact.CollectionResultModel;
import com.acss.core.model.deskcontact.ContactResultModel;
import com.acss.core.model.deskcontact.ContactResultSaveDTO;
import com.acss.core.model.deskcontact.CustomerInfoModel;
import com.acss.core.model.deskcontact.PaymentRejectModel;
import com.acss.core.model.deskcontact.ContactHistoryModel;

public interface DeskContactService {
	
	public void populateCollectionResult(CollectionResultModel collectionResult, UserConfigurable us);
	public List<ContactResultModel> populateContactResult(UserConfigurable us);
	public List<AccountCollectionModel> populateAccountResult(UserConfigurable us);
	public void populateCustomerInfo(CustomerInfoModel custInfo, String agreementCd);
	public void saveContactResult(ContactResultSaveDTO contactResultSaveForm, String userCd);
	public List<PaymentRejectModel> populateRejectResult(String agreementCd);
	public List<ContactHistoryModel> populateContactHistory(String agreementCd);
	
}
