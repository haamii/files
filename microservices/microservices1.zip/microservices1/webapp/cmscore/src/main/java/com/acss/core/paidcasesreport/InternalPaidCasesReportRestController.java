/**
 * 
 */
package com.acss.core.paidcasesreport;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.acss.core.model.paidcasesreport.PaidCasesReportDTO;
import com.acss.core.model.paidcasesreport.PaidCasesResultModel;

/**
 * @author jpetronio
 *
 */
@RestController
public class InternalPaidCasesReportRestController {

	@Autowired 
	private PaidCasesReportService service;
	
	@RequestMapping(value="ajax/paidCasesSearch", method = RequestMethod.GET)
	 public List<PaidCasesResultModel> populateResult(@ModelAttribute PaidCasesReportDTO form) {
		//PaidCasesReportDTO paidcasesreportDTO = new PaidCasesReportDTO();
		form = service.populatePaidCasesReport(form);
		return form.getPaidCasesResult();
	}
}