package com.acss.core.deskproductivityreport;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.acss.core.model.deskproductivityreport.DeskProductivityReportModel;
import com.acss.core.model.deskproductivityreport.DeskProductivityReportSearchModel;
/**
 * @author sgalvez
 */
@Component
public class RsDeskProductivityReport implements DeskProductivityReportService{
	
	@Autowired
	private Environment env;
	
	private final static String RSREPORT_DESKPRODUCTIVITY_SEARCH_URL_KEY = "rs.deskProductivityReport.search.url";

	@Override
	public List<DeskProductivityReportModel> populateReport(DeskProductivityReportSearchModel form) {
		String uri = env.getProperty(RSREPORT_DESKPRODUCTIVITY_SEARCH_URL_KEY);
		RestTemplate rt = new RestTemplate();
		uri = form.appendParameters(uri);
		
		ResponseEntity<DeskProductivityReportModel[]> response = rt.getForEntity(uri, DeskProductivityReportModel[].class);
		List<DeskProductivityReportModel> deskProductivityList = Arrays.asList(response.getBody());
		List<DeskProductivityReportModel> listDeskProductivity = new ArrayList<DeskProductivityReportModel>();	
		
		for(DeskProductivityReportModel e: deskProductivityList){
			DeskProductivityReportModel container = new DeskProductivityReportModel();
			container.setSno(e.getSno());
			container.setCallerName(e.getCallerName());
			container.setNoOfCalls(e.getNoOfCalls());
			container.setNoOfContact(e.getNoOfContact());
			container.setPtp(e.getPtp());
			container.setPaid(e.getPaid());
			container.setUpdated(e.getUpdated());
			container.setToBeUpdated(e.getToBeUpdated());
			container.setCb(e.getCb());
			container.setMsg(e.getMsg());
			container.setRtp(e.getRtp());
			container.setPtpAtField(e.getPtpAtField());
			container.setNc(e.getNc());
			container.setRing(e.getRing());
			container.setSo(e.getSo());
			container.setBptp(e.getBptp());
			container.setOther(e.getOther());
			container.setFieldyn(e.getFieldyn());
			listDeskProductivity.add(container);
		}
		
		return listDeskProductivity;
	}
	
}
