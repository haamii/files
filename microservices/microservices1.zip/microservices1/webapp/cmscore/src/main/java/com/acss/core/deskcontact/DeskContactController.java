package com.acss.core.deskcontact;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.acss.core.account.UserConfigurable;
import com.acss.core.model.deskcontact.ActionEnum;
import com.acss.core.model.deskcontact.ChequeStatusEnum;
import com.acss.core.model.deskcontact.CollectionResultModel;
import com.acss.core.model.deskcontact.ContactResultEnum;
import com.acss.core.model.deskcontact.ContactResultSaveDTO;
import com.acss.core.model.deskcontact.CustomerInfoModel;
import com.acss.core.model.deskcontact.ModeOfPaymentEnum;
import com.acss.core.model.deskcontact.PaymentRejectModel;
import com.acss.core.model.deskcontact.ContactHistoryModel;
import com.acss.core.model.deskcontact.SubActionEnum;
import com.acss.core.support.web.MessageHelper;

@Controller
public class DeskContactController {
	
	@Autowired
	private DeskContactService deskContactService;
	
	private static final String DESKCONTACT_ENUM_CONTACTRESULT_KEY = "listContactResult";
	private static final String DESKCONTACT_ENUM_ACTION_KEY = "listAction";
	private static final String DESKCONTACT_ENUM_SUBACTION_KEY = "listSubAction";
	private static final String DESKCONTACT_ENUM_CONTACTTO_KEY = "listContactTo";
	private static final String DESKCONTACT_ENUM_MODEOFPAYMENT_KEY = "listModeOfPayment";
	private static final String DESKCONTACT_ENUM_CHEQUESTATUSE_KEY = "listChequeStatus";
	
	private static final String contactUri = "/contact?";
	private static final String accountUri = "/accountListDeskContact?";
	private UserConfigurable us = null;
	
	@RequestMapping(value = "deskContact")
	public String onLoad(Model model, Principal principal){
		
		us = (UserConfigurable)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		CollectionResultModel collectionResult = new CollectionResultModel();
		deskContactService.populateCollectionResult(collectionResult, us);	
		
		model.addAttribute(DESKCONTACT_ENUM_CONTACTRESULT_KEY,ContactResultEnum.values());
		model.addAttribute(DESKCONTACT_ENUM_ACTION_KEY,ActionEnum.values());
		model.addAttribute(DESKCONTACT_ENUM_SUBACTION_KEY,SubActionEnum.values());
		model.addAttribute(DESKCONTACT_ENUM_CONTACTTO_KEY,ContactToEnum.values());
		model.addAttribute(DESKCONTACT_ENUM_MODEOFPAYMENT_KEY,ModeOfPaymentEnum.values());
		model.addAttribute(DESKCONTACT_ENUM_CHEQUESTATUSE_KEY,ChequeStatusEnum.values());
		
		model.addAttribute(CollectionResultModel.MODEL_ATTRIB_KEY,collectionResult);
		model.addAttribute("contactUrl", contactUri);
		model.addAttribute("accountUrl", accountUri);
		
		return "deskcontact/deskcontact";
	}
	
	@RequestMapping(value = "ajax/deskcontact/customerinfo", method= RequestMethod.POST)
	public String showCustInfo(Model model,
			@RequestParam(value = "agreement", required = true) String agreementCd){
		
		CustomerInfoModel custInfo = new CustomerInfoModel();
		
		deskContactService.populateCustomerInfo(custInfo, agreementCd);
		
		model.addAttribute(CustomerInfoModel.MODEL_ATTRIB_KEY, custInfo);
		
		//for bounce file and ecs/acd/pdc reject
		List<PaymentRejectModel> rejectResult = deskContactService.populateRejectResult(agreementCd);
		model.addAttribute(PaymentRejectModel.MODEL_ATTRIB_KEY, rejectResult);
		
		List<ContactHistoryModel> contactHistoryModels = deskContactService.populateContactHistory(agreementCd);
		model.addAttribute(ContactHistoryModel.MODEL_ATTRIB_KEY, contactHistoryModels);
		
		return "fragments/deskcontact/modal_custInfo";
		
	}
	
	@RequestMapping(value="saveContactResult",method= RequestMethod.POST)
	public String deskContactSave(
			@ModelAttribute ContactResultSaveDTO contactResultSaveForm,
			RedirectAttributes ra){
		
		us = (UserConfigurable)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		deskContactService.saveContactResult(contactResultSaveForm, us.getUsername());
			
		MessageHelper.addSuccessAttribute(ra, "deskcontact.save.success", contactResultSaveForm.getAgreementCd().substring(0,19));
		
		return "redirect:/deskContact";
		
	}
	
}
