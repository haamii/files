package com.acss.core.fieldorder;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Component;

import com.acss.core.model.fieldorder.AllocatedTable;
import com.acss.core.model.fieldorder.FieldOrderDTO;
import com.acss.core.model.fieldorder.UnallocatedTable;
import com.acss.core.model.fieldorder.UserDetails;
import com.acss.core.model.fieldorder.UserNameMCollAccount;
import com.acss.core.model.fieldorder.UserNameMCollAgency;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

@Component
public class FieldOrderUtil {
	public List<UserDetails> bindMCollectionAccountToUserDetails(List<UserNameMCollAccount> users){
		List<UserDetails> listUsers = new ArrayList<UserDetails>();
		for(UserNameMCollAccount mcollaccountdetails:users){
			UserDetails details = new UserDetails();
			details.setUserid(mcollaccountdetails.getUsercd());
			details.setUsername(mcollaccountdetails.getUsername());
			listUsers.add(details);
		}	
		return listUsers;
	}
	
	public List<UserDetails> bindMCollectionAgencyToUserDetails(List<UserNameMCollAgency> users){
		List<UserDetails> listUsers = new ArrayList<UserDetails>();
		for(UserNameMCollAgency mcollagencydetails:users){
			UserDetails details = new UserDetails();
			details.setUserid(mcollagencydetails.getUsercd());
			details.setUsername(mcollagencydetails.getUsername());
			listUsers.add(details);
		}
		return listUsers;
	}
	
	public List<AllocatedTable> parseJsonToModelAllocatedTable(FieldOrderDTO fieldOrderDTO){
		Gson gson = new Gson();
		TypeToken<List<AllocatedTable>> token = new TypeToken<List<AllocatedTable>>(){};
		String data = fieldOrderDTO.getFieldOrderSearch().getJsonallocstorage();
		List<AllocatedTable> allocatedlist = gson.fromJson(data, token.getType());
		return allocatedlist;	
	}
	
	public List<UnallocatedTable> parseJsonToModelUnAllocatedTable(FieldOrderDTO fieldOrderDTO){
		Gson gson = new Gson();
		TypeToken<List<UnallocatedTable>> token = new TypeToken<List<UnallocatedTable>>(){};
		String data = fieldOrderDTO.getFieldOrderSearch().getJsonallocstorage();
		List<UnallocatedTable> unallocatedlist = gson.fromJson(data, token.getType());
		return unallocatedlist;	
	}
	
}
