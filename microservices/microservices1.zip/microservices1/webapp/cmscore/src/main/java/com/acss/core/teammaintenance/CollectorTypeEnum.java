package com.acss.core.teammaintenance;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * @author decalne
 *
 */

public enum CollectorTypeEnum {
	Field_Collector(0,"FIELD COLLECTOR"),
	Agency(1,"AGENCY");
	
	private int code;
	private String value;
	
public final static String MODEL_ATTRIB_KEY = "collectorTypeList";
	
	private final static class BootstrapSingleton {
		public static final Map<String, CollectorTypeEnum> lookupByValue = new HashMap<String, CollectorTypeEnum>();
		public static final Map<BigDecimal, CollectorTypeEnum> lookupByCode = new HashMap<BigDecimal, CollectorTypeEnum>();
	}
	
	CollectorTypeEnum(int code, String value) {
		this.code = code;
		this.value = value;
		BootstrapSingleton.lookupByValue.put(value, this);
		BootstrapSingleton.lookupByCode.put(new BigDecimal(code), this);
	}
	
	public int getCode() {
		return code;
	}

	public String getValue() {
		return value;
	}
	
	 public static String getEnumByString(String code){
        for(CollectorTypeEnum e : CollectorTypeEnum.values()){
            if(code.equals(e.getCode())) return e.value;
        }
        return null;
    }
}
