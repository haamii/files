package com.acss.core.deskproductivityreport;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.acss.core.model.deskproductivityreport.DeskProductivityReportModel;
import com.acss.core.model.deskproductivityreport.DeskProductivityReportSearchModel;
/**
 * @author sgalvez
 */
@RestController
public class InternalDeskProductivityReportRestController {

	@Autowired
	private DeskProductivityReportService deskProductivityReportService;
	
	@RequestMapping(value="deskProductivityReportSearch", method= RequestMethod.GET)
	public List<DeskProductivityReportModel> getDeskProductivityReport(Model model, 
			@ModelAttribute DeskProductivityReportSearchModel form){
		return deskProductivityReportService.populateReport(form);
	}
	
}
