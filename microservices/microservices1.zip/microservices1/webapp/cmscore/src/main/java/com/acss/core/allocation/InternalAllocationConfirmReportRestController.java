/**
 * 
 */
package com.acss.core.allocation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.acss.core.account.UserConfigurable;
import com.acss.core.model.allocation.AccountAllocationDTO;
import com.acss.core.model.allocation.AllocationCriteriaSearchDTO;
import com.acss.core.model.allocation.AllocationReportModel;
import com.acss.core.model.allocation.AllocationResultDetailsDTO;

/**
 * @author jpetronio
 *
 */
@RestController
public class InternalAllocationConfirmReportRestController {
	@Autowired
	private AllocationConfirmReportService allocationReportService;
	
	@Autowired
	private AllocationService allocationService;

	@RequestMapping(value = "allocationReport", method = RequestMethod.GET)
	public List<AllocationReportModel> getAllocationReport(Model model, String username) {

//		UserConfigurable us = (UserConfigurable) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		
		List<AllocationReportModel> result = allocationReportService.populateAllocationReport(username);

		return result;
	}
	
	@RequestMapping(value = "ajax/allocation/fillalloctable", method = RequestMethod.GET)
	public List<AccountAllocationDTO> fillalloctable(Model model, 
			@ModelAttribute AllocationCriteriaSearchDTO allocationSearchForm) {
		
		if (allocationSearchForm.getArea().equalsIgnoreCase("ALL")) {
			allocationSearchForm.setArea("");
		}
		
		String selected = null;
		String currentCollector = null;
		String function = null;
		AllocationResultDetailsDTO allocationForm = new AllocationResultDetailsDTO();
		
		// get allocation result
		allocationService.getAllocationResult(allocationForm, allocationSearchForm, selected, currentCollector,
				function);
	
		return allocationForm.getAllocate();
	}
	
	@RequestMapping(value = "ajax/allocation/fillalloctablehidden", method = RequestMethod.GET)
	public List<AccountAllocationDTO> fillalloctablehidden(Model model, 
			@ModelAttribute AllocationCriteriaSearchDTO allocationSearchForm) {
		
		if (allocationSearchForm.getArea().equalsIgnoreCase("ALL")) {
			allocationSearchForm.setArea("");
		}
		
		String selected = null;
		String currentCollector = null;
		String function = null;
		AllocationResultDetailsDTO allocationForm = new AllocationResultDetailsDTO();
		
		// get allocation result
//		allocationService.getAllocationResulthidden(allocationForm, allocationSearchForm, selected, currentCollector,
//				function);
	
		return allocationForm.getAllocate();
	}

}
