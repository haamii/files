package com.acss.core.customerpayment;

import java.util.List;

import com.acss.core.model.customerpayment.CustPDCHistory;
import com.acss.core.model.customerpayment.CustomerACHHistory;
import com.acss.core.model.customerpayment.CustomerAgreement;
import com.acss.core.model.customerpayment.CustomerECSHistory;
import com.acss.core.model.customerpayment.CustomerInstallmentNote;
import com.acss.core.model.customerpayment.CustomerInstallmentSummary;
import com.acss.core.model.customerpayment.CustomerPaymentDTO;
import com.acss.core.model.customerpayment.CustomerPaymentDate;
import com.acss.core.model.customerpayment.CustomerPaymentSearch;

public interface ICustmerPaymentService {
	public List<CustomerPaymentSearch> search(CustomerPaymentSearch cps);
	public List<CustomerAgreement> searchAgreements(CustomerPaymentSearch searchData);
	public List<CustomerPaymentDate> searchPaymentDate(CustomerPaymentSearch searchCriteria);
	//public List<CustomerInstallmentNote> searchInstallmentTable(CustomerPaymentSearch searchCriteria);
	public CustomerPaymentDTO searchInstallmentTable(CustomerPaymentSearch searchCriteria);
	public List<CustomerECSHistory> searchEcsTable(CustomerPaymentSearch searchCriteria);
	public List<CustPDCHistory> searchPdcTable(CustomerPaymentSearch searchCriteria);
	public List<CustomerACHHistory> searchAchTable(CustomerPaymentSearch searchCriteria);
	public CustomerInstallmentSummary searchInstallmentDetails(
			CustomerPaymentSearch searchData);
}
