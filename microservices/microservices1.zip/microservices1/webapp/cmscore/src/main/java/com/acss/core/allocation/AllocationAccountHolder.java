package com.acss.core.allocation;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * @author joliveros
 *	singlton class for allocation locking
 *
 */
public class AllocationAccountHolder {
	//singleton class holder cannot be instantiated
	private AllocationAccountHolder(){}
	
	private static Map<String, String> account = new HashMap<String, String>();
	
	public static Map<String, String> getAccount() {
		return account;
	}

	public static void setAccount(Map<String, String> account) {
		AllocationAccountHolder.account = account;
	}
	
	/**
	 * @param key
	 * @param value
	 * add vaue of the global object Map
	 */
	public static void put(String key,String value){
		AllocationAccountHolder.account.put(key, value);
	}

	/**
	 * 
	 * @param key of the map of the account
	 * @return value from Map account
	 */
	public static String get(String key){
		return AllocationAccountHolder.account.get(key);
	}
	
	/**
	 * remove item from the global map
	 */
	public static void remove(String key){
		AllocationAccountHolder.account.remove(key);
	}
}
