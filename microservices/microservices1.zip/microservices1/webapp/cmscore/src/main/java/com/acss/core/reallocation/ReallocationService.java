package com.acss.core.reallocation;

import java.security.Principal;

import com.acss.core.model.reallocation.ReallocationResultDetailsDTO;
import com.acss.core.model.reallocation.ReallocationSaveDTO;
import com.acss.core.model.reallocation.ReallocationSearchDTO;


public interface ReallocationService {
	
	public void populateAccountHolder(ReallocationResultDetailsDTO reallocationDTO);
	public void populateSearchResult(ReallocationResultDetailsDTO reallocationDTO, ReallocationSearchDTO reallocationSearchForm);
	public void populateReallocateToCollector(ReallocationResultDetailsDTO reallocationDTO);
	public void updateReallocation(ReallocationSaveDTO reallocationSaveForm, Principal principal);

}
