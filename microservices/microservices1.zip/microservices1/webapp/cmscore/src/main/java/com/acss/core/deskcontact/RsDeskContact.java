package com.acss.core.deskcontact;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.acss.core.account.UserConfigurable;
import com.acss.core.model.deskcontact.AccountCollectionModel;
import com.acss.core.model.deskcontact.CollectionResultModel;
import com.acss.core.model.deskcontact.ContactHistoryModel;
import com.acss.core.model.deskcontact.ContactResultEnum;
import com.acss.core.model.deskcontact.ContactResultModel;
import com.acss.core.model.deskcontact.ContactResultSaveDTO;
import com.acss.core.model.deskcontact.CustomerInfoModel;
import com.acss.core.model.deskcontact.PaymentRejectModel;

@Component
public class RsDeskContact implements DeskContactService{
	
	@Autowired
	private Environment env;
	
	private final static String RSDESKCONTACT_COLLECTION_URL_KEY = "rs.deskcontact.collection.url";
	private final static String RSDESKCONTACT_CUSTINFO_URL_KEY = "rs.utils.customerinfo.url";
	private final static String RSDESKCONTACT_SAVE_URL_KEY = "rs.deskcontact.save.url";
	private final static String RSDESKCONTACT_CONTACT_URL_KEY = "rs.deskcontact.contact.url";
	private final static String RSDESKCONTACT_ACCOUNT_URL_KEY = "rs.deskcontact.account.url";
	private final static String RSDESKCONTACT_PAYMENTREJECT_URL_KEY = "rs.utils.paymentreject.url";
	private final static String RSDESKCONTACT_CONTACTHISTORY_URL_KEY = "rs.utils.contacthistory.url";
	
	private final static String SCREENID_SAVE_KEY = "view.deskContact.id";

	@Override
	public void populateCollectionResult(CollectionResultModel collectionResult, UserConfigurable us) {
		
		String uri = env.getProperty(RSDESKCONTACT_COLLECTION_URL_KEY);
		uri = uri + "userCd=" + us.getUsername() + "&role=" + getRole(us);
		
		RestTemplate rt = new RestTemplate();	
		
		ResponseEntity<CollectionResultModel> response = rt.getForEntity(uri, CollectionResultModel.class);
		collectionResult.setBeginAccount(response.getBody().getBeginAccount());
		collectionResult.setBeginBillAmount(response.getBody().getBeginBillAmount());
		collectionResult.setBeginOs(response.getBody().getBeginOs());
		collectionResult.setResultAccount(response.getBody().getResultAccount());
		collectionResult.setResultBillAmount(response.getBody().getResultBillAmount());
		collectionResult.setResultOs(response.getBody().getResultOs());
	}
	
	@Override
	public List<ContactResultModel> populateContactResult(UserConfigurable us) {

		String uri = env.getProperty(RSDESKCONTACT_CONTACT_URL_KEY);
		uri = uri + "userCd=" + us.getUsername() + "&role=" + getRole(us);
		
		RestTemplate rt = new RestTemplate();
		
		ResponseEntity<ContactResultModel[]> response = rt.getForEntity(uri, ContactResultModel[].class);
		List<ContactResultModel> contactResultModel = Arrays.asList(response.getBody());
		return contactResultModel;
	}
	
	@Override
	public List<AccountCollectionModel> populateAccountResult(UserConfigurable us) {

		String uri = env.getProperty(RSDESKCONTACT_ACCOUNT_URL_KEY);
		uri = uri + "userCd=" + us.getUsername() + "&role=" + getRole(us);
		
		RestTemplate rt = new RestTemplate();
		
		ResponseEntity<AccountCollectionModel[]> response = rt.getForEntity(uri, AccountCollectionModel[].class);
		List<AccountCollectionModel> accountResultModel = Arrays.asList(response.getBody());
		return accountResultModel;
	}
	
	@Override
	public void populateCustomerInfo(CustomerInfoModel custInfo, String agreementCd) {
		
		String uri = env.getProperty(RSDESKCONTACT_CUSTINFO_URL_KEY);
		uri = uri + "agreementCd=" + agreementCd;
		
		RestTemplate rt = new RestTemplate();			
		
		ResponseEntity<CustomerInfoModel> response = rt.getForEntity(uri, CustomerInfoModel.class);
//		custInfo = response.getBody();
		custInfo.setAccount(response.getBody().getAccount());
		custInfo.setType(response.getBody().getType());
		custInfo.setBucketBom(response.getBody().getBucketBom());
		custInfo.setContactResult(response.getBody().getContactResult());
		custInfo.setCreDate(response.getBody().getCreDate());
		custInfo.setCreTime(response.getBody().getCreTime());
		custInfo.setCustomerCd(response.getBody().getCustomerCd());
		custInfo.setDelayStatus(response.getBody().getDelayStatus());
		custInfo.setFollowUpDate(response.getBody().getFollowUpDate());
		custInfo.setLastAccount(response.getBody().getLastAccount());
		custInfo.setName(response.getBody().getName());
		custInfo.setTotalOS(response.getBody().getTotalOS());
		custInfo.setTotalPay(response.getBody().getTotalPay());
		custInfo.setAction(response.getBody().getAction());
		custInfo.setFollowUpDateTo(response.getBody().getFollowUpDateTo());
		
		//reference details
		custInfo.setName1(response.getBody().getName1());
		custInfo.setName2(response.getBody().getName2());
		custInfo.setMobileNo1(response.getBody().getMobileNo1());
		custInfo.setMobileNo2(response.getBody().getMobileNo2());
		custInfo.setHomeTel1(response.getBody().getHomeTel1());
		custInfo.setHomeTel2(response.getBody().getHomeTel2());
		custInfo.setCorpTel1(response.getBody().getCorpTel1());
		
	}

	@Override
	public void saveContactResult(ContactResultSaveDTO contactResultSaveForm, String userCd) {
		
		String uri = env.getProperty(RSDESKCONTACT_SAVE_URL_KEY);		
		RestTemplate rt = new RestTemplate();	
		contactResultSaveForm.prepareForCreate(userCd, env.getProperty(SCREENID_SAVE_KEY));
		rt.postForEntity(uri, contactResultSaveForm, ContactResultSaveDTO.class);
	}
	
	private String getRole(UserConfigurable us){
		Object[] arrAuth = us.getAuthorities().toArray(); 
		return arrAuth[0].toString();
	}

	@Override
	public List<PaymentRejectModel> populateRejectResult(String agreementCd) {
		
		String uri = env.getProperty(RSDESKCONTACT_PAYMENTREJECT_URL_KEY);
		uri = uri + "agreementCd=" + agreementCd;
		
		RestTemplate rt = new RestTemplate();
		
		ResponseEntity<PaymentRejectModel[]> response = rt.getForEntity(uri, PaymentRejectModel[].class);
		List<PaymentRejectModel> rejectResultModel = Arrays.asList(response.getBody());
		return rejectResultModel;
	}

	@Override
	public List<ContactHistoryModel> populateContactHistory(String agreementCd) {
		String uri = env.getProperty(RSDESKCONTACT_CONTACTHISTORY_URL_KEY);
		uri = uri + "agreementCd=" + agreementCd;
		
		RestTemplate rt = new RestTemplate();
		
		ResponseEntity<ContactHistoryModel[]> response = rt.getForEntity(uri, ContactHistoryModel[].class);
		List<ContactHistoryModel> contactHistoryModel = Arrays.asList(response.getBody());
		
		for (ContactHistoryModel contact : contactHistoryModel) {
			if (contact.getContactResult() != null && 
					!contact.getContactResult().isEmpty()) {
				contact.setContactResult(ContactResultEnum.getEnumNameByCode(contact.getContactResult()));
			}
		}
		
//		Boolean isEqual = false;
//		ContactResultEnum[] contact = ContactResultEnum.values();
//		for (ContactResultEnum contactEnum : contact) {
//           if (contactEnum.name().equals(aName.toUpperCase())) {
//        	   isEqual=true;
//           } 
//	    }
		
		return contactHistoryModel;

	}
	
	

}
