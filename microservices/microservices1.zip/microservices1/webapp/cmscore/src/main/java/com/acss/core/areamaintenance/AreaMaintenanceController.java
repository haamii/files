package com.acss.core.areamaintenance;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.acss.core.model.areamaintenance.AreaDetails;
import com.acss.core.model.areamaintenance.AreaDetailsJsonMapper;
import com.acss.core.model.areamaintenance.AreaMaintenanceDTO;
import com.acss.core.model.fieldorder.UnallocatedTable;
import com.acss.core.support.web.MessageHelper;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;


@Controller
public class AreaMaintenanceController {
	
	private static final String AREASEARCH_MODEL_ATTRIB_KEY = "areaMaintenanceForm";
	private static final String uri = "/areas?";
	private static final String uriSummary = "/areasummary?";
	private static final String uriZipCode = "/zipcode?";
	
	private final static String MESSAGE_SEARCH_NOTASSIGNED_KEY = "delete.info.when.selected.notassigned";
	private final static String MESSAGE_SEARCH_NOCRITERIA_KEY = "delete.info.when.no.criteria";
	private final static String MESSAGE_SEARCH_NOAREA_KEY = "delete.info.when.no.selected.area";
	
	@Autowired
	private AreaMaintenanceService areaService;
	
	@Autowired
	private Environment env;
	
	/**
	 * On Load
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "areaMaintenance")
	public String showAreaMaintenance(@ModelAttribute AreaMaintenanceDTO existingForm, 
			Model model, @RequestParam(value = "action", required = false) String action,
			@RequestParam(value="selectedPostId", required=false) String selectedPostId){
		
		if(model.containsAttribute(AREASEARCH_MODEL_ATTRIB_KEY) || (null != action && action.equals("delete"))){

			String areaDetail = existingForm.getAreaCriteria().appendParameters(uri);
			model.addAttribute("searchUrl", areaDetail);
		
			
		}else{
			AreaMaintenanceDTO areaMaintenance = new AreaMaintenanceDTO();
			areaService.populateBranchListForArea(areaMaintenance);
			areaMaintenance.setJsonallocstorage("");
			model.addAttribute(AREASEARCH_MODEL_ATTRIB_KEY,areaMaintenance);
		}
		
		return "areamaintenance/areamaintenance";
	}
	
	/**
	 * Add Area 
	 * 
	 * @param existingForm
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "areaMaintenance",params = {"addArea"},method= RequestMethod.POST)
	public String addArea(@ModelAttribute AreaMaintenanceDTO existingForm,Model model, RedirectAttributes ra
			,Principal principal){
		
		if(model.containsAttribute(AREASEARCH_MODEL_ATTRIB_KEY) || existingForm!=null){
			areaService.populateBranchListForArea(existingForm);
			model.addAttribute("searchUrl", existingForm.getAreaCriteria().appendParameters(uri));
			model.addAttribute(AREASEARCH_MODEL_ATTRIB_KEY,existingForm);
			
			List<AreaDetailsJsonMapper> checkedArea = parseJsonToModel(existingForm);
			for(AreaDetailsJsonMapper a : checkedArea){
				AreaDetails area = new AreaDetails();
				area.setBranchnm(existingForm.getAreaDetail().getBranchnm());
				area.setArea(existingForm.getAreaDetail().getArea());
				area.setPostid(a.getPostId());
				area.setPostcode(a.getPostCode());
				area.setAreanm(a.getAreaNm());
				area.setCitynm(a.getCityNm());
				areaService.addArea(area, principal);
			}		
		}else{
			AreaMaintenanceDTO areaMaintenance = new AreaMaintenanceDTO();
			areaService.populateBranchListForArea(areaMaintenance);
			model.addAttribute(AREASEARCH_MODEL_ATTRIB_KEY,areaMaintenance);
		}
		MessageHelper.addSuccessAttribute(ra, "area.add.success");
		return "redirect:/areaMaintenance";
	}
	
	/**
	 * Add Area 
	 * 
	 * @param existingForm
	 * @param model
	 * @return
	 *
	@RequestMapping(value = "areaMaintenance",params = {"deleteArea"},method= RequestMethod.POST)
	public String deleteArea(@ModelAttribute AreaMaintenanceDTO existingForm,Model model,RedirectAttributes ra){
		
		if(model.containsAttribute(AREASEARCH_MODEL_ATTRIB_KEY) || existingForm!=null){
			areaService.populateBranchList(existingForm);
			model.addAttribute("searchUrl", existingForm.getAreaCriteria().appendParameters(uri));
			model.addAttribute(AREASEARCH_MODEL_ATTRIB_KEY,existingForm);
			areaService.addArea(existingForm.getAreaDetail());
			
		}else{
			AreaMaintenanceDTO areaMaintenance = new AreaMaintenanceDTO();
			areaService.populateBranchList(areaMaintenance);
			model.addAttribute(AREASEARCH_MODEL_ATTRIB_KEY,areaMaintenance);
		}
		MessageHelper.addSuccessAttribute(ra, "area.add.success");
		return "redirect:/areaMaintenance";
	}*/
	
	
	
	
	/**
	 * List Area Maintenance
	 * 
	 * @param existingForm
	 * @param model
	 * @return
	 *
	@RequestMapping(value = "areaMaintenance",params = {""}, method= RequestMethod.POST)
	public String showAreaMaintenance(@ModelAttribute AreaMaintenanceDTO existingForm,Model model){
		
		if(model.containsAttribute(AREASEARCH_MODEL_ATTRIB_KEY) || existingForm!=null){
			areaService.populateBranchList(existingForm);
			model.addAttribute("searchUrl", existingForm.getAreaCriteria().appendParameters(uri));
			model.addAttribute("areaSummaryUrl", existingForm.getAreaCriteria().appendParameters(uriSummary));
			model.addAttribute(AREASEARCH_MODEL_ATTRIB_KEY,existingForm);
		}else{
			AreaMaintenanceDTO areaMaintenance = new AreaMaintenanceDTO();
			areaService.populateBranchList(areaMaintenance);
			model.addAttribute(AREASEARCH_MODEL_ATTRIB_KEY,areaMaintenance);
		}
		
		return "areamaintenance/areamaintenance";
	}*/

	
	@RequestMapping(value = "areaMaintenance",params = {"deleteArea"},method= RequestMethod.POST)
	public String deleteArea(@ModelAttribute AreaMaintenanceDTO existingForm,Model model,RedirectAttributes ra,
			@RequestParam(value="selectedPostId", required=false) String selectedPostId,
			@RequestParam(value = "action", required = false) String action){
		
		
		if(model.containsAttribute(AREASEARCH_MODEL_ATTRIB_KEY) || existingForm!=null){
			areaService.populateBranchListForArea(existingForm);
			model.addAttribute("searchUrl", existingForm.getAreaCriteria().appendParameters(uri));
			model.addAttribute(AREASEARCH_MODEL_ATTRIB_KEY,existingForm);
			model.addAttribute("action", action);
			if (null != selectedPostId && !selectedPostId.isEmpty()){
				areaService.deleteArea(selectedPostId);
				MessageHelper.addSuccessAttribute(ra, "area.delete.success");
			}else{
				MessageHelper.addInfoAttribute(ra, "delete.info.when.selected");
			}
			
		}else{
			AreaMaintenanceDTO areaMaintenance = new AreaMaintenanceDTO();
			areaService.populateBranchListForArea(areaMaintenance);
			model.addAttribute(AREASEARCH_MODEL_ATTRIB_KEY,areaMaintenance);
		}
		
	
	
		/*
		for (int i=0; i < areaMaintenance.getAreaDetail().getPostid().length(); i++){
			agreementlist.add(reallocationSaveForm.getAgreementCdList()[i].substring(0,19));
		}*/

		return "redirect:/areaMaintenance";
	}
	

	@RequestMapping(value="ajax/area/summary",method= RequestMethod.POST)
	public String getAreaSummary(@ModelAttribute AreaMaintenanceDTO areaMaintenance,Model model,
			@RequestParam(value="selectedPostId", required=false) String selectedPostId,
			@RequestParam(value="action", required=false) String action){
		areaService.populateBranchListForArea(areaMaintenance);
		
		/*
		areaMaintenance.getAreaSummary().clear();
		String currentSelection = areaMaintenance.getAreaCriteria().getSelectedBranch();
		
		RestTemplate rt = new RestTemplate();
		String uri = "http://localhost:18082/areasummary?branchName="+currentSelection;
		
		ResponseEntity<AreaMaintenanceModel[]> response = rt.getForEntity(uri, AreaMaintenanceModel[].class);
		List<AreaMaintenanceModel> areaSummary =  Arrays.asList(response.getBody());
		
		for(AreaMaintenanceModel areastat: areaSummary){
			areaMaintenance.getAreaSummary().add(mapper.map(areastat, AreaAssignment.class));
		}*/

		model.addAttribute(AREASEARCH_MODEL_ATTRIB_KEY,areaMaintenance);
		String areaDetail = areaMaintenance.getAreaCriteria().appendParameters(uriSummary);
		model.addAttribute("areaSummaryUrl", areaDetail);
		
		
		return "fragments/area/_summary";
	}
	
	@RequestMapping(value = "ajax/area/detail")
	public String searchArea(@ModelAttribute AreaMaintenanceDTO areaMaintenance, Model model, RedirectAttributes ra,
			@RequestParam(value="action", required=false) String action, @RequestParam(value="selectedPostId", required=false) String selectedPostId){
		
		areaService.populateBranchListForArea(areaMaintenance);
		//retain the search parameter
		model.addAttribute(AREASEARCH_MODEL_ATTRIB_KEY,areaMaintenance);
		String areaDetail = areaMaintenance.getAreaCriteria().appendParameters(uri);
		model.addAttribute("searchUrl", areaDetail);
		

		//MessageHelper.addInfoAttribute(ra, "delete.info.when.selected");
		return "fragments/area/_areadetail";
	}
	
	
	
	
	@RequestMapping(value = "ajax/area/info/alert")
	public String showDeleteMessage(@ModelAttribute AreaMaintenanceDTO areaMaintenance, Model model, RedirectAttributes ra,
			@RequestParam(value="action", required=false) String action, @RequestParam(value="selectedPostId", required=false) String selectedPostId,
			@RequestParam(value="group", required=false) String group,
			@RequestParam(value="checkBoxCount", required=false) String checkBoxCount
			){
		
		if (null != action && action.equals("delete")){
			
			
			if(group.equals("-")){
				model.addAttribute("messageAreaDelete", env.getProperty(MESSAGE_SEARCH_NOTASSIGNED_KEY));
			}else if (group.isEmpty()){
				if(null != selectedPostId && selectedPostId.isEmpty() && !checkBoxCount.equals("1")){
					model.addAttribute("messageAreaDelete", env.getProperty(MESSAGE_SEARCH_NOAREA_KEY));
				}else{
					model.addAttribute("messageAreaDelete", env.getProperty(MESSAGE_SEARCH_NOCRITERIA_KEY));
				}
				
			}
		}
		
		//MessageHelper.addInfoAttribute(ra, "delete.info.when.selected");
		return "fragments/alert_areadelete";
	}
	

	@RequestMapping(value = "ajax/area/zipcode")
	public String seachZipCode(@ModelAttribute AreaMaintenanceDTO areaMaintenance,Model model){
	
		/*
		areaService.populateBranchList(areaMaintenance);
		model.addAttribute(AREASEARCH_MODEL_ATTRIB_KEY,areaMaintenance);
		
		
		String uri = "http://localhost:18085/util/zipcodes?";
		
		AreaMaintenanceSearchDTO searchCriteria = new AreaMaintenanceSearchDTO(areaMaintenance.getAreaCriteria().getSelectedBranch(), "");
		uri = searchCriteria.appendParameters(uri);
		
		RestTemplate template = new RestTemplate();
		//ZipCode[] zipCodes = template.getForObject(uri, ZipCode[].class);
		//return Arrays.asList(zipCodes);	
		
		
		ResponseEntity<ZipCode[]> response = template.getForEntity(uri, ZipCode[].class);
		List<ZipCode> zipcodes =  Arrays.asList(response.getBody());
		
		//String zipCode = areaMaintenance.getAreaCriteria().appendParameters(uriZipCode);
		model.addAttribute("zipcode", zipcodes);
		*/
		//areaService.populateBranchList(areaMaintenance);
		//retain the search parameter
		model.addAttribute(AREASEARCH_MODEL_ATTRIB_KEY,areaMaintenance);
		String zipCode = areaMaintenance.getAreaDetail().appendParameters(uriZipCode);
		model.addAttribute("zipcode", zipCode);
		
		return "fragments/area/_zipcodedetail";	
	}
	
	private List<AreaDetailsJsonMapper> parseJsonToModel(AreaMaintenanceDTO existingForm){
		Gson gson = new Gson();
		TypeToken<List<AreaDetailsJsonMapper>> token = new TypeToken<List<AreaDetailsJsonMapper>>(){};
		String data = existingForm.getJsonallocstorage();
		List<AreaDetailsJsonMapper> list = gson.fromJson(data, token.getType());
		return list;	
	}
	
}
