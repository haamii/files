package com.acss.core.allocation;

import java.security.Principal;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.acss.core.account.UserConfigurable;
import com.acss.core.model.CustomerGroupEnum;
import com.acss.core.model.adminallocation.CategoryEnum;
import com.acss.core.model.allocation.AllocationCriteriaSearchDTO;
import com.acss.core.model.allocation.AllocationResultDetailsDTO;
import com.acss.core.model.deskcontact.SubActionEnum;
import com.acss.core.model.fieldorder.FieldOrderDTO;
import com.acss.core.model.fieldorder.FieldOrderStatic;
import com.acss.core.model.fieldorder.UnallocatedTable;
import com.acss.core.support.web.MessageHelper;
import com.google.common.base.Throwables;

@Controller
public class AllocationController {

	@Autowired
	private AllocationService allocationService;
	
	@Autowired
	private InternalAllocationConfirmReportRestController InternalAllocation;

	@Autowired
	private Environment env;

	private final static String MESSAGE_ADD_KEY = "allocation.add.success";
	private final static String MESSAGE_DELETE_KEY = "allocation.delete.success";
	
	private final static String RETURN_MAINPAGE = "allocation/allocation";
	private final static String RETURN_ERRORPAGE = "error/logoutsession";
	
	private final static String SYSADROLE = "SYSTEM_ADMINISTRATOR";
	
	private static final String CATEGORY_ENUM = "listCategory";
	private static final String CUSTOMERGROUP_ENUM = "listCustomerGroup";

	@RequestMapping(value = "allocation")
	public String onLoad(Model model) {
		model.addAttribute(BucketEnum.MODEL_ATTRIB_KEY, BucketEnum.values());
		
		String returnPage = "";
		AllocationResultDetailsDTO alloc = new AllocationResultDetailsDTO();

		// get list of branch
		allocationService.populateBranchAreaList(alloc);
		
		//to do if user is not logged on allocation
		UserConfigurable us = getUser();	
		
		Collection<GrantedAuthority> authorities = us.getAuthorities();
		boolean hasRole = false;
		for(GrantedAuthority auth : authorities){
			hasRole = auth.getAuthority().equals(SYSADROLE);	
			if(hasRole){
				returnPage = RETURN_ERRORPAGE;
				model.addAttribute("errorMessage", "Account "+ us.getAccountname()+" is a SYSTEM ADMINISTRATOR and has no BUCKET");
			}
		}
		
		if(!hasRole){
			if(AllocationAccountHolder.get(us.getBucket().toString()) == null){
				AllocationAccountHolder.put(us.getBucket().toString(), us.getUsername());
					returnPage = RETURN_MAINPAGE;
			}else{
				if(AllocationAccountHolder.get(us.getBucket().toString()).equals(us.getUsername())){
					//do nothing, it means same account is logged in
					returnPage = RETURN_MAINPAGE;
				}else{
					//other user in the same bucket is currently logged in
					returnPage = RETURN_ERRORPAGE;
					model.addAttribute("errorMessage", "Account "+AllocationAccountHolder.get(us.getBucket().toString())+" is already logged at Allocation module for Bucket "+us.getBucket());
				}
			}
		}
		
		//to do if user is not logged on allocation
		model.addAttribute(AllocationCriteriaSearchDTO.MODEL_ATTRIB_KEY, new AllocationCriteriaSearchDTO());
		model.addAttribute(AllocationResultDetailsDTO.MODEL_ATTRIB_KEY, alloc);
		
		model.addAttribute(CATEGORY_ENUM, CategoryEnum.values());
		model.addAttribute(CUSTOMERGROUP_ENUM, CustomerGroupEnum.values());

		return returnPage;
	}
	
	/**
	 * 
	 * FOR DELETING OF SESSION 
	 * @param model
	 * @param allocationSearchForm
	 * @param ra
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "alloc", method = RequestMethod.POST,params ="updunalloc")
	public ModelAndView logoutsession(
			Model model,
			@ModelAttribute AllocationCriteriaSearchDTO allocationSearchForm,
			RedirectAttributes ra){
		
		UserConfigurable us  = getUser();
		AllocationAccountHolder.remove(us.getBucket().toString());
		ModelAndView modelAndView = new ModelAndView("error/logoutsession");
		modelAndView.addObject("succMessage", "Successfully deleted ownership for bucket "+us.getBucket()+" For user "+us.getUsername());
		return modelAndView;
	}
	
	@RequestMapping(value = "alloc", method = RequestMethod.POST)
	public String updateunallocatedacc(
			Model model,
			@ModelAttribute AllocationCriteriaSearchDTO allocationSearchForm,
			RedirectAttributes ra){
	
		boolean isAllocationDone = false;
		
		UserConfigurable us = getUser();

		isAllocationDone = allocationService.allocateAgreements(allocationSearchForm);
		
		//remove authority for the allocation
		if(isAllocationDone){
			AllocationAccountHolder.remove(us.getBucket().toString());
		}
		
		String username = us.getUsername();
		
		Runnable myRunnable = new Runnable(){
			@Override
			public void run() {
				processAllocationReport(model, username); 
			}
		};
		Thread thread = new Thread(myRunnable);
		//thread.start();
		
		MessageHelper.addSuccessAttribute(ra, "view.fieldorder.allocated.update.success");
		return "redirect:/allocation";
	}
	
	public void processAllocationReport(Model model, String username) {
		InternalAllocation.getAllocationReport(model, username);
	}

	/*
	 * serach for number of accounts
	 */
	@RequestMapping(value = "ajax/allocation/searchresultNumberofAccounts", method = RequestMethod.POST)
	public String allocationSearchNumberofAccounts(Model model, @ModelAttribute AllocationCriteriaSearchDTO allocationSearchForm,
			@RequestParam(value = "selected", required = false) String selected,
			@RequestParam(value = "currentCollector", required = false) String currentCollector,
			@RequestParam(value = "function", required = false) String function, RedirectAttributes ra) {

		if (allocationSearchForm.getArea().equalsIgnoreCase("ALL")) {
			allocationSearchForm.setArea("");
		}
		
		AllocationResultDetailsDTO allocationForm = new AllocationResultDetailsDTO();
		
		// get number of accounts
		allocationService.getNumberOfAccounts(allocationForm, allocationSearchForm);

		model.addAttribute(AllocationResultDetailsDTO.MODEL_ATTRIB_KEY, allocationForm);
		
		return "fragments/allocation/_numberofAccounts :: numberofaccounts";

	}
	
	/*
	 * search for selections of collector
	 */
	@RequestMapping(value = "ajax/allocation/searchresultCollectorsUnder", method = RequestMethod.POST)
	public String allocationSearchCollectorsUnder(Model model, @ModelAttribute AllocationCriteriaSearchDTO allocationSearchForm,
			@RequestParam(value = "selected", required = false) String selected,
			@RequestParam(value = "currentCollector", required = false) String currentCollector,
			@RequestParam(value = "function", required = false) String function, RedirectAttributes ra) {

		if (allocationSearchForm.getArea().equalsIgnoreCase("ALL")) {
			allocationSearchForm.setArea("");
		}
		
		AllocationResultDetailsDTO allocationForm = new AllocationResultDetailsDTO();
	
		// get collectors under selected branch
		allocationService.populateCollectors(allocationForm, allocationSearchForm);

		model.addAttribute(AllocationResultDetailsDTO.MODEL_ATTRIB_KEY, allocationForm);

		return "fragments/allocation/_searchresult :: searchresult";

	}

	@RequestMapping(value = "confirm", method = RequestMethod.POST)
	public String allocationConfirm(Model model, @ModelAttribute AllocationCriteriaSearchDTO allocationSearchForm,
			@RequestParam(value = "currentCollector", required = true) String currentCollector, RedirectAttributes ra,
			Principal principal) {

		allocationService.updateAllocation(currentCollector, allocationSearchForm, principal);

		MessageHelper.addSuccessAttribute(ra, "confirm.success");
		return "redirect:/allocationConfirmReport";

	}

	@RequestMapping(value = "ajax/allocation/message", method = RequestMethod.POST)
	public String showMessage(Model model, @RequestParam(value = "function", required = true) String function,
			RedirectAttributes ra) {

		// display message for add and delete collector/s
		if (function.equals("delete"))
			model.addAttribute("messageAddDelete", env.getProperty(MESSAGE_DELETE_KEY));
		else
			model.addAttribute("messageAddDelete", env.getProperty(MESSAGE_ADD_KEY));

		return "fragments/alert_allocation";

	}
	
	/**
	 * method for getting usercredentials
	 * @return userconfig
	 */
	private static UserConfigurable getUser(){
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		return (UserConfigurable) auth.getPrincipal();
	}

}
