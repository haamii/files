package com.acss.core.adminallocation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.acss.core.model.adminallocation.AdminAllocationModel;

@RestController
public class InternalRestControllerAdminAllocation {

	@Autowired
	private AdminAllocationService adminAllocationService;
	
	List<AdminAllocationModel> adminAllocDetails = null;
	
	@RequestMapping(value="/adminAllocationDetails", method = RequestMethod.GET)
	public List<AdminAllocationModel> retrieveAdminAllocDetails() {
		adminAllocDetails = new ArrayList<AdminAllocationModel>();
//		adminAllocDetails = adminAllocationService.retrieveAdminAllocDetails();
		return adminAllocDetails;
	}
	
//	@RequestMapping(value="/adminAllocationDetailsCopy", method = RequestMethod.GET)
//	public List<AdminAllocationModel> retrieveAdminAllocDetailsCopy() {
//		if (adminAllocDetails == null && !adminAllocDetails.isEmpty()) {
//			return adminAllocDetails;
//		} else {
//			adminAllocDetails = new ArrayList<AdminAllocationModel>();
//			adminAllocDetails = adminAllocationService.retrieveAdminAllocDetails();
//			return adminAllocDetails;
//		}
//	}
	
}
