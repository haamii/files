package com.acss.core.areamaintenance;


import java.security.Principal;

import com.acss.core.model.areamaintenance.AreaDetails;
import com.acss.core.model.areamaintenance.AreaMaintenanceDTO;

public interface AreaMaintenanceService {
	
	public void populateBranchList(AreaMaintenanceDTO areaMaintenance);
	public void populateBranchListForArea(AreaMaintenanceDTO areaMaintenance);
	public void addArea(AreaDetails area, Principal principal);
	public void deleteArea(String selectedPostId);
}
