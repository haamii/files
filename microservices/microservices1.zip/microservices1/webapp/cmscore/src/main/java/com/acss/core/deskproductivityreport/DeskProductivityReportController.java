package com.acss.core.deskproductivityreport;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.acss.core.model.deskproductivityreport.DeskProductivityReportSearchModel;
/**
 * @author sgalvez
 */
@Controller
public class DeskProductivityReportController {
	
	@RequestMapping(value="deskProductivityReport")
	public String onLoad(Model model) {
		model.addAttribute(DeskProductivityReportSearchModel.MODEL_ATTRIB_KEY, 
				new DeskProductivityReportSearchModel());
		return "report/deskproductivityreport";
	}
	
}
