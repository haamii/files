package com.acss.core.customerpayment;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.acss.core.model.customerpayment.CustomerAgreement;
import com.acss.core.model.customerpayment.CustomerInstallmentNote;
import com.acss.core.model.customerpayment.CustomerInstallmentSummary;
import com.acss.core.model.customerpayment.CustomerPaymentDTO;
import com.acss.core.model.customerpayment.CustomerPaymentSearch;



@Controller
public class CustomerPaymentController {
	
	@Autowired
	CustomerPaymentService customerPaymentService;
	
	@RequestMapping(value = "customerPayment")
	public String onLoad(Model model){
		
		model.addAttribute(PaymentStatus.MODEL_ATTRIB_KEY,PaymentStatus.values());	
		CustomerPaymentDTO dto = new CustomerPaymentDTO();
		CustomerInstallmentSummary summary = new CustomerInstallmentSummary();
		summary.init();
		dto.setCustomerInstallmentSummary(summary);
		model.addAttribute(CustomerPaymentDTO.MODEL_ATTRIB_KEY, dto);
		
		return "customerpayment/customerPayment";
	}
	
	@RequestMapping(value = "ajax/customerPayment/customerFillAgreements", method = RequestMethod.GET)
	public String fillAgreement(Model model,
			@RequestParam(value = "customercode", required = false) String customercode){
		
		CustomerPaymentDTO dto = new CustomerPaymentDTO();
		CustomerPaymentSearch searchData = new CustomerPaymentSearch();
		searchData.setCustomercode(customercode);
		
		List<CustomerAgreement> list = customerPaymentService.searchAgreements(searchData);

		dto.setCustomerAgreement(list);
		CustomerInstallmentSummary summary = new CustomerInstallmentSummary();
		summary.init();
		dto.setCustomerInstallmentSummary(summary);
		model.addAttribute(CustomerPaymentDTO.MODEL_ATTRIB_KEY, dto);
		
		return "fragments/customerpayment/_agreementModal ::  agreementDetail";
	}
	
	@RequestMapping(value = "ajax/customerPayment/customerFillInstallmentDetails", method = RequestMethod.GET)
	public String fillInstallmentDetails(Model model,
			@RequestParam(value = "agreementcd", required = false) String agreementcd){
		
		CustomerPaymentDTO dto = new CustomerPaymentDTO();
		CustomerPaymentSearch searchData = new CustomerPaymentSearch();
		searchData.setAgreementno(agreementcd);
		CustomerInstallmentSummary cis = customerPaymentService.searchInstallmentDetails(searchData);
		dto.setCustomerInstallmentSummary(cis);
		model.addAttribute(CustomerPaymentDTO.MODEL_ATTRIB_KEY, dto);	
		return "fragments/customerpayment/_installmentSummary :: installmentDetail";
	}
	
}
