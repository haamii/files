package com.acss.core.teammaintenance;

import java.security.Principal;
import java.util.List;

public interface TeamMaintenanceService {
	void populateBranchAreaList(TeamMaintenanceDTO teamMaintenanceDto);
	List<TeamLeader> populateTeamLeader(TeamMaintenanceDTO teamMaintenanceDto);
	void populateCollectorList(TeamMaintenanceDTO teamMaintenanceDto);
	void addTeam(TeamDetails teamDetails, Principal principal);
	List<TeamResultModel> search(TeamMaintenanceDTO teamMaintenanceDTO);
	TeamUpdateDetails populateTeamDetails(Integer teamId);
	void updateTeam(TeamMaintenanceDTO teamMaintenanceDto, Principal principal);
}
