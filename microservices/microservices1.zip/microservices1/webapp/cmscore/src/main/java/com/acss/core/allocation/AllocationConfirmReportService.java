/**
 * 
 */
package com.acss.core.allocation;

import java.util.List;

import com.acss.core.model.allocation.AllocationReportModel;

/**
 * @author jpetronio
 *
 */
public interface AllocationConfirmReportService {
	public List<AllocationReportModel> populateAllocationReport(String accountId);
}
