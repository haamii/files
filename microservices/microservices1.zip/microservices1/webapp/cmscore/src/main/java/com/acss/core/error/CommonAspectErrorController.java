package com.acss.core.error;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.base.Throwables;

@ControllerAdvice
public class CommonAspectErrorController {
	
	private static Logger errorLogger = LoggerFactory.getLogger(CommonAspectErrorController.class);
	
	@ExceptionHandler(DataRetrievalFailureException.class)
	@ResponseBody
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	public ModelAndView handleNotFoundException(Exception e) {
		/**
		 * Do not log this kind of error, 404 will be handled by client.
		 */
		ModelAndView modelAndView = new ModelAndView("error/general");
		modelAndView.addObject("errorMessage", Throwables.getRootCause(e));
//		modelAndView.addObject("detailedErrorMsg",ExceptionUtils.getStackTrace(e));
		return modelAndView;
	}
	
	@ExceptionHandler(DataIntegrityViolationException.class)
	@ResponseBody
	@ResponseStatus(value = HttpStatus.CONFLICT)
	public ModelAndView handleConstraintViolation(Exception e,Object handler) {
		errorLogger.error("ERROR encountered {}", handler, e);
		ModelAndView modelAndView = new ModelAndView("error/general");
		modelAndView.addObject("errorMessage", Throwables.getRootCause(e));
//		modelAndView.addObject("detailedErrorMsg",ExceptionUtils.getStackTrace(e));
	    return modelAndView;
	}
	
	@ExceptionHandler(Exception.class)
	@ResponseBody
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public ModelAndView genericError(Exception e,Object handler) {
		errorLogger.error("ERROR encountered {}", handler, e);
		ModelAndView modelAndView = new ModelAndView("error/general");
		modelAndView.addObject("errorMessage", Throwables.getRootCause(e));
//		modelAndView.addObject("detailedErrorMsg",ExceptionUtils.getStackTrace(e));
	    return modelAndView;
	}
}
