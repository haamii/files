package com.acss.core.adminallocation;

import java.util.List;
import java.util.Map;

import com.acss.core.model.adminallocation.AdminAllocationDTO;
import com.acss.core.model.adminallocation.AdminAllocationModel;
import com.acss.core.model.allocation.AllocationResultDetailsDTO;

public interface AdminAllocationService {

	public List<AdminAllocationModel> retrieveAdminAllocDetails(String branch);
	
	public boolean confirmAdminAllocation(AdminAllocationDTO adminAllocationModel);
	
	public boolean isAdminAlloCompleted(String branch);

	void populateBranchAreaList(AdminAllocationDTO allocationDTO);
	
}
