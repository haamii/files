package com.acss.core.usermaintenance;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.acss.core.support.web.MessageHelper;
import com.acss.kaizen.jooq.poc.account.Account;



@Controller
public class UserMaintenanceController {
	
	private static final String USERSEARCH_MODEL_ATTRIB_KEY = "userMaintenanceForm";
	private static final String uriUser = "/user";
	@Autowired
	private UserMaintenanceService userService;
	
	/**
	 * On Load
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "userMaintenance")
	public String showUserMaintenance(Model model){
	
		Account useraccount = new Account();
		model.addAttribute(USERSEARCH_MODEL_ATTRIB_KEY, useraccount);
		return "usermaintenance/usermaintenance";
	}
	
	
	/**
	 * searchUser - search all user that are not yet registered as collector/supervisor
	 * 
	 * @param existingForm
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "userMaintenance",params = {"addUser"},method= RequestMethod.POST)
	public String searchUser(@ModelAttribute Account userRegistrationForm, Model model, RedirectAttributes ra){
		
		userService.addUser(userRegistrationForm);
		MessageHelper.addSuccessAttribute(ra, "user.add.success");
		
		return "redirect:/userMaintenance";
	}
	
	/**
	 * Add user 
	 * 
	 * @param existingForm
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "ajax/user")
	public String addUser(@ModelAttribute Account userRegistrationForm, Model model, RedirectAttributes ra){
		
		model.addAttribute("users", uriUser);
		return "fragments/user/_userdetail";
	}
	
	
	
}
