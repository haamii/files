/**
 * 
 */
package com.acss.core.staffmaintenance;

import java.util.List;

import com.acss.core.model.allocation.BranchDTO;
import com.acss.core.model.staffmaintenance.StaffMaintenanceSearchModel;
import com.acss.core.model.staffmaintenance.UserAccountModel;

/**
 * @author jarnonobal
 *
 */
public class StaffResultDetailsDTO {
	
	private List<BranchDTO> branches;	
	private String accountCode;
	private String userName;
	private String positionType;
	private List<StaffMaintenanceSearchModel> searchResult;
	private List<UserAccountModel> userList;
	
	
	public final static String MODEL_ATTRIB_KEY = "staffMaintenanceDetail";
	public final static String USER_ACCOUNT_MODEL_ATTRIB_KEY = "branchList";

	/**
	 * @return the branches
	 */
	public List<BranchDTO> getBranches() {
		return branches;
	}

	/**
	 * @param branches the branches to set
	 */
	public void setBranches(List<BranchDTO> branches) {
		this.branches = branches;
	}

	/**
	 * @return the accountCode
	 */
	public String getAccountCode() {
		return accountCode;
	}

	/**
	 * @param accountCode the accountCode to set
	 */
	public void setAccountCode(String accountCode) {
		this.accountCode = accountCode;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
	/**
	 * @return the positionType
	 */
	public String getPositionType() {
		return positionType;
	}

	/**
	 * @param positionType the positionType to set
	 */
	public void setPositionType(String positionType) {
		this.positionType = positionType;
	}

	/**
	 * @return the searchResult
	 */
	public List<StaffMaintenanceSearchModel> getSearchResult() {
		return searchResult;
	}

	/**
	 * @param searchResult the searchResult to set
	 */
	public void setSearchResult(List<StaffMaintenanceSearchModel> searchResult) {
		this.searchResult = searchResult;
	}

	/**
	 * @return the userList
	 */
	public List<UserAccountModel> getUserList() {
		return userList;
	}

	/**
	 * @param userList the userList to set
	 */
	public void setUserList(List<UserAccountModel> userList) {
		this.userList = userList;
	}
	
	
}
