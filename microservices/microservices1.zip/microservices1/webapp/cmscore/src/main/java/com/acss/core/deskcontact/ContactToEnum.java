package com.acss.core.deskcontact;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public enum ContactToEnum {
	HOME(0,"HOME"),
	OFFICE(1, "OFFICE"),
	ALTERNATE_ADD(2, "ALTERNATE ADDRESS"),
	OTHERS(3, "OTHERS");
	
	private int code;
	private String value;
	
	private final static class BootstrapSingleton {
		public static final Map<String, ContactToEnum> lookupByValue = new HashMap<String, ContactToEnum>();
		public static final Map<BigDecimal, ContactToEnum> lookupByCode = new HashMap<BigDecimal, ContactToEnum>();
	}
	
	ContactToEnum(int code, String value) {
		this.code = code;
		this.value = value;
		BootstrapSingleton.lookupByValue.put(value, this);
		BootstrapSingleton.lookupByCode.put(new BigDecimal(code), this);
	}
	
	public int getCode() {
		return code;
	}

	public String getValue() {
		return value;
	}
}
