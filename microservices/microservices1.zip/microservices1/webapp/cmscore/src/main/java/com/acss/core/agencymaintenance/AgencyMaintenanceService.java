package com.acss.core.agencymaintenance;

import java.security.Principal;
import java.util.List;

public interface AgencyMaintenanceService {		
	void addAgency(AgencyResultModel agencyResultModel, Principal principal);
	void agencyUpdate(AgencyResultModel agencyResultModel, Principal principal);
	boolean isAgencyDeleted(AgencyResultModel agencyResultModel, Principal principal);
	List<AgencyResultModel> getAgencies(AgencyMaintenanceDTO agencyMaintenanceDTO);
}
