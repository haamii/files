/*! Customed function for string to cater format functions on scripts. */
String.prototype.format = String.prototype.f = function() {
    var s = this,
        i = arguments.length;

    while (i--) {
        s = s.replace(new RegExp('\\{' + i + '\\}', 'gm'), arguments[i]);
    }
    return s;
};


function addImageFunction(){
	/*! Customed function for dynamic addition of image with image type */
	$("#addLink").click(function () {
	    var id = ($('.additionalImage .row').length + 1).toString();
	    var index = ($('.additionalImage .row').length).toString();
	    
	    $('#additionalImage').append('<h4></h4><div class="row" id="row-image_'+id+'">'
	    		+'<div class="col-md-4 col-xs-6" th:classappend="${#fields.hasErrors(\'additionalImages['+index+'].imageType\')}? \'has-error\'"><div class="input-group svX3">'
	    		+'<label for="inputImageType_'+id+'" class="input-group-addon imagetype-width" id="imageType-addon_'+id+'">Image Type :&nbsp;</label>'
	    		+'<select class="form-control" th:field="*{additionalImages['+index+'].imageType}" aria-describedby="imageType-addon_'+id+'" id="inputImageType_'+id+'" name="imageType">'
	    		+ '<option value="0"></option><option value="1">Application Form</option><option value="2">ID Proof</option><option value="3">Proof of Billing</option><option value="4">Proof of Income</option>'
	    		+'</select>'
	    		+'</div>'
	    		+'<span class="help-block" th:if="${#fields.hasErrors(\'additionalImages['+index+'].imageType\')}" th:errors="*{additionalImages['+index+'].imageType}"></span>'
	    		+'</div>'
	    		+'<div class="col-md-8 col-xs-6" th:classappend="${#fields.hasErrors(\'additionalImages['+id+'].imageFile\')}? \'has-error\'"><div class="input-group">'
	    		+'<input type="file" class="form-control" id="image_'+id+'" th:field="*{additionalImages['+id+'].imageFile}" name="image" aria-describedby="image_'+id+'-addon" />'
	    		+'<span class="input-group-btn"><button type="button" class="btn btn-primary" onclick="resetForm(\'image_'+id+'\')">Clear</button></span></div>'
	    		+'<span class="help-block" th:if="${#fields.hasErrors(\'additionalImages['+id+'].imageFile\')}" th:errors="*{additionalImages['+id+'].imageFile}"></span> </div></div>');

	});

	$("#removeLink").click(function () {
		var id = ($('.additionalImage .row').length).toString();
	    $("#additionalImage #row-image_"+ id).remove();
	});
	/*! Customed function for dynamic addition of image with image type */
};

/* Prevents user to input character on fields marked with class numeric.*/
function enableNumericOnlyForNumericClass(){
	$(".numeric").numeric({ decimal: false, negative: false }, function() {this.value = ""; this.focus(); });
}

/* Show loading screen for every form submit only*/
function showLoadingGifOnFormSubmit(){
	$("form").on('submit',function(){$(".se-pre-con").show();});
}

/* Show tool-tip for user guide*/
function enableToolTipForHeader(){
	
	$('[href="#logout"]').tooltip({title: "Logout to CMS-IN.", animation: true,placement: "right"});
/*	$('[href="/cms/areaMaintenance"]').tooltip({title: "Register/Update Area for allocation in the respective branch.", animation: true,placement: "right"});
	$('[href="/cms/staffMaintenance"]').tooltip({title: "Register/Update staffs allowed for collection activities", animation: true,placement: "right"});
	$('[href="/cms/allocation"]').tooltip({title: "Allocate account to staff.", animation: true,placement: "right"});
	$('[href="/cms/reallocation"]').tooltip({title: "Reallocate account to staff.", animation: true,placement: "right"});*/
	$('a[id="deskContactMenu"]').tooltip({title: "Display allocated accounts and register/update collection information of the respective staff", animation: true,placement: "right"});
/*	$('[href="/cms/allocationReport"]').tooltip({title: "Allocation related reports", animation: true,placement: "right"});
	$('[href="/cms/userMaintenance"]').tooltip({title: "Restricts authorization for CMD accounts.", animation: true,placement: "right"});*/
}

function enableToolTipForMerchantUpload(){
	$('[name="generate"]').tooltip({title: "Generate a new application number. Note that this will clear all currently uploaded image/s.", animation: true,placement: "right"});
	$('#appNo-addon').tooltip({title: "Generated Application No.", animation: true,placement: "right"});
	$('#seqNo-addon').tooltip({title: "Sequence No. stated in physical Application Form.", animation: true,placement: "right"});
	$('#appForm-addon').tooltip({title: "Scanned Application Form", animation: true,placement: "right"});
	$('#idProof-addon').tooltip({title: "Id Proof e.g. SSS, Govt ID, TIN, Office ID, Passport.", animation: true,placement: "right"});
	$('#addressProof-addon').tooltip({title: "Proof of Billing e.g. Electric Bill, Water Bill, Internet Bill.", animation: true,placement: "right"});
	$('#incomeProof-addon').tooltip({title: "Proof of Income e.g. Payslip, Bank Statement.", animation: true,placement: "right"});
	
	$('[name="addImage"]').tooltip({title: "Add more images if the above default is not enough. Note that this will clear all currently uploaded image/s.", animation: true,placement: "right"});
	$('#removeLink').tooltip({title: "Remove image/s that was previouly added.", animation: true,placement: "right"});
	$('[name="clearUpload"]').tooltip({title: "Clears the uploaded file.", animation: true,placement: "right"});
	$('[name="upload_images"]').tooltip({title: "Submit the application for Data Entry.", animation: true,placement: "right"});
	$('[name="pending_images"]').tooltip({title: "Submit the application as Pending to be completed later. Only Application Form is required.", animation: true,placement: "right"});
	$('[id^="imageType-addon_"]').tooltip({title: "Select the appropriate image type per image uploaded.", animation: true,placement: "right"});
	$('[name="view_images"]').tooltip({title: "Show images pop-up.", animation: true,placement: "right",html:true});	
	$('[name="completeSubmission"]').tooltip({title: "Submit the application as complete.", animation: true,placement: "right"});
	$('[name="attach_images"]').tooltip({title: "Attach more image/s to this application", animation: true,placement: "right"});

}

function enableTooltipForSignup(){
	$('[for="storeCd"]').tooltip({title: "Please enter a valid and existing store code otherwise this will lead to validation error.", animation: true,placement: "right"});
	$('[for="username"]').tooltip({title: "Any existing username will result into validation error.", animation: true,placement: "right"});
	$('[for="email"]').tooltip({title: "Token for reset password will be sent to this email. Please put a valid email.", animation: true,placement: "right"});
	$('[type="submit"]').tooltip({title: "Register a new user with ROLE_USER privileges under the store code entered.", animation: true,placement: "right"});
}

/* For buttons << and >> */
function toChoose(param) {
	var arSelected = new Array();

	var select = [ "collectorAdd", "areaGroupAdd","areaGroupEdit","collectorEdit","selectedUserGroupEdit","allCollector" ];
	var selected = [ "selectedCollector", "selectedAreaGroup","selectedAreaGroupEdit","selectedCollectorEdit","userGroupEdit","selectedCollector" ];
	
	var operator = document.getElementById(select[param]);
	var operator2 = document.getElementById(selected[param]);

	if(operator != null){
		//get all selected
		for(i = 0; i < operator.options.length; i++){
			if(operator.options[i].selected){
				arSelected.push(operator.options[i].text);
			}
		} 
		
		//get all existing
		for(i = 0; i < operator2.options.length; i++){
				arSelected.push(operator2.options[i].text);
		}
		
		//remove values in operator2
		operator2.innerHTML = "";
		
		//add all in operator2
		arSelected.sort();
		for(i = 0; i < arSelected.length; i++){
			var y = document.createElement("option");
			y.text = arSelected[i].valueOf();
			operator2.add(y);
		}
		
		//remove selected values in operator
		$("#"+select[param]+" option:selected").remove();
//		for(i = 0; i < operator.options.length; i++){
//			for(j = 0; j < arSelected.length; j++){
//				if(operator.options[i].text == arSelected[j]){
//					operator.options.remove(i);
//				}
//			}
//		}
	}		
}

function toChooseBack(param){
	var arSelected = new Array();

	var select = [ "collectorAdd", "areaGroupAdd","areaGroupEdit","collectorEdit","selectedUserGroupEdit","allCollector" ];
	var selected = [ "selectedCollector", "selectedAreaGroup","selectedAreaGroupEdit","selectedCollectorEdit","userGroupEdit","selectedCollector" ];
	
	var operator = document.getElementById(select[param]);
	var operator2 = document.getElementById(selected[param]);
	
	
	if(operator2 != null){
		//get all selected
		for(i = 0; i < operator2.options.length; i++){
			if(operator2.options[i].selected ){
				arSelected.push(operator2.options[i].text);
			}
		} 
		
		//get all existing
//		for(i = 0; i < operator.options.length; i++){
//				arSelected.push(operator.options[i].text);
//		}
		
		//remove values in operator
//		operator2.innerHTML = "";
		
		//add all in operator
		arSelected.sort();
		for(i = 0; i < arSelected.length; i++){
			var y = document.createElement("option");
			y.text = arSelected[i].valueOf();
			operator.add(y);
		}
		
		//remove selected values in operator2
		$("#"+selected[param]+" option:selected").remove();
/*		for(i = 0; i < operator2.options.length;i++){
			for(j = 0; j < arSelected.length;j++){
				if(operator2.options[i].text == arSelected[j]){
					operator2.options.remove(i);
				}
			}
		}*/
	}
}

function toChooseBackWithoutSelected(param){
	var arSelected = new Array();

	var select = [ "collectorAdd", "areaGroupAdd","areaGroupEdit","collectorEdit","selectedUserGroupEdit","allCollector" ];
	var selected = [ "selectedCollector", "selectedAreaGroup","selectedAreaGroupEdit","selectedCollectorEdit","userGroupEdit","selectedCollector" ];
	
	var operator = document.getElementById(select[param]);
	var operator2 = document.getElementById(selected[param]);
	
	
	if(operator2 != null){
		//get all selected
		for(i = 0; i < operator2.options.length; i++){
			arSelected.push(operator2.options[i].text);
		} 
		
		//get all existing
//		for(i = 0; i < operator.options.length; i++){
//				arSelected.push(operator.options[i].text);
//		}
		
		//remove values in operator
//		operator2.innerHTML = "";
		
		//add all in operator
		arSelected.sort();
		for(i = 0; i < arSelected.length; i++){
			var y = document.createElement("option");
			y.text = arSelected[i].valueOf();
			operator.add(y);
		}
		
		//remove selected values in operator2
		for(i = 0; i < operator2.options.length;i++){
			for(j = 0; j < arSelected.length;j++){
				if(operator2.options[i].text == arSelected[j].valueOf()){
					operator2.options.remove(i);
				}
			}
		}
	}
}

function enableTextBox(){
	document.getElementById("inputApplicationAgreementNo").disabled = false;
}

function datePicker (e) {
	var datepickerId = e;
	$('#'+datepickerId).datetimepicker({
    	format: "DD/MM/YYYY"
    });
}

function datePickerMinToday () {
    $('#datepicker').datetimepicker({
    	format: "DD/MM/YYYY"
    });
    $("#datepicker").on("dp.change", function (e) {
   	 $('#datepicker').data("DateTimePicker").minDate(e.date);
   	 });
    
}

function datePickerCurrentMonth() {
	
	var currentTime = new Date();
	// First Date Of the month 
	var startDateFrom = new Date(currentTime.getFullYear(),currentTime.getMonth(),1);
	// Last Date Of the Month 
	var startDateTo = new Date(currentTime.getFullYear(),currentTime.getMonth() +1,0);
	

	 $('#datepicker_from').datetimepicker({
		format: "DD/MM/YYYY",
		minDate:startDateFrom,
		maxDate:startDateTo
	 });
	 
	 $('#datepicker_to').datetimepicker({
		format: "DD/MM/YYYY"
	 });
	 
	 $("#datepicker_from").on("dp.change", function () {
		 $('#datepicker_to').data('DateTimePicker').date(null);
	 });
	 
	 $("#datepicker_from").on("dp.change", function () {
		 var selectedDate = $('#datepicker_from').data('date');		 
		 $('#datepicker_to').data("DateTimePicker").minDate(selectedDate);
	 })
	 
	 $("#datepicker_from").on("dp.change", function () {
		 $('#datepicker_to').data("DateTimePicker").maxDate(startDateTo);
	 });


}


function datePickerUpToCurrentMonth() {
	
	var currentTime = new Date();
	// Last Date Of the Month 
	var startDateTo = new Date(currentTime.getFullYear(),currentTime.getMonth() +1,0);
	
	 $('#datepicker_month').datetimepicker({
		format: "DD/MM/YYYY",
		maxDate:startDateTo
	 });
	 
	 $("#datepicker_month").on("dp.change", function () {
		 var selectedDate = $('#datepicker_from').data('date');		 
	 })

}


function datePickerFromToDate () {

	 $('#datepicker_from').datetimepicker({
		 format: "DD/MM/YYYY"
	 });
	 
	 $('#datepicker_to').datetimepicker({
		 format: "DD/MM/YYYY"
	 });
	 $("#datepicker_from").on("dp.change", function (e) {
	 $('#datepicker_from').data("DateTimePicker").minDate(e.date);
	 });
	 $("#datepicker_to").on("dp.change", function (e) {
	 $('#datepicker_from').data("DateTimePicker").maxDate(e.date);
	 });
	 $("#datepicker_from").on("dp.change", function (e) {
	 $('#datepicker_to').data("DateTimePicker").minDate(e.date);
	 });
}

function datePickerMaxTodayDate () {
	enableToolTipForHeader();
    $('#datepicker').datetimepicker({
    	format: "YYYY/MM/DD"
    });
    $("#datepicker").on("dp.change", function (e) {
        $('#datepicker').data("DateTimePicker").maxDate(e.date);
    });
    
}

function datePickerFromTo () {
	//min date: no limit
	//max date: current month
	var currentTime = new Date();
	var maxDateTo = new Date(currentTime.getFullYear(),currentTime.getMonth() +1,0);
	
    $('#datepicker_from').datetimepicker({
    	format: "DD/MM/YYYY",
    	maxDate:maxDateTo
    });
    
    $('#datepicker_to').datetimepicker({
		 format: "DD/MM/YYYY",
		 maxDate:maxDateTo
	});
    
    $("#datepicker_from").on("dp.change", function () {
		 $('#datepicker_to').data('DateTimePicker').date(null);
	 });
	 
	 $("#datepicker_from").on("dp.change", function () {
		 var selectedDate = $('#datepicker_from').data('date');		 
		 $('#datepicker_to').data("DateTimePicker").minDate(selectedDate);
	 });
    
}

function convertTextAllCaps() {
	$("input[type=text],textarea").on('input', function (e) {
		this.value = this.value.toUpperCase();
	});
}
