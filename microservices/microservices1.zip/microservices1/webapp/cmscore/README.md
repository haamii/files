# mothership-webapp
The mothership-webapp which houses the core web application and will contain the restful modules.
